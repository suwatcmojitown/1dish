<?php
defined('BASEPATH') OR exit('No direct script access allowed');

define('PAGE_LIMIT', 20);
define('UPLOAD_PATH', 'uploads/');
define('FROALA_KEY', '');
