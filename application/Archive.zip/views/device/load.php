       
                                        <table class="table color-table default-table ">
                                            <thead style="background-color: #4e73df;color: #fff;">
                                                <tr>
                                                    <!--<th style="width:10%;">ปีการศึกษา</th>-->
                                                    <th style="width:20%;">#</th>
                                                    <th style="width:20%;">ชื่อ</th>
                                                    <th style="width:40%;">รายละเอียด</th>
                                                    <th style="width:20%;">สถานะ</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                if(isset($result)&&!empty($result)){
                                                    foreach($result as $row){
                                                ?> 
                                                <tr>
                                                    <td><?php echo @$row->serial_no;?></td>
                                                    <td><?php echo @$row->name;?></td>
                                                    <td><?php echo @$row->description;?></td>
                                                    <td <?php if(@$row->status=='offline') echo 'style="color:red";';else echo 'style="color:green;"'?>><?php echo @$row->status;?></td>
                                                <tr>
                                                <?php 
                                                    }
                                                }    
                                                ?>     
                                            </tbody>
                                        </table>
                                    