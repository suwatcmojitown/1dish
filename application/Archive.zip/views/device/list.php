                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <?php 
                                //console($academicYearList);
                                ?>
                                <hr class="m-t-0 m-b-10">
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper" id="content_div">
                                               
                                        <table class="table color-table default-table ">
                                            <thead style="background-color: #4e73df;color: #fff;">
                                                <tr>
                                                    <!--<th style="width:10%;">ปีการศึกษา</th>-->
                                                    <th style="width:20%;">#</th>
                                                    <th style="width:20%;">ชื่อ</th>
                                                    <th style="width:40%;">รายละเอียด</th>
                                                    <th style="width:20%;">สถานะ</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                if(isset($result)&&!empty($result)){
                                                    foreach($result as $row){
                                                ?> 
                                                <tr>
                                                    <td><?php echo @$row->serial_no;?></td>
                                                    <td><?php echo @$row->name;?></td>
                                                    <td><?php echo @$row->description;?></td>
                                                    <td <?php if(@$row->status=='offline') echo 'style="color:red";';else echo 'style="color:green;"'?>><?php echo @$row->status;?></td>
                                                <tr>
                                                <?php 
                                                    }
                                                }    
                                                ?>     
                                            </tbody>
                                        </table>
                                    
                                </div>
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

        <script>
        sendRequest();
        function sendRequest(){
            $.ajax({
                url: "<?php echo base_url('device/load')?>",
                success: 
                function(result){
                    $('#content_div').html(result); //insert text of test.php into your div
                    setTimeout(function(){
                        sendRequest(); //this will send request again and again;
                    }, 5000);
                }
            });
        }
        </script>
 
