<div class="tab-pane active show" id="grade" role="tabpanel">
                                    <div class="card-body">
                                        <!-- now grade -->
                                        <div class="ribbon-wrapper card">
                                        <div class="ribbon ribbon-bookmark ribbon-success ">ผลการเรียน ชั้นประถมศึกษาปีที่ 4 ปี เทอม 1 ปีการศึกษา 2562</div>
                                        <h4 class="card-title"></h4>
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead>
                                                        <tr class="text-success">
                                                            <th style="width:15%;">รหัสวิชา</th>
                                                            <th style="width:50%;">ชื่อวิชา</th>
                                                            <th style="width:15%;">กลางภาค</th>
                                                            <th style="width:15%;">ปลายภาค</th>
                                                            <th ></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="text-muted">
                                                        <tr>
                                                            <td>ท101</td>
                                                            <td>ภาษาไทย</td>
                                                            <td>35/50</td>
                                                            <td>43/50</td>
                                                            <th ><a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-danger"></i> </a>
                                                        </th>
                                                        </tr>
                                                        <tr>
                                                            <td>ค101</td>
                                                            <td>คณิตศาสตร์</td>
                                                            <td>35/50</td>
                                                            <td>43/50</td>
                                                            <th ><a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-danger"></i> </a>
                                                        </th>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <!-- now grade-->
                                        <!-- now grade -->
                                        <div class="ribbon-wrapper card">
                                        <div class="ribbon ribbon-bookmark ribbon-success ">ผลการเรียน ชั้นประถมศึกษาปีที่ 4 ปี เทอม 2 ปีการศึกษา 2562</div>
                                        <h4 class="card-title"></h4>
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead>
                                                        <tr class="text-success">
                                                            <th style="width:15%;">รหัสวิชา</th>
                                                            <th style="width:50%;">ชื่อวิชา</th>
                                                            <th style="width:15%;">กลางภาค</th>
                                                            <th style="width:15%;">ปลายภาค</th>
                                                            <th ></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="text-muted">
                                                        <tr>
                                                            <td>ท101</td>
                                                            <td>ภาษาไทย</td>
                                                            <td>35/50</td>
                                                            <td>43/50</td>
                                                            <th ><a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-danger"></i> </a>
                                                        </th>
                                                        </tr>
                                                        <tr>
                                                            <td>ค101</td>
                                                            <td>คณิตศาสตร์</td>
                                                            <td>35/50</td>
                                                            <td>43/50</td>
                                                            <th ><a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-danger"></i> </a>
                                                        </th>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <!-- now grade-->
                                        <!-- list grade -->
                                        <div class="ribbon-wrapper card">
                                        <div class="ribbon ribbon-bookmark ribbon-primary ">ผลการศึกษา</div>
                                        <h4 class="card-title"></h4>
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead>
                                                        <tr class="text-primary">
                                                            <th style="width:30%;">ระดับชั้น</th>
                                                            <th style="width:20%;">ปีการศึกษา</th>
                                                            <th style="width:20%;">ผลการศึกษา</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="text-muted">
                                                        <tr>
                                                            <td>ประถมศึกษาปีที่ 1</td>
                                                            <td>2559</td>
                                                            <td>89.0</td>
                                                        </tr>
                                                        <tr>
                                                            <td>ประถมศึกษาปีที่ 2</td>
                                                            <td>2560</td>
                                                            <td>86.0</td>
                                                        </tr>
                                                        <tr>
                                                            <td>ประถมศึกษาปีที่ 3</td>
                                                            <td>2561</td>
                                                            <td>93.2</td>
                                                        </tr>
                                                        <tr>
                                                            <td>ประถมศึกษาปีที่ 4</td>
                                                            <td>2562</td>
                                                            <td>-</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <!-- list grade -->
                                        
                                    </div>
                                </div>
                                <script type="text/javascript"> 
   
   $( "#parent").click(function() {
           $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'student/editParent'?>',
               data: 'id=<?php echo $student_id;?>',
               success: function(result) {
                   $('#content_div').html(result);
               }
           });
   });        
   $( "#profile").click(function() {
           $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'student/editProfile_load'?>',
               data: 'student_id=<?php echo $student_id;?>',
               success: function(result) {
                   $('#content_div').html(result);
               }
           });        
   });
   $( "#behave").click(function() {
           $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'student/editBehave'?>',
               data: 'student_id=<?php echo $student_id;?>',
               success: function(result) {
                   $('#content_div').html(result);
               }
           });        
   });
   $( "#score").click(function() {
           $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'student/editScore'?>',
               data: 'student_id=<?php echo $student_id;?>',
               success: function(result) {
                   $('#content_div').html(result);
               }
           });        
   });
</script>                                