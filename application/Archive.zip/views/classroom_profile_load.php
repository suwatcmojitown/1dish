<thead>
    <tr>
        <th style="width:5%;">#</th>
        <th style="width:60%;">ชื่อ - นามสกุล</th>
        <th style="width:30%;">เลขประจำตัว</th>
    </tr>
</thead>
<tbody class="text-muted" >
<?php 
foreach($student as $row)
{
?>                                                                                      
<tr>
            <td class="text-nowrap" style="font-size: 17px;">
            <input type="radio" class="student" id="<?php echo $row->id;?>" value="<?php echo $row->id;?>" name="student[]">
            </td>
            <td class="p-t-20"><?php echo $row->name_th?></td>
            <td class="p-t-20"><?php echo $row->student_no?></td>
</tr>
<?php
}
?>
</tbody>

<script type="text/javascript">    
   $( "#addStudentBtn").click(function() {
        var a = $('.student:checked').val();
        $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'classroom/addStudent'?>',
               data: 'student_id='+a+'&classroom_id=<?php echo $classroom_id;?>',
               success: function(result) {
                   alert(result);
                   //$('#parentList').html(result);
               }
           });      
   });

</script>
