<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
<?php 
if($alert!='')
{
    if($alert=='success'){
?>
        swal("success!", "ทำรายการสำเร็จ", "success");
<?php 
    }
    else
    {
?> 
        swal("Error!", "ไม่สามารถทำรายการได้", "error");
<?php 
    }
}
?>
</script>
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <div class="text-right m-b-10">
                                        <a href="<?php echo base_url('files/แบบฟอร์มรายชื่อบุคลากร.xlsx');?>"><button class="btn btn-success" type="button" > <span><i class="fa fa-file-excel-o"></i> ไฟล์ต้นฉบับ</span> </button></a>
                                        <a href="personnelCreate"><button class="btn btn-success" type="button"> <span><i class="fa fa-plus"></i><i class="fa fa-user-md"></i> เพิ่มบุคลากร</span> </button></a>
                                </div>
                                
                                <hr class="m-t-0 m-b-20">
                                
                                <div class="row m-b-15">
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                 <?php 
                                                 //console($result);
                                                 ?>
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ตำแหน่ง
                                                </div>
                                                <div class="col-md-2" id="personnelGroup_div">
                                                        <select class="form-control custom-select text-muted" id="personnelGroupSec" name="personnelGroupSec">
                                                                            <option value="0">ทั้งหมด</option>
                                                                            <?php 
                                                                            if(isset($personnelGroupList)&&!empty($personnelGroupList)){
                                                                                foreach($personnelGroupList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->title;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                            ?>
                                                        </select>
                                                </div>
                                                <!--                            
                                                <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                        สิทธิ์การใช้งาน
                                                </div>
                                                <div class="col-md-2" id="subjectList_div">
                                                        <select class="form-control custom-select text-muted" id="permissionSec" name="permissionSec">
                                                                            <option value="0">ทั้งหมด</option>
                                                                            <?php 
                                                                            if(isset($permissionList)&&!empty($permissionList)){
                                                                                foreach($permissionList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->title;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                            ?>
                                                        </select>
                                                                
                                                </div>
                                                                                
                                                
                                                -->

                                                <div class="offset-md-1 col-md-4">
                                                        <input type="text" id="search" name="search" placeholder="คำค้นหา : เบอร์โทรศัพท์,ชื่อ,นามสกุล" class="form-control" placeholder="คำค้นหา" <?php if($search) echo "value='$search'";?>>
                                                </div>

                                                <div class="col-md-2">
                                                      <button type="button" id="searchBtn" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                
                                
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper" id="load_content">
                                        <?php 
                                        //console($result);
                                        ?>
                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <th style="width:25%;">ชื่อ - สกุล</th>
                                                    <th style="width:15%;">ฝ่าย</th>
                                                    <th style="width:15%;">วิชา</th>
                                                    <th style="width:15%;">หมวด</th>
                                                    <th style="width:15%;">เบอร์โทรศัพท์</th>
                                                    <th style="width:10%;">รูปภาพ</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                
                                                if(isset($result)&&!empty($result)){
                                                    if(isset($page)&&!empty($page))
                                                    { 
                                                        $active_page = $page->page;
                                                        $i = (($active_page-1)*PAGE_LIMIT)+1;
                                                    }else $i = 1; 
                                                    foreach($result as $row){
                                                ?> 
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo $row->name_th;?></td>
                                                    <td><?php echo $row->personnel_group_title;?></td>
                                                    <td><?php //echo $row->subject;?></td>
                                                    <td><?php echo $row->subject_group_name_th;?></td>
                                                    <td><?php echo $row->cell_phone;?></td>
                                                    <td><img src="<?php echo $row->profile_ing_url;?>" style="max-height:100px;"></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="<?php echo base_url('setting/personnelEdit/').$row->id;?>" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-warning"></i> </a>
                                                    </td>
                                                <tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }    
                                                ?> 
                                            </tbody>
                                        </table>    

                                    <?php
                                    if(isset($page->page)&&!empty($page->page))
                                    { 
                                        $active_page = $page->page;
                                        $total = $page->total_page;
                                        if($total>1){
                                        
                                    ?>	            

                                <div class="dataTables_paginate paging_simple_numbers" id="example23_paginate">
                                        <?php if($active_page-1>0){?>    
                                            <a href="<?php echo base_url('setting/personnelList?page=').($active_page-1);?>" class="paginate_button previous" aria-controls="example23" data-dt-idx="0" tabindex="0" id="example23_previous">ก่อนหน้า</a>
                                        <?php }?>
                                        
                                        <?php 
                                            if($active_page-2>0)
                                        {
                                        ?>     
                                            <a href="<?php echo base_url('setting/personnelList?page=').($active_page-2);?>" class="paginate_button " aria-controls="example23" data-dt-idx="2" tabindex="0"><?php echo $active_page-2;?></a>
                                        <?php
                                        } 
                                        if($active_page-1>0)
                                        {
                                        ?>     
                                            <a href="<?php echo base_url('setting/personnelList?page=').($active_page-1);?>" class="paginate_button " aria-controls="example23" data-dt-idx="3" tabindex="0"><?php echo $active_page-1;?></a>
                                        <?php 
                                        }
                                        ?>   
                                            <a class="paginate_button current" aria-controls="example23" data-dt-idx="4" tabindex="0"><?php echo $active_page;?></a>
                                        <?php 
                                            if($active_page+1<=$total)
                                        {
                                        ?>
                                            <a href="<?php echo base_url('setting/personnelList?page=').($active_page+1);?>" class="paginate_button " aria-controls="example23" data-dt-idx="5" tabindex="0"><?php echo $active_page+1;?></a>
                                        <?php 
                                        }
                                        ?>
                                        <?php 
                                            if($active_page+2<=$total)
                                        {
                                        ?>
                                            <a href="<?php echo base_url('setting/personnelList?page=').($active_page+2);?>" class="paginate_button " aria-controls="example23" data-dt-idx="6" tabindex="0"><?php echo $active_page+2;?></a></span>
                                        <?php 
                                        }
                                        ?>
                                            <?php if($active_page+1<$total){?>      
                                            <a href="<?php echo base_url('setting/personnelList?page=').($active_page+1);?>" class="paginate_button next" aria-controls="example23" data-dt-idx="7" tabindex="0" id="example23_next">ถัดไป</a>
                                        <?php }?>
                                    </div>
                                    <hr>
                                    <?php 
                                        }
                                    }
                                    ?>
                                                
                                </div>
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>

        <script>
        
        $( "#personnelGroupSec").change(function() {
            a = document.getElementById("personnelGroupSec").value;
            //b = document.getElementById("permissionSec").value;
            page = <?php if(isset($page->page)&&!empty($page->page))echo $page->page;else echo '1';?>;
            
            $.ajax({
                type: 'POST',
                url: 'personnelLoad',
                data: 'personnelGroup='+a+'&page='+page,
                success: function(result) { 
                    $("#load_content").html(result);
                }
            });
            
        });
        
        $( "#searchBtn").click(function() {
            key = document.getElementById("search").value;
            url = "<?php echo base_url('setting/personnelList').'?search=';?>"+key;
            window.location.replace(url);
        });

        </script>