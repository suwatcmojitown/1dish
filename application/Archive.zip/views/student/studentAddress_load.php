<!--/row-->
<?php
//console($result); 
if(isset($result[0]->subdistrict_name))$subdistrict = $result[0]->subdistrict_name; else $subdistrict = '';
if(isset($result[0]->subdistrict_id))$subdistrict_id = $result[0]->subdistrict_id; else $subdistrict_id = '';
if(isset($result[0]->district_name))$district = $result[0]->district_name; else $district = '';
if(isset($result[0]->province_name))$province = $result[0]->province_name; else $province = '';
if(isset($result[0]->zip_code))$zip_code = $result[0]->zip_code; else $zip_code = '';
?>
                                                                    <div class="col-md-6">
                                                                        <div class="form-group row" style="margin-bottom:0px!important;">
                                                                            <label class="control-label text-left col-md-4 text-primary" style="padding-top:7px;">ตำบล</label>
                                                                            <div class="col-md-8">
                                                                                <input type="text" id="subdistrict" name="subdistrict" class="form-control text-muted" placeholder="กรอกตำบล" value="<?php echo $subdistrict;?>" required>
                                                                                <input type="hidden" id="subdistrict_id" name="subdistrict_id" value="<?php echo $subdistrict_id;?>" >
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-group row" style="margin-bottom:0px!important;">
                                                                            <label class="control-label text-left col-md-4 text-primary p-t-5" style="padding-top:7px;">อำเภอ</label>
                                                                            <div class="col-md-8">
                                                                                 <input type="text" id="district" name="district" class="form-control text-muted" placeholder="กรอกอำเภอ" value="<?php echo $district;?>" required>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-group row m-t-5" >
                                                                            <label class="control-label text-left col-md-4 text-primary p-t-5" style="padding-top:7px;">จังหวัด</label>
                                                                            <div class="col-md-8">
                                                                                 <input type="text" id="province" name="province" class="form-control text-muted" placeholder="กรอกจังหวัด" value="<?php echo $province;?>" required>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-group row m-t-5" >
                                                                            <label class="control-label text-left col-md-4 text-primary p-t-5" style="padding-top:7px;">รหัสไปรษณีย์</label>
                                                                            <div class="col-md-7">
                                                                                 <input type="text" id="zipcode" name="zipcode" class="form-control text-muted" placeholder="กรอกรหัสไปรษณีย์" value="<?php echo $zip_code;?>" required>
                                                                            </div>
                                                                        </div>
                                                                    </div> 



<script>
$('#subdistrict').keyup(function(e) {
    clearTimeout($.data(this, 'timer'));
    if (e.keyCode == 13)
      search(true);
    else
      $(this).data('timer', setTimeout(search, 500));
    });
    function search(force) {
        var existingString = $("#subdistrict").val();
        if (!force && existingString.length < 3) return; //wasn't enter, not > 2 char
        //alert('d');
        $.get('getStudentAddress/' + existingString, function(data) {
            $('#address_detail').html(data);
            /*
            $('#address_detail').html(data);
            $('#results').show();
            */
        });
    }
</script>