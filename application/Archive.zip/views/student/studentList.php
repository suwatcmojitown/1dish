                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <!--
                                <div class="text-right m-b-10">
                                        <a href="studentCreate"><button class="btn btn-success" type="button" data-toggle="modal" data-target="#responsive-modal"> <span><i class="fa fa-file-o"></i>เพิ่มนักเรียน</span> </button></a>
                                </div>
                                
                                <hr class="m-t-0 m-b-20">
                                -->
                                
                                <div class="row">
                                                <!--
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ปีการศึกษา
                                                </div>
                                                <div class="col-md-2" >
                                                        <select class="form-control custom-select text-muted" id="academic_year" name="academic_year">
                                                                            <option value="0">ทั้งหมด</option>
                                                                        <?php 
                                                                            if(isset($academicYearList)&&!empty($academicYearList)){
                                                                                foreach($academicYearList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>">ปี <?php echo $row->academic_year;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                        ?>
                                                        </select>
                                                                
                                                </div>
                                                -->
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ชั้น
                                                </div>
                                                <div class="col-md-2" >
                                                        <select class="form-control custom-select text-muted" id="education" name="education">
                                                                        <option value="0">ทั้งหมด</option>
                                                                        <?php 
                                                                            if(isset($educationList)&&!empty($educationList)){
                                                                                foreach($educationList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                        ?>
                                                        </select>
                                                                
                                                </div> 
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ระดับ
                                                </div>
                                                <div class="col-md-2" id="educationSublevel_div">
                                                        <select class="form-control custom-select text-muted" id="educationSub" name="educationSub">
                                                                            <option value="0">ทั้งหมด</option>
                                                        </select>
                                                </div>

                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ห้อง
                                                </div>
                                                <div class="col-md-2" id="room_div">
                                                        <select class="form-control custom-select text-muted" id="room" name="room">
                                                                            <option value="0">ทั้งหมด</option>
                                                        </select>
                                                </div>
                                </div>

                                <div class="row m-b-15 m-t-15">
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <div class="col-md-3">
                                                        <input type="text" id="search" name="search" class="form-control" placeholder="คำค้นหา" <?php if($search) echo "value='$search'";?>>
                                                </div> 

                                                <div class="col-md-1">
                                                      <button type="button" id="searchBtn" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>

                                            </div>
                                            
                                        </div>
                                </div>
                                
                                
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper" id="content_div">
                                        <?php //console($result);?>
                                        
                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <th style="width:15%;">รหัสนักเรียน</th>
                                                    <th style="width:20%;">ชื่อ - สกุล</th>
                                                    <th style="width:20%;">ชั้นเรียน</th>
                                                    <th style="width:10%;">รูปภาพ</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                if(isset($result)&&!empty($result)){
                                                    $i = 1;
                                                    foreach($result as $row){
                                                ?> 
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo $row->id_card;?></td>
                                                    <td><?php echo $row->name_th;?></td>
                                                    <td><?php echo $row->room;?></td>
                                                    <td><img src="<?php echo $row->profile_img_url;?>" style="max-height:100px;"></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="<?php echo base_url('student/profile/').$row->id;?>" data-toggle="tooltip" data-original-title="ดู"> <i class="fa fa-eye text-success m-r-10"></i> </a>
                                                        <a href="<?php echo base_url('student/editProfile/').$row->id;?>" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-warning"></i> </a>
                                                    </td>
                                                <tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }    
                                                ?> 
                                            </tbody>
                                        </table>    
                                                
                                    <?php 
                                    if(isset($page)&&!empty($page))
                                    { 
                                        $active_page = $page->page;
                                        $total = $page->total_page;
                                        
                                    ?>	            

                                    <div class="dataTables_paginate paging_simple_numbers" id="example23_paginate">
                                        <?php if($active_page-1>0){?>    
                                            <a class="paginate_button previous" aria-controls="example23" data-dt-idx="0" tabindex="0" id="example23_previous">ก่อนหน้า</a>
                                        <?php }?>
                                        
                                        <?php 
                                            if($active_page-2>0)
                                        {
                                        ?>     
                                            <a class="paginate_button " aria-controls="example23" data-dt-idx="2" tabindex="0"><?php echo $active_page-2;?></a>
                                        <?php
                                        } 
                                        if($active_page-1>0)
                                        {
                                        ?>     
                                            <a class="paginate_button " aria-controls="example23" data-dt-idx="3" tabindex="0"><?php echo $active_page-1;?></a>
                                        <?php 
                                        }
                                        ?>   
                                            <a class="paginate_button current" aria-controls="example23" data-dt-idx="4" tabindex="0"><?php echo $active_page;?></a>
                                        <?php 
                                            if($active_page+1<=$total)
                                        {
                                        ?>
                                            <a class="paginate_button " aria-controls="example23" data-dt-idx="5" tabindex="0"><?php echo $active_page+1;?></a>
                                        <?php 
                                        }
                                        ?>
                                        <?php 
                                            if($active_page+2<=$total)
                                        {
                                        ?>
                                            <a class="paginate_button " aria-controls="example23" data-dt-idx="6" tabindex="0"><?php echo $active_page+2;?></a></span>
                                        <?php 
                                        }
                                        ?>
                                            <?php if($active_page+1<$total){?>      
                                            <a class="paginate_button next" aria-controls="example23" data-dt-idx="7" tabindex="0" id="example23_next">ถัดไป</a>
                                        <?php }?>
                                    </div>
                                    <hr>
                                    <?php 
                                    }
                                    ?>             
                                </div>
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>

        <script>
        
        $( "#searchBtn").click(function() {
            key = document.getElementById("search").value;
            url = "<?php echo base_url('student/list').'?page='.$page->page.'&search=';?>"+key;
            window.location.replace(url);
        });

        $( "#education").change(function() {
            a = document.getElementById("education").value;
            //b = document.getElementById("subjectGroupSec").value;
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url('student/')?>loadEducationSub',
                data: 'education='+a+'&academic_year=<?php echo $academicYearNow;?>&term_id=<?php echo $term_id;?>',
                success: function(result) { 
                    $("#educationSublevel_div").html(result);
                }
            });
            
        });

        $( "#academic_year").change(function() {
            academic_year = <?php echo $academicYearNow;?>;
            education = document.getElementById("education").value;
            educationSub = document.getElementById("educationSub").value;
            room = document.getElementById("room").value;
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url('student/')?>listLoad',
                data: 'academic_year='+academic_year+'&education='+education+'&educationSub='+educationSub+'&room='+room,
                success: function(result) { 
                    $("#content_div").html(result);
                }
            });
            
            
        });

        </script>