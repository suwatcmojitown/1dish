<?php
defined('BASEPATH') or exit('No direct script access allowed');
$name_title = @$profile->name_title_th;
$firstname = @$profile->firstname_th;
$lastname = @$profile->lastname_th;
$profile_img = @$profile->profile_img_url;

//profile
$name_title_th = @$profile->name_title_th;
$firstname_th = @$profile->firstname_th;
$lastname_th = @$profile->lastname_th;
$name_title_en = @$profile->name_title_en;
$firstname_en = @$profile->firstname_en;
$lastname_en = @$profile->lastname_en;
$nickname = @$profile->nickname;

$student_no = @$profile->student_no;
$id_card = @$profile->id_card;
$id_1 = substr($id_card,0,1);
$id_2 = substr($id_card,1,4);
$id_3 = substr($id_card,5,5);
$id_4 = substr($id_card,10,2);
$id_5 = substr($id_card,12,1);
$birthdate = @$profile->birthdate;
$blood_type = @$profile->blood_type;
$congenital_disease = @$profile->congenital_disease;
$nationality = @$profile->nationality;
$race = @$profile->race;
$religion = @$profile->religion;

$address = @$profile->address;
$province_name = @$profile->province_name;
$district_name = @$profile->district_name;
$subdistrict_name = @$profile->subdistrict_name;
$zipcode = @$profile->zipcode;
$home_latitude = @$profile->home_latitude;
$home_longitude = @$profile->home_longitude;

$behavior_point = @$profile->behavior_point;

$room = @$profile->room;

//console($profile);
?>

                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        <div class="card">
                            <div class="card-body">
                                <center class="m-t-30"> <img src="<?php echo $profile_img;?>" class="img-circle" width="150" />
                                    <h4 class="card-title m-t-10"><?php echo $name_title;?> <?php echo $firstname;?> <?php echo $lastname;?></h4>
                                    <h6 class="card-subtitle m-t-20">ปีการศึกษา <?php echo $academicYearNow;?></h6>
                                    <h6 class="card-subtitle"><?php echo $room;?></h6>
                                    <h6 class="card-subtitle m-t-20">คะแนนความประพฤติ <?php echo $point;?> คะแนน</h6>
                                </center>
                            </div>
                            <div>
                                <hr> 
                            </div>
                            <div class="card-body"> <h6 class="text-muted">ผู้ปกครอง : <span style="color:black;">
                                <?php echo @$parentContactPoint[0]->name;?></span></h6> 
                                <h6 class="text-muted p-t-10">เบอร์โทรศัพท์ : <span style="color:black;"><?php echo @$parentContactPoint[0]->cell_phone;?></span></h6> 
                            </div>
                            <div>
                                <hr> 
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs profile-tab" role="tablist">
                                <li class="nav-item" id="profile"> <a class="nav-link" data-toggle="tab" href="#home" role="tab">ข้อมูลทั่วไป</a> </li>
                                <li class="nav-item" id="parent"> <a class="nav-link" data-toggle="tab" href="#family" role="tab">ผู้ปกครอง</a> </li>
                                <li class="nav-item" id="grade"> <a class="nav-link" data-toggle="tab" href="#" role="#tab">ผลการเรียน</a> </li>
                                <li class="nav-item" id="behave"> <a class="nav-link" data-toggle="tab" href="#" role="#tab">ความประพฤติ</a> </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content" id="content_div">
                                <div class="tab-pane active" id="home" role="tabpanel">
                                    <div class="card-body">
                                        <div class="row">
                                               <div class="col-lg-12 col-md-12 col-xlg-2 col-xs-12">
                                                    <form class="form-horizontal" role="form">
                                                        <div class="ribbon-wrapper card">
                                                        <div class="ribbon ribbon-bookmark ribbon-success ">ข้อมูลพื้นฐาน</div>
                                                            <div class="form-body m-t-15">
                                                                <div class="row">
                                                                    <!--/span-->
                                                                    <div class="col-md-12">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-2 text-primary" style="padding-top:7px;">รหัสนักเรียน</label>
                                                                            <div class="col-md-2">
                                                                                <input type="text" class="form-control text-muted" id="student_no" name="student_no" value="<?php echo $student_no;?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                    <div class="col-md-12 m-t-20">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-2 text-primary" style="padding-top:7px;">ชื่อ</label>
                                                                            <div class="col-md-2">
                                                                                <select class="form-control custom-select text-muted" data-placeholder="Choose a Category" tabindex="1" required>
                                                                                    <option value="all">--เลือก--</option>
                                                                                    <option value="เด็กชาย" <?php if($name_title_th=='เด็กชาย') echo 'selected';?>>เด็กชาย</option>
                                                                                    <option value="เด็กหญิง" <?php if($name_title_th=='เด็กหญิง') echo 'selected';?>>เด็กหญิง</option>
                                                                                    <option value="นาย" <?php if($name_title_th=='นาย') echo 'selected';?>>นาย</option>
                                                                                    <option value="นางสาว" <?php if($name_title_th=='นางสาว') echo 'selected';?>>นางสาว</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="col-md-4">
                                                                                <input type="text" class="form-control text-muted" id="firstname_th" name="firstname_th" value="<?php echo $firstname_th;?>">
                                                                            </div>
                                                                            <div class="col-md-4">
                                                                                <input type="text" class="form-control text-muted" id="lastname_th" name="lastname_th" value="<?php echo $lastname_th;?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                    <div class="col-md-12">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-2 text-primary" style="padding-top:7px;">Name</label>
                                                                            <div class="col-md-2">
                                                                                <select class="form-control custom-select text-muted" data-placeholder="Choose a Category" tabindex="1" required>
                                                                                    <option value="Mr." <?php if($name_title_en=='Mr.') echo 'selected';?>>Mr.</option>
                                                                                    <option value="Mrs." <?php if($name_title_en=='Mrs.') echo 'selected';?>>Mrs.</option>
                                                                                    <option value="Miss." <?php if($name_title_en=='Miss.') echo 'selected';?>>Miss.</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="col-md-4">
                                                                                <input type="text" class="form-control text-muted" id="firstname_en" name="firstname_en" value="<?php echo $firstname_en;?>">
                                                                            </div>
                                                                            <div class="col-md-4">
                                                                                <input type="text" class="form-control text-muted" id="lastname_en" name="lastname_en" value="<?php echo $lastname_en;?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                    <div class="col-md-12 m-t-20">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-2 text-primary" style="padding-top:7px;">ชื่อเล่น</label>
                                                                            <div class="col-md-3">
                                                                                <input type="text" class="form-control text-muted" id="nickname" name="nickname" value="<?php echo $nickname;?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                    <div class="col-md-12 ">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-2 text-primary" style="padding-top:7px;">รหัสประชาชน</label>
                                                                            
                                                                                <!--<p class="form-control-static">1-1029-00216-35-1</p>-->
                                                                                <div class="col-md-1">
                                                                                    <input type="text" value="<?php echo $id_1;?>" id="txtID1" name="txtID1" class="form-control text-muted" maxlength=1 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" required>
                                                                                </div>
                                                                                <span class="p-t-5">-</span>   
                                                                                <div class="col-md-2">
                                                                                    <input type="text" value="<?php echo $id_2;?>" id="txtID2" name="txtID2" class="form-control text-muted" maxlength=4 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" required>  
                                                                                </div>
                                                                                <span class="p-t-5">-</span> 
                                                                                <div class="col-md-2">
                                                                                    <input type="text" value="<?php echo $id_3;?>" id="txtID3" name="txtID3" class="form-control text-muted" maxlength=5 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" required>  
                                                                                </div>
                                                                                <span class="p-t-5">-</span> 
                                                                                <div class="col-md-2">
                                                                                    <input type="text" value="<?php echo $id_4;?>" id="txtID4" name="txtID4" class="form-control text-muted" maxlength=2 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" required> 
                                                                                </div> 
                                                                                <span class="p-t-5">-</span> 
                                                                                <div class="col-md-1">
                                                                                    <input type="text" value="<?php echo $id_5;?>" id="txtID5" name="txtID5" class="form-control text-muted" maxlength=1 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" required> 
                                                                                </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                    <div class="col-md-12">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-2 text-primary" style="padding-top:7px;">วันเกิด</label>
                                                                            <div class="col-md-4">
                                                                                 <input type="date" class="form-control text-muted" id="birthdate" name="birthdate" value="<?php echo $birthdate;?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                </div>
                                                                <!--/row-->
                                                            </div> 
                                                        </div>
                                                        <div class="ribbon-wrapper card">
                                                        <div class="ribbon ribbon-bookmark ribbon-success ">ข้อมูลพื้นฐาน</div>
                                                            <div class="form-body m-t-15">
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <div class="form-group row" style="margin-bottom:0px!important;">
                                                                            <label class="control-label text-left col-md-2 text-primary p-t-5">ที่อยู่</label>
                                                                            <div class="col-md-8">
                                                                                 <textarea id="address" name="address" class="form-control text-muted" placeholder="กรอกที่อยู่" required value="<?php echo $address;?>"></textarea>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                     
                                                                    <div class="col-md-6">
                                                                        <div class="form-group row" style="margin-bottom:0px!important;">
                                                                            <label class="control-label text-left col-md-4 text-primary" style="padding-top:7px;">ตำบล</label>
                                                                            <div class="col-md-8">
                                                                                <input type="text" id="subdistrict" name="subdistrict" class="form-control text-muted" placeholder="กรอกตำบล" value="<?php echo $subdistrict_name;?>" required>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-group row" style="margin-bottom:0px!important;">
                                                                            <label class="control-label text-left col-md-4 text-primary p-t-5" style="padding-top:7px;">อำเภอ</label>
                                                                            <div class="col-md-8">
                                                                                 <input type="text" id="district" name="district" class="form-control text-muted" placeholder="กรอกอำเภอ" value="<?php echo $district_name;?>" required>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-group row m-t-5" >
                                                                            <label class="control-label text-left col-md-4 text-primary p-t-5" style="padding-top:7px;">จังหวัด</label>
                                                                            <div class="col-md-8">
                                                                                 <input type="text" id="province_id" name="province_id" class="form-control text-muted" placeholder="กรอกจังหวัด" value="<?php echo $province_name;?>" required>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-group row m-t-5" >
                                                                            <label class="control-label text-left col-md-4 text-primary p-t-5" style="padding-top:7px;">รหัสไปรษณีย์</label>
                                                                            <div class="col-md-7">
                                                                                 <input type="text" id="zipcode" name="zipcode" class="form-control text-muted" placeholder="กรอกรหัสไปรษณีย์" value="<?php echo $zipcode;?>" required>
                                                                            </div>
                                                                        </div>
                                                                    </div> 
                                                                    
                                                                    <div class="col-md-6">
                                                                        <div class="form-group row">
                                                                            <label class="control-label text-left col-md-4 text-primary p-t-5" style="padding-left:14px;padding-top:7px;">longitude</label>
                                                                            <div class="col-md-8">
                                                                                 <input type="text" id="home_longitude" name="home_longitude" class="form-control text-muted" placeholder="กรอกตำแหน่ง longitude" value="<?php echo $home_longitude;?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-group row">
                                                                            <label class="control-label text-left col-md-3 text-primary p-t-5">latitude</label>
                                                                            <div class="col-md-8">
                                                                                 <input type="text" id="home_latitude" name="home_latitude" class="form-control text-muted" placeholder="กรอกตำแหน่ง latitude" value="<?php echo $home_latitude;?>">
                                                                            </div>
                                                                        </div>
                                                                    </div> 
                                                                </div>      
                                                            </div>
                                                        </div>
                                                        <hr class="m-t-0 m-b-20">
                                                        <div class="row">
                                                                    <div class="col-12">
                                                                        <div class="form-group row">

                                                                            <div class="offset-md-7 col-md-1">
                                                                                 <button class="btn btn-danger pull-right" input type="reset" >ยกเลิก</button>
                                                                                
                                                                            </div>    
                                                                            <div class="offset-md-1 col-md-1">
                                                                                 <button class="btn btn-success pull-right btn-outline" input type="submit"> บันทึก</button>
                                                                            </div>     
                                                                        </div>
                                                                    </div>
                                                        </div>           
                                                    </form>
                                                </div> 
                                            </div>
                                        </div>    
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

<script type="text/javascript"> 
   
    $( "#parent").click(function() {
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url().'student/editParent'?>',
                data: 'id=<?php echo $student_id;?>',
                success: function(result) {
                    $('#content_div').html(result);
                }
            });
    });        
    $( "#profile").click(function() {
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url().'student/editProfile_load'?>',
                data: 'student_id=<?php echo $student_id;?>',
                success: function(result) {
                    $('#content_div').html(result);
                }
            });        
    });
    $( "#behave").click(function() {
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url().'student/editBehave'?>',
                data: 'student_id=<?php echo $student_id;?>',
                success: function(result) {
                    $('#content_div').html(result);
                }
            });        
    });
    $( "#grade").click(function() {
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url().'student/editScore'?>',
                data: 'student_id=<?php echo $student_id;?>',
                success: function(result) {
                    $('#content_div').html(result);
                }
            });        
    });
</script>

    