<?php 
//console($behaviorLogPlus);
?>
<div class="tab-pane active show" id="behave" role="tabpanel">
                                    <div class="card-body">
                                        <div class="card-body">
                                            <h4><span class="text-purple"><i class="far fa-meh" style="font-size:24px;" aria-hidden="true"></i> คะแนนความประพฤติ <?php echo $point;?> คะแนน</span></h4>
                                        </div>
                                        <!-- list grade -->
                                        <div class="card">
                                                <div class="card-header bg-cyan">
                                                    <span class="m-b-0 text-white"><i class="far fa-grin" aria-hidden="true" style="font-size:24px;"></i> เพิ่มคะแนนความประพฤติ</span> 
                                                </div>
                                                <div>
                                                    <div class="card-body">
                                                        <table class="table color-table primary-table">
                                                            <tbody class="text-muted">
                                                                <?php 
                                                                if(isset($behaviorLogPlus)&&!empty($behaviorLogPlus))
                                                                {
                                                                    //console($behaviorLogPlus);
                                                                    foreach($behaviorLogPlus->logs as $row)
                                                                    {
                                                                ?>
                                                                <tr>
                                                                    <td width=50%><?php echo $row->reason;?></td>
                                                                    <td><?php echo $row->point;?></td>
                                                                    <td width=25%><?php echo $row->created_date;?></td>
                                                                    <td width=10%><a href="#" data-toggle="tooltip" data-original-title="ลบ" class="img-responsive" > <i class="fa fa-close text-danger"></i></a></td>
                                                                </tr>
                                                                <?php 
                                                                    }
                                                                }    
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                        </div>
                                        <!-- list grade -->
                                        <!-- now grade -->
                                        <div class="card">
                                                <div class="card-header bg-primary">
                                                <span class="m-b-0 text-white"><i class="far fa-frown" aria-hidden="true" style="font-size:24px"></i> หักคะแนนความประพฤติ</span>
                                                </div>
                                                <div id="collapse1" class="collapse show" aria-labelledby="heading11" data-parent="#accordian-3" style="">
                                                    <div class="card-body">
                                                        <table class="table color-table primary-table">
                                                            <tbody class="text-muted">
                                                                <?php 
                                                                if(isset($behaviorLogMinus)&&!empty($behaviorLogMinus))
                                                                {
                                                                    foreach($behaviorLogMinus->logs as $row)
                                                                    {
                                                                ?>
                                                                <tr>
                                                                    <td width=50%><?php echo $row->reason;?></td>
                                                                    <td><?php echo $row->point;?></td>
                                                                    <td width=25%><?php echo $row->created_date;?></td>
                                                                    <td width=10%><a href="#" data-toggle="tooltip" data-original-title="ลบ" class="img-responsive" > <i class="fa fa-close text-danger"></i></a></td>
                                                                </tr>
                                                                <?php 
                                                                    }
                                                                }    
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                        </div>
                                        <!-- now grade-->
                                    </div>
                                </div>
                                <script type="text/javascript"> 
   
   $( "#parent").click(function() {
           $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'student/editParent'?>',
               data: 'id=<?php echo $student_id;?>',
               success: function(result) {
                   $('#content_div').html(result);
               }
           });
   });        
   $( "#profile").click(function() {
           $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'student/editProfile_load'?>',
               data: 'student_id=<?php echo $student_id;?>',
               success: function(result) {
                   $('#content_div').html(result);
               }
           });        
   });
   $( "#behave").click(function() {
           $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'student/editBehave'?>',
               data: 'student_id=<?php echo $student_id;?>',
               success: function(result) {
                   $('#content_div').html(result);
               }
           });        
   });
   $( "#score").click(function() {
           $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'student/editScore'?>',
               data: 'student_id=<?php echo $student_id;?>',
               success: function(result) {
                   $('#content_div').html(result);
               }
           });        
   });
</script>                                