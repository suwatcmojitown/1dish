<?php 
$name_title = @$profile->name_title_th;
$firstname = @$profile->firstname_th;
$lastname = @$profile->lastname_th;
$profile_img = @$profile->profile_img_url;

//profile
$name_title_th = @$profile->name_title_th;
$firstname_th = @$profile->firstname_th;
$lastname_th = @$profile->lastname_th;
$name_title_en = @$profile->name_title_en;
$firstname_en = @$profile->firstname_en;
$lastname_en = @$profile->lastname_en;
$nickname = @$profile->nickname;

$student_no = @$profile->student_no;
$id_card = @$profile->id_card;
$id_1 = substr($id_card,0,1);
$id_2 = substr($id_card,1,4);
$id_3 = substr($id_card,5,5);
$id_4 = substr($id_card,10,2);
$id_5 = substr($id_card,12,1);
$birthdate = @$profile->birthdate;
$blood_type = @$profile->blood_type;
$congenital_disease = @$profile->congenital_disease;
$nationality = @$profile->nationality;
$race = @$profile->race;
$religion = @$profile->religion;

$address = @$profile->address;
$province_name = @$profile->province_name;
$district_name = @$profile->district_name;
$subdistrict_name = @$profile->subdistrict_name;
$zipcode = @$profile->zipcode;
$home_latitude = @$profile->home_latitude;
$home_longitude = @$profile->home_longitude;
?>
<!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">


                <?php //console($profile);?>
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        <div class="card">
                            <div class="card-body">
                                <center class="m-t-30"> <img src="<?php echo $profile_img;?>" class="img-circle" width="150" />
                                    <h4 class="card-title m-t-10"><?php echo $name_title;?> <?php echo $firstname;?> <?php echo $lastname;?></h4>
                                    <h6 class="card-subtitle m-t-20">ปีการศึกษา 2562</h6>
                                    <h6 class="card-subtitle">ชั้นประถมศึกษาปีที่ 4 ห้อง 2</h6>
                                    <h6 class="card-subtitle m-t-20">คะแนนความประพฤติ 100 คะแนน</h6>
                                </center>
                            </div>
                            <div>
                                
                                <hr> 
                            </div>
                            <div class="card-body"> <h6 class="text-muted">ผู้ปกครอง : <span style="color:black;">
                                <?php echo @$parentContactPoint[0]->name;?></span></h6> 
                                <h6 class="text-muted p-t-10">เบอร์โทรศัพท์ : <span style="color:black;"><?php echo @$parentContactPoint[0]->cell_phone;?></span></h6> 
                            </div>
                            <div>
                                <hr> 
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs profile-tab" role="tablist">
                                <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#home" role="tab">ข้อมูลทั่วไป</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#family" role="tab">ผู้ปกครอง</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#time" role="tab">ลงเวลา</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#grade" role="tab">ผลการเรียน</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#behave" role="tab">ความประพฤติ</a> </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane active" id="home" role="tabpanel">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-12 col-xs-12 b-r m-b-10">
                                                <h6 class="m-t-10 text-muted">ปีการศึกษา 2562 <span class="p-l-10">จำนวนวันเรียนทั้งหมด  81 / 123 วัน </span></h6>
                                            </div>
                                            <div class="col-md-3 col-xs-6 b-r">
                                                <h6 class="m-t-10 text-success">มาเรียน 73 วัน<span class="pull-right">85%</span></h6>
                                                <div class="progress">
                                                    <div class="progress-bar bg-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width:90%; height:6px;"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-xs-6 b-r">
                                                <h6 class="m-t-10 text-primary">ขาด 8 วัน<span class="pull-right">85%</span></h6>
                                                <div class="progress">
                                                    <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width:10%; height:6px;"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-xs-6"> 
                                                <h6 class="m-t-10 text-danger">ลา 0 วัน<span class="pull-right">0%</span></h6>
                                                <div class="progress">
                                                    <div class="progress-bar bg-danger" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:0%; height:6px;"></div>
                                                </div>

                                            </div>
                                            <div class="col-md-3 col-xs-6">
                                                <h6 class="m-t-10 text-warning">สาย 2 วัน<span class="pull-right">3%</span></h6>
                                                <div class="progress">
                                                    <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:3%; height:6px;"> </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <hr> 
                                        </div>
                                        <div class="row">
                                               <div class="col-lg-6 col-md-6 col-xlg-2 col-xs-12">
                                                    <div class="ribbon-wrapper card">
                                                        <div class="ribbon ribbon-bookmark ribbon-primary ">ข้อมูลพื้นฐาน</div>
                                                        <form class="form-horizontal m-t-15" role="form">
                                                            <div class="form-body">
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-4 text-muted">รหัสนักเรียน</label>
                                                                            <div class="col-md-7">
                                                                                <p class="form-control-static"> <?php echo $student_no;?> </p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                    <div class="col-md-12">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-4 text-muted">ชื่อ</label>
                                                                            <div class="col-md-8">
                                                                                <p class="form-control-static"><?php echo $name_title_th.' '.$firstname_th.' '.$lastname_th;?></p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                    <div class="col-md-12">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-4 text-muted">Name</label>
                                                                            <div class="col-md-8">
                                                                                <p class="form-control-static"><?php echo $name_title_en.' '.$firstname_en.' '.$lastname_en;?></p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                </div>
                                                                <!--/row-->
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-4 text-muted">รหัสประชาชน</label>
                                                                            <div class="col-md-8">
                                                                                <p class="form-control-static"><?php echo $id_1;?>-<?php echo $id_2;?>-<?php echo $id_3;?>-<?php echo $id_4;?>-<?php echo $id_5;?></p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                    <div class="col-md-12">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-4 text-muted">กรุ๊ปเลือด</label>
                                                                            <div class="col-md-8">
                                                                                <p class="form-control-static"><?php echo $blood_type;?></p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                    <div class="col-md-12">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-4 text-muted">วันเกิด</label>
                                                                            <div class="col-md-8">
                                                                                <p class="form-control-static"><?php echo $birthdate;?></p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                    <div class="col-md-12">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-4 text-muted">เพิ่มเติม</label>
                                                                            <div class="col-md-8">
                                                                                <p class="form-control-static"><?php echo $congenital_disease;?></p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                    <div class="col-md-12">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-4 text-muted">สัญชาติ</label>
                                                                            <div class="col-md-8">
                                                                                <p class="form-control-static"><?php echo $nationality;?></p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                    <div class="col-md-12">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-4 text-muted">เชื้อชาติ</label>
                                                                            <div class="col-md-8">
                                                                                <p class="form-control-static"><?php echo $race;?></p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                    <div class="col-md-12">
                                                                        <div class="form-group row m-b-5">
                                                                            <label class="control-label text-left col-md-4 text-muted">ศาสนา</label>
                                                                            <div class="col-md-8">
                                                                                <p class="form-control-static"><?php echo $religion;?></p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!--/span-->
                                                                </div>
                                                            </div>    
                                                        </form>
                                                    </div>
                                                </div> 
                                                <div class="col-lg-6 col-md-6 col-xlg-2 col-xs-12">
                                                    <div class="ribbon-wrapper card">
                                                            <div class="ribbon ribbon-bookmark ribbon-primary ">ข้อมูลที่อยู่</div>
                                                            <form class="form-horizontal m-t-15" role="form">
                                                                    <div class="form-body">
                                                                        <div class="row">
                                                                            <div class="col-md-12">
                                                                                <div class="form-group row m-b-5">
                                                                                    <label class="control-label text-left col-md-4 text-muted">ที่อยู่</label>
                                                                                    <div class="col-md-7">
                                                                                        <p class="form-control-static"><?php echo $address;?></p>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <!--/span-->
                                                                            <div class="col-md-12">
                                                                                <div class="form-group row m-b-5">
                                                                                    <label class="control-label text-left col-md-4 text-muted">ตำบล</label>
                                                                                    <div class="col-md-8">
                                                                                        <p class="form-control-static"><?php echo $subdistrict_name;?></p>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <!--/span-->
                                                                            <div class="col-md-12">
                                                                                <div class="form-group row m-b-5">
                                                                                    <label class="control-label text-left col-md-4 text-muted">อำเภอ</label>
                                                                                    <div class="col-md-8">
                                                                                        <p class="form-control-static"><?php echo $district_name;?></p>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <!--/span-->
                                                                        </div>
                                                                        <!--/row-->
                                                                        <div class="row">
                                                                            <div class="col-md-12">
                                                                                <div class="form-group row m-b-5">
                                                                                    <label class="control-label text-left col-md-4 text-muted">จังหวัด</label>
                                                                                    <div class="col-md-8">
                                                                                        <p class="form-control-static"><?php echo $province_name;?></p>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <!--/span-->
                                                                            <div class="col-md-12">
                                                                                <div class="form-group row m-b-5">
                                                                                    <label class="control-label text-left col-md-4 text-muted">รหัสไปรษณีย์</label>
                                                                                    <div class="col-md-8">
                                                                                        <p class="form-control-static"><?php echo $zipcode;?></p>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <!--/span-->
                                                                            <div class="col-md-12">
                                                                                <div class="form-group row m-b-5">
                                                                                    <label class="control-label text-left col-md-4 text-muted">แผนที่</label>
                                                                                    <div class="col-md-12 m-t-15">
                                                                                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d470029.1604841957!2d72.29955005258641!3d23.019996818380896!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e848aba5bd449%3A0x4fcedd11614f6516!2sAhmedabad%2C+Gujarat!5e0!3m2!1sen!2sin!4v1493204785508" width="100%" height="150" frameborder="0" style="border:0" allowfullscreen></iframe>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <!--/span-->
                                                                        </div>
                                                                    </div>    
                                                                </form>
                                                        </div>
                                                    </div> 
                                            </div>
                                        </div>    
                                </div>
                                <!--second tab-->
                                <div class="tab-pane" id="family" role="tabpanel">
                                    <?php 
                                    //console($parentFather);
                                    ?>
                                    <div class="card-body">
                                        <table class="table color-table primary-table">
                                            <thead>
                                                <tr>
                                                    <th style="width:20%;">สถานะ</th>
                                                    <th style="width:40%;">ชื่อ - สกุล</th>
                                                    <th style="width:40%;">เบอร์โทรศัพท์</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>บิดา</td>
                                                    <td><?php echo @$parentFather[0]->name;?></td>
                                                    <td><?php echo @$parentFather[0]->cell_phone;?></td>
                                                </tr>
                                                <tr>
                                                    <td>มารดา</td>
                                                    <td><?php echo @$parentMother[0]->name;?></td>
                                                    <td><?php echo @$parentMother[0]->cell_phone;?></td>
                                                </tr>
                                                <tr>
                                                    <td>ผู้ปกครอง</td>
                                                    <td><?php echo @$parentContactPoint[0]->name;?></td>
                                                    <td><?php echo @$parentContactPoint[0]->cell_phone;?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <hr>
                                    </div>
                                </div>
                                <!--third tab-->
                                <div class="tab-pane" id="time" role="tabpanel">
                                    <?php 
                                    //console($timesheetLate);
                                    ?>
                                    <div class="card">
                                        <div class="card-body" id="accordian-3">
                                            <div class="card">
                                                <div class="card-header bg-primary">
                                                    <span class="m-b-0 text-white">วันที่สาย</span> 
                                                    <a style="float:right;cursor: pointer;color:white;" id="heading11" data-toggle="collapse" data-target="#collapse1" aria-expanded="false" aria-controls="collapse1">แสดง</a>
                                                </div>
                                                <div id="collapse1" class="collapse show" aria-labelledby="heading11" data-parent="#accordian-3" style="">
                                                    <div class="card-body">
                                                        <table class="table color-table primary-table">
                                                            <tbody class="text-muted">
                                                                <?php 
                                                                if(isset($timesheetLate->log_checkin)&&!empty($timesheetLate->log_checkin))
                                                                {
                                                                    foreach($timesheetLate->log_checkin as $row)
                                                                    {
                                                                ?>
                                                                    <tr>
                                                                        <td><?php echo $row->date;?></td>
                                                                        <td><?php echo $row->checkin_time;?></td>
                                                                        <td><?php echo $row->checkout_time;?></td>
                                                                    </tr>
                                                                <?php
                                                                    }
                                                                }
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card">
                                                <div class="card-header bg-danger">
                                                    <span class="m-b-0 text-white">วันที่ลา</span> 
                                                    <a style="float:right;cursor: pointer;color:white;" id="heading22" data-toggle="collapse" data-target="#collapse2" aria-expanded="false" aria-controls="collapse2">แสดง</a>
                                                </div>
                                                <div id="collapse2" class="collapse" aria-labelledby="heading22" data-parent="#accordian-3" style="">
                                                    <div class="card-body">
                                                        <table class="table color-table primary-table">
                                                            <tbody class="text-muted">
                                                                <tr>
                                                                    <td>ไม่มีข้อมูล</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card">
                                                <div class="card-header bg-success">
                                                    <span class="m-b-0 text-white">วันที่มาเรียน</span> 
                                                    <a style="float:right;cursor: pointer;color:white;" id="heading33" data-toggle="collapse" data-target="#collapse3" aria-expanded="false" aria-controls="collapse2">แสดง</a>
                                                </div>
                                                <div id="collapse3" class="collapse" aria-labelledby="heading33" data-parent="#accordian-3" style="">
                                                    <div class="card-body">
                                                        <table class="table color-table primary-table">
                                                            <tbody>
                                                                <tr>
                                                                    <td style="width:30%;">วันที่บันทึก</td>
                                                                    <td style="width:30%;">เวลาเข้า</td>
                                                                    <td style="width:40%;">เวลาออก</td>
                                                                </tr>
                                                                <tr class="text-muted">
                                                                    <td>30 สิงหาคม 2562</td>
                                                                    <td>08:11:16</td>
                                                                    <td>15:44:01</td>
                                                                </tr>
                                                                <tr class="text-muted">
                                                                    <td>29 สิงหาคม 2562</td>
                                                                    <td>06:41:57</td>
                                                                    <td>15:35:35</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- fourth -->
                                <div class="tab-pane" id="grade" role="tabpanel">
                                <div class="card-body">
                                        <!-- now grade -->
                                        <div class="ribbon-wrapper card">
                                        <div class="ribbon ribbon-bookmark ribbon-success ">ผลการเรียน ชั้นประถมศึกษาปีที่ 4 ปี เทอม 1 ปีการศึกษา 2562</div>
                                        <h4 class="card-title"></h4>
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead>
                                                        <tr class="text-success">
                                                            <th style="width:15%;">รหัสวิชา</th>
                                                            <th style="width:50%;">ชื่อวิชา</th>
                                                            <th style="width:15%;">กลางภาค</th>
                                                            <th style="width:15%;">ปลายภาค</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="text-muted">
                                                        <tr>
                                                            <td>ท101</td>
                                                            <td>ภาษาไทย</td>
                                                            <td>35/50</td>
                                                            <td>43/50</td>
                                                        </tr>
                                                        <tr>
                                                            <td>ค101</td>
                                                            <td>คณิตศาสตร์</td>
                                                            <td>35/50</td>
                                                            <td>43/50</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <!-- now grade-->
                                        <!-- now grade -->
                                        <div class="ribbon-wrapper card">
                                        <div class="ribbon ribbon-bookmark ribbon-success ">ผลการเรียน ชั้นประถมศึกษาปีที่ 4 ปี เทอม 2 ปีการศึกษา 2562</div>
                                        <h4 class="card-title"></h4>
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead>
                                                        <tr class="text-success">
                                                            <th style="width:15%;">รหัสวิชา</th>
                                                            <th style="width:50%;">ชื่อวิชา</th>
                                                            <th style="width:15%;">กลางภาค</th>
                                                            <th style="width:15%;">ปลายภาค</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="text-muted">
                                                        <tr>
                                                            <td>ท101</td>
                                                            <td>ภาษาไทย</td>
                                                            <td>35/50</td>
                                                            <td>43/50</td>
                                                        </tr>
                                                        <tr>
                                                            <td>ค101</td>
                                                            <td>คณิตศาสตร์</td>
                                                            <td>35/50</td>
                                                            <td>43/50</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <!-- now grade-->
                                        <!-- list grade -->
                                        <div class="ribbon-wrapper card">
                                        <div class="ribbon ribbon-bookmark ribbon-primary ">ผลการศึกษา</div>
                                        <h4 class="card-title"></h4>
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead>
                                                        <tr class="text-primary">
                                                            <th style="width:30%;">ระดับชั้น</th>
                                                            <th style="width:20%;">ปีการศึกษา</th>
                                                            <th style="width:20%;">ผลการศึกษา เทอม 1</th>
                                                            <th style="width:20%;">ผลการศึกษา เทอม 2</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="text-muted">
                                                        <tr>
                                                            <td>ประถมศึกษาปีที่ 1</td>
                                                            <td>2559</td>
                                                            <td>89.0</td>
                                                            <td>89.0</td>
                                                        </tr>
                                                        <tr>
                                                            <td>ประถมศึกษาปีที่ 2</td>
                                                            <td>2560</td>
                                                            <td>86.0</td>
                                                            <td>89.0</td>
                                                        </tr>
                                                        <tr>
                                                            <td>ประถมศึกษาปีที่ 3</td>
                                                            <td>2561</td>
                                                            <td>93.2</td>
                                                            <td>89.0</td>
                                                        </tr>
                                                        <tr>
                                                            <td>ประถมศึกษาปีที่ 4</td>
                                                            <td>2562</td>
                                                            <td>-</td>
                                                            <td>-</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <!-- list grade -->
                                        
                                    </div>
                                </div>
                                <!-- fourth -->
                                <!-- fifth -->
                                <div class="tab-pane" id="behave" role="tabpanel">
                                <div class="card-body">
                                        <div class="card-body">
                                            <h4><span class="text-purple"><i class="far fa-meh" style="font-size:24px;" aria-hidden="true"></i> คะแนนความประพฤติ <?php echo @$point;?> คะแนน</span></h4>
                                        </div>
                                        <!-- list grade -->
                                        <div class="card">
                                                <div class="card-header bg-cyan">
                                                    <span class="m-b-0 text-white"><i class="far fa-grin" aria-hidden="true" style="font-size:24px;"></i> เพิ่มคะแนนความประพฤติ</span> 
                                                </div>
                                                <div>
                                                    <div class="card-body">
                                                        <table class="table color-table primary-table">
                                                            <tbody class="text-muted">
                                                                <?php 
                                                                if(isset($behaviorLogPlus)&&!empty($behaviorLogPlus))
                                                                {
                                                                    //console($behaviorLogPlus);
                                                                    foreach($behaviorLogPlus->logs as $row)
                                                                    {
                                                                ?>
                                                                <tr>
                                                                    <td width=50%><?php echo $row->reason;?></td>
                                                                    <td><?php echo $row->point;?></td>
                                                                    <td width=25%><?php echo $row->created_date;?></td>
                                                                    <td width=10%><a href="#" data-toggle="tooltip" data-original-title="ลบ" class="img-responsive" > <i class="fa fa-close text-danger"></i></a></td>
                                                                </tr>
                                                                <?php 
                                                                    }
                                                                }    
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                        </div>
                                        <!-- list grade -->
                                        <!-- now grade -->
                                        <div class="card">
                                                <div class="card-header bg-primary">
                                                <span class="m-b-0 text-white"><i class="far fa-frown" aria-hidden="true" style="font-size:24px"></i> หักคะแนนความประพฤติ</span>
                                                </div>
                                                <div id="collapse1" class="collapse show" aria-labelledby="heading11" data-parent="#accordian-3" style="">
                                                    <div class="card-body">
                                                        <table class="table color-table primary-table">
                                                            <tbody class="text-muted">
                                                                <?php 
                                                                if(isset($behaviorLogMinus)&&!empty($behaviorLogMinus))
                                                                {
                                                                    foreach($behaviorLogMinus->logs as $row)
                                                                    {
                                                                ?>
                                                                <tr>
                                                                    <td width=50%><?php echo $row->reason;?></td>
                                                                    <td><?php echo $row->point;?></td>
                                                                    <td width=25%><?php echo $row->created_date;?></td>
                                                                    <td width=10%><a href="#" data-toggle="tooltip" data-original-title="ลบ" class="img-responsive" > <i class="fa fa-close text-danger"></i></a></td>
                                                                </tr>
                                                                <?php 
                                                                    }
                                                                }    
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                        </div>
                                        <!-- now grade-->
                                    </div>
                                </div>
                                <!-- fifth -->
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <div class="right-sidebar">
                    <div class="slimscrollright">
                        <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
                        <div class="r-panel-body">
                            <ul id="themecolors" class="m-t-20">
                                <li><b>With Light sidebar</b></li>
                                <li><a href="javascript:void(0)" data-skin="skin-default" class="default-theme working">1</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-green" class="green-theme">2</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-red" class="red-theme">3</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-blue" class="blue-theme">4</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-purple" class="purple-theme">5</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-megna" class="megna-theme">6</a></li>
                                <li class="d-block m-t-30"><b>With Dark sidebar</b></li>
                                <li><a href="javascript:void(0)" data-skin="skin-default-dark" class="default-dark-theme ">7</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-green-dark" class="green-dark-theme">8</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-red-dark" class="red-dark-theme">9</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-blue-dark" class="blue-dark-theme">10</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-purple-dark" class="purple-dark-theme">11</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-megna-dark" class="megna-dark-theme ">12</a></li>
                            </ul>
                            <ul class="m-t-20 chatonline">
                                <li><b>Chat option</b></li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/1.jpg" alt="user-img" class="img-circle"> <span>Varun Dhavan <small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/2.jpg" alt="user-img" class="img-circle"> <span>Genelia Deshmukh <small class="text-warning">Away</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/3.jpg" alt="user-img" class="img-circle"> <span>Ritesh Deshmukh <small class="text-danger">Busy</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/4.jpg" alt="user-img" class="img-circle"> <span>Arijit Sinh <small class="text-muted">Offline</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/5.jpg" alt="user-img" class="img-circle"> <span>Govinda Star <small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/6.jpg" alt="user-img" class="img-circle"> <span>John Abraham<small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/7.jpg" alt="user-img" class="img-circle"> <span>Hritik Roshan<small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/8.jpg" alt="user-img" class="img-circle"> <span>Pwandeep rajan <small class="text-success">online</small></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>