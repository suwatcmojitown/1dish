<thead>
    <tr>
        <th style="width:5%;">#</th>
        <th style="width:60%;">ชื่อ - นามสกุล</th>
    </tr>
</thead>
<tbody class="text-muted" >
<?php 
foreach($parent as $row)
{
?>                                                                                      
<tr>
            <td class="text-nowrap" style="font-size: 17px;">
            <input type="radio" class="parent" id="<?php echo $row->id;?>" value="<?php echo $row->id;?>" name="parent[]">
            </td>
            <td class="p-t-20"><?php echo $row->name?></td>
</tr>
<?php
}
?>
</tbody>

<script type="text/javascript">    
   $( "#addFatherBtn").click(function() {
        var a = $('.parent:checked').val();
        alert(a);
        /*
        $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'student/addParent'?>',
               data: 'parent_id='+a+'&type=<?php echo $type;?>&student_id=<?php echo $student_id;?>&is_parent=0',
               success: function(result) {
                   //alert(result);
                   //$('#parentList').html(result);
               }
           });  
        */       
   });

   $( "#addMotherBtn").click(function() {
        var a = $('.parent:checked').val();
        alert(a);
        $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'student/addParent'?>',
               data: 'parent_id='+a+'&type=<?php echo $type;?>&student_id=<?php echo $student_id;?>&is_parent=0',
               success: function(result) {
                   //alert(result);
                   //$('#parentList').html(result);
               }
           });      
   });

   $( "#addParentBtn").click(function() {
        var a = $('.parent:checked').val();
        $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'student/addParent'?>',
               data: 'parent_id='+a+'&type=<?php echo $type;?>&student_id=<?php echo $student_id;?>&is_parent=1',
               success: function(result) {
                   //alert(result);
                   //$('#parentList').html(result);
               }
           });      
   });
</script>
