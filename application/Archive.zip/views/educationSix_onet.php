
 
                                                                        <div class="modal-content">
                                                                            <div class="modal-header alert-danger">
                                                                                <h4 class="modal-title"><i class="fa fa-mixcloud"></i> O-NET</h4>
                                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                            </div>
                                                                            <div class="modal-body">
                                                                                <form method="post" action="<?php echo base_url('setting/updateOnetScore/'.$student_id.'/'.$academic_year.'');?>" >
                                                                                    <?php
                                                                                    //console($onetScore->score);
                                                                                    if(isset($onetScore->score)&&!empty($onetScore->score)){
                                                                                        foreach($onetScore->score as $row){
                                                                                    ?>
                                                                                    <div class="row">
                                                                                                        <div class="col-md-6 text-danger" style="padding-top: 7px;">
                                                                                                                <?php echo $row->name_th;?>
                                                                                                        </div>
                                                                                                        <div class="col-md-5">
                                                                                                            <input type="text" class="form-control text-muted" placeholder="คะแนน" id="<?php echo $row->subject_id?>" name="<?php echo $row->subject_id?>" value="<?php echo $row->score?>">
                                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-t-10"></div>
                                                                                    <?php 
                                                                                        }
                                                                                    }
                                                                                    ?>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <div class="text-right m-b-10">
                                                                                            <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                                            <button type="submit" id="addScore" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                                    </div>
                                                                                </form>    
                                                                            </div>
                                                                                
                                                                        </div>
 
