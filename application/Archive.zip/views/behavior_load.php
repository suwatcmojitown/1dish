<table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <th style="width:40%;">ชื่อ</th>
                                                    <th style="width:15%;">ประเภท</th>
                                                    <th style="width:15%;">คะแนน</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                if(isset($result)&&!empty($result))
                                                {
                                                    $i = 1;
                                                    foreach($result as $row)
                                                    {
                                                ?>
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo $row->title;?></td>
                                                    <td><?php echo $row->point_type;?></td>
                                                    <td><?php echo $row->point;?></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="ดู"> <i class="fa fa-pencil text-success m-r-10"></i> </a>
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" > <i class="fa fa-close text-danger"></i> </a>
                                                    </td>
                                                </tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>