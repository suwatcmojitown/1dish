
<!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">
                            <?php 
                            //console($subjectProfile->subjectlist[0]);
                            ?>
                            <div class="card-body">
                            <div class="ribbon-wrapper">
                                    <div class="ribbon ribbon-success">วิชา : <?php echo @$subjectProfile->subjectlist[0]->name_th.' '.@$subjectProfile->subjectlist[0]->subject_id;?></div>
                                </div>
                                <div class="row m-b-15">
                                        <?php 
                                        //console($subjectProfile->subjectlist[0]);
                                        ?>
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <div class="col-md-3 col-xs-6 b-r"> <strong>ชั้นเรียน</strong>
                                                    <br>
                                                    <p class="text-muted m-t-5"><?php echo @$subjectProfile->subjectlist[0]->education_sublevel_name_th;?></p>
                                                </div>
                                                <div class="col-md-3 col-xs-6 b-r"> <strong>กลุ่มสาระ</strong>
                                                    <br>
                                                    <p class="text-muted m-t-5"><?php echo @$subjectProfile->subjectlist[0]->subject_group_name_th;?></p>
                                                </div>
                                                <div class="col-md-3 col-xs-6 b-r"> <strong>ประเภท</strong>
                                                    <br>
                                                    <p class="text-muted m-t-5"><?php echo @$subjectProfile->subjectlist[0]->subject_type_name_th;?></p>
                                                </div>
                                                <div class="col-md-3 col-xs-6 m-t-5"> <strong>หน่วยกิจ</strong>
                                                    <br>
                                                    <p class="text-muted"><?php echo @$subjectProfile->subjectlist[0]->unit;?></p>
                                                </div>
                                            </div>
                                            <!--
                                            <div class="m-b-20"></div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                        <input type="text" id="search" name="search" class="form-control" placeholder="กรอกคำค้นหา">
                                                </div>
                                                <div class="col-md-2">
                                                      <button type="button" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>
                                            </div>
                                            -->
                                        </div>
                                </div>
                                
                                <div class="table-responsive dataTables_wrapper">
                                    <table class="table color-table purple-table">
                                        <thead>
                                            <tr>
                                                <th>เทอม </th>
                                                <th>คะแนนเก็บ</th>
                                                <th>คะแนนกลางภาค</th>
                                                <th>คะแนนปลายภาค</th>
                                                <th>เทอม </th>
                                                <th>คะแนนเก็บ</th>
                                                <th>คะแนนกลางภาค</th>
                                                <th>คะแนนปลายภาค</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>เทอม 1</td>
                                                <td><?php echo @$subjectProfile->subjectlist[0]->term_1_test_score;?></td>
                                                <td><?php echo @$subjectProfile->subjectlist[0]->term_1_midterm_score;?></td>
                                                <td><?php echo @$subjectProfile->subjectlist[0]->term_1_finalterm_score;?></td>
                                                <td>เทอม 2</td>
                                                <td><?php echo @$subjectProfile->subjectlist[0]->term_2_test_score;?></td>
                                                <td><?php echo @$subjectProfile->subjectlist[0]->term_2_midterm_score;?></td>
                                                <td><?php echo @$subjectProfile->subjectlist[0]->term_2_finalterm_score;?></td>
                                                <td class="text-nowrap" style="font-size: 17px;">
                                                    <a href="javascript:void(0)" data-toggle="modal" data-target="#responsive-modal"> <i class="fa fa-pencil text-warning"></i> </a>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>        
                            <!-- modal -->
                            <div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                                    <div class="modal-dialog modal-md" >
                                                                        <div class="modal-content">
                                                                            <div class="modal-header alert-success">
                                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> ตั้งค่าคะแนน</h4>
                                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                            </div>
                                                                            
                                                                            <div class="modal-body">
                                                                                <?php 
                                                                                //console($personnelList);
                                                                                ?>
                                                                                <form method="post" action="<?php echo base_url('setting/subjectUpdateScore')?>" >
                                                                                    <input type="hidden" id="academic_year" name="academic_year" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->academic_year;?>">
                                                                                    <input type="hidden" id="subject_id" name="subject_id" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->id;?>">
                                                                                <div class="card border-warning">
                                                                                
                                                                                <div class="card-header bg-success m-b-15">
                                                                                    <h4 class="m-b-0 text-white">เทอม 1</h4>
                                                                                </div>
                            
                                                                                    <div class="row">
                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                            คะแนนเก็บ
                                                                                        </div>
                                                                                        <div class="col-md-7" id="subjectGroup_div">
                                                                                            <input type="text" id="term_1_test_score" name="term_1_test_score" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->term_1_test_score;?>">
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-b-15"></div> 
                                                                                    <div class="row">
                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                            คะแนนกลางภาค
                                                                                        </div>
                                                                                        <div class="col-md-7" id="subjectGroup_div">
                                                                                        <input type="text" id="term_1_midterm_score" name="term_1_midterm_score" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->term_1_midterm_score;?>">        
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-b-15"></div> 
                                                                                    <div class="row">
                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                            คะแนนปลายภาค
                                                                                        </div>
                                                                                        <div class="col-md-7" id="subjectGroup_div">
                                                                                        <input type="text" id="term_1_finalterm_score" name="term_1_finalterm_score" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->term_1_finalterm_score;?>">        
                                                                                        </div>
                                                                                    </div>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <div class="card-header bg-success m-b-15">
                                                                                    <h4 class="m-b-0 text-white">เทอม 2</h4>
                                                                                </div>
                            
                                                                                    <div class="row">
                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                            คะแนนเก็บ
                                                                                        </div>
                                                                                        <div class="col-md-7" id="subjectGroup_div">
                                                                                            <input type="text" id="term_2_test_score" name="term_2_test_score" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->term_2_test_score;?>">
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-b-15"></div> 
                                                                                    <div class="row">
                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                            คะแนนกลางภาค
                                                                                        </div>
                                                                                        <div class="col-md-7" id="subjectGroup_div">
                                                                                        <input type="text" id="term_2_midterm_score" name="term_2_midterm_score" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->term_2_midterm_score;?>">        
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-b-15"></div> 
                                                                                    <div class="row">
                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                            คะแนนปลายภาค
                                                                                        </div>
                                                                                        <div class="col-md-7" id="subjectGroup_div">
                                                                                        <input type="text" id="term_2_finalterm_score" name="term_2_finalterm_score" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->term_2_finalterm_score;?>">        
                                                                                        </div>
                                                                                    </div>
                                                                                    <div style="margin-top:21px;"></div>     
                                                                                    
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <div class="text-right m-b-10">
                                                                                            <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                                            <button type="submit" id="addPersonnelBtn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                                    </div>
                                                                                </form>    
                                                                            </div>
                                                                                
                                                                        </div>
                                                                    </div>
                                                                    </div>
                                </div>
                                <!-- modal -->
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
  