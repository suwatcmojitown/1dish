<body class="skin-default fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label">Elite admin</p>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <!-- ============================================================== -->
                <!-- Logo -->
                <!-- ============================================================== -->
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.html">
                        <!-- Logo icon --><b>
                            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                            <!-- Dark Logo icon -->
                            <img src="<?php echo base_url();?>assets/images/logo-icon.png" alt="homepage" class="dark-logo" />
                            <!-- Light Logo icon -->
                            <img src="<?php echo base_url();?>assets/images/logo-light-icon.png" alt="homepage" class="light-logo" />
                        </b>
                        <!--End Logo icon -->
                        <!-- Logo text --><span>
                         <!-- dark Logo text -->
                         <img src="<?php echo base_url();?>assets/images/logo-text.png" alt="homepage" class="dark-logo" />
                         <!-- Light Logo text -->    
                         <img src="<?php echo base_url();?>assets/images/logo-light-text.png" class="light-logo" alt="homepage" /></span> </a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav mr-auto">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link nav-toggler d-block d-md-none waves-effect waves-dark" href="javascript:void(0)"><i class="ti-menu"></i></a> </li>
                        <li class="nav-item"> <a class="nav-link sidebartoggler d-none d-lg-block d-md-block waves-effect waves-dark" href="javascript:void(0)"><i class="icon-menu"></i></a> </li>
                        <!-- ============================================================== -->
                        <!-- Search -->
                        <!-- ============================================================== -->
                    </ul>
                    <!-- ============================================================== -->
                    <!-- User profile and search -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav my-lg-0">
                        <!-- ============================================================== -->
                        <!-- End mega menu -->
                        <!-- ============================================================== -->
                        <li class="nav-item right-side-toggle"> <a class="nav-link  waves-effect waves-light" href="javascript:void(0)"><i class="ti-settings"></i></a></li>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- User Profile-->
                <?php 
                $permission = $this->session->userdata['role'];
                ?>
                <div class="user-profile">
                    <div class="user-pro-body">
                        <div><img src="<?php echo @$this->session->userdata['thumbnail'];?>" alt="user-img" class="img-circle"></div>
                        <div class="dropdown">
                            <a href="javascript:void(0)" class="dropdown-toggle u-dropdown link hide-menu" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $this->session->userdata['name'];?> <span class="caret"></span></a>
                            <div class="dropdown-menu animated flipInY">
                                <!-- text-->
                                <a href="<?php echo base_url('changepassword');?>" class="dropdown-item"><i class="fa fa-wrench"></i> เปลี่ยน password</a>
                                <a href="<?php echo base_url('logout');?>" class="dropdown-item"><i class="fa fa-power-off"></i> Logout</a>
                                <!-- text-->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                <?php //console($data_menu);?>
                    <ul id="sidebarnav">
                        <?php 
                        if(($permission=='Super Admin')||($permission=='Admin'))
                        {
                        ?>
                        <li class="nav-small-cap" style="font-size:14px;">--- ข้อมูล</li>
                        <li <?php if($data_menu['active']=='dashboard') echo 'class="active"';?> > <a class="waves-dark" href="<?php echo base_url('dashboard');?>" aria-expanded="false"><i class="fa fa-book"></i><span class="hide-menu">Dashboard<span class="badge badge-pill badge-cyan ml-auto"></span></span></a></li>
                        <li <?php if($data_menu['active']=='timesheet') echo 'class="active"';?> > <a class="waves-dark" href="<?php echo base_url('timesheet/list');?>" aria-expanded="false"><i class="fa fa-briefcase"></i><span class="hide-menu">สรุปเวลาเข้าเรียน<span class="badge badge-pill badge-cyan ml-auto"></span></span></a></li>
                        <li <?php if($data_menu['active']=='hr') echo 'class="active"';?>> <a class="waves-dark" href="<?php echo base_url('hr/createEvent');?>" aria-expanded="false"><i class="fa fa-clock-o"></i><span class="hide-menu">แจ้ง สาย/กลับก่อน<span class="badge badge-pill badge-cyan ml-auto"></span></span></a></li>
                        <li <?php if($data_menu['active']=='behavior') echo 'class="active"';?>> <a class="waves-dark" href="<?php echo base_url('behavior/createEvent');?>" aria-expanded="false"><i class="fa fa-thumbs-o-up"></i><span class="hide-menu">+ - คะแนนพฤิตกรรม <span class="badge badge-pill badge-cyan ml-auto"></span></span></a></li>
                        <li <?php if($data_menu['active']=='personnel') echo 'class="active"';?> > <a class="waves-dark" href="<?php echo base_url('personnel/profile/').@$this->session->userdata['personnel_id'];?>" aria-expanded="false"><i class="fa fa-address-book-o"></i><span class="hide-menu">ข้อมูลครู<span class="badge badge-pill badge-cyan ml-auto"></span></span></a></li>
                        <li <?php if($data_menu['active']=='device') echo 'class="active"';?>> <a class="waves-dark" href="<?php echo base_url('device/list');?>" aria-expanded="false"><i class="fa fa-h-square"></i><span class="hide-menu">Health Check <span class="badge badge-pill badge-cyan ml-auto"></span></span></a></li>
                        <?php 
                        }
                        if($permission=='Super Admin'){?>
                        <li class="nav-small-cap" style="font-size:14px;">--- ตั้งค่า</li>
                        <li <?php if($data_menu['active']=='academicyear') echo 'class="active"';?> > <a class="waves-dark" href="<?php echo base_url('setting/academicYearList');?>" aria-expanded="false"><i class="fa fa-briefcase"></i><span class="hide-menu">เทอม / ปีการศึกษา <span class="badge badge-pill badge-cyan ml-auto"></span></span></a></li>
                        <li <?php if($data_menu['active']=='subject') echo 'class="active"';?>> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="fa fa-file-text-o"></i><span class="hide-menu">วิชา <span class="badge badge-pill badge-cyan ml-auto">3</span></span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li <?php if($data_menu['sub_active']=='subjectType') echo 'class="active"';?>><a href="<?php echo base_url('setting/subjectTypeList');?>">ประเภทวิชา</a></li>
                                <li <?php if($data_menu['sub_active']=='subjectGroup') echo 'class="active"';?>><a href="<?php echo base_url('setting/subjectGroupList');?>">กลุ่มสาระ</a></li>
                                <li <?php if($data_menu['sub_active']=='subject') echo 'class="active"';?>><a href="<?php echo base_url('setting/subjectList');?>">วิชา</a></li>
                            </ul>
                        </li>
                        <li <?php if($data_menu['active']=='personnel') echo 'class="active"';?>> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="fa fa-user-md"></i><span class="hide-menu">บุคลากร <span class="badge badge-pill badge-cyan ml-auto">2</span></span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li <?php if($data_menu['sub_active']=='personnelGroup') echo 'class="active"';?>><a href="<?php echo base_url('setting/personnelGroupList');?>">กลุ่มบุคลากร</a></li>
                                <li <?php if($data_menu['sub_active']=='personnel') echo 'class="active"';?>><a href="<?php echo base_url('setting/personnelList');?>">บุคลากร</a></li>
                            </ul>
                        </li>
                        <li <?php if($data_menu['active']=='classroom') echo 'class="active"';?>> <a class="waves-dark" href="<?php echo base_url('setting/classroomList');?>" aria-expanded="false"><i class="fa fa-fort-awesome"></i><span class="hide-menu">ชั้นเรียน <span class="badge badge-pill badge-cyan ml-auto"></span></span></a></li>
                        <li <?php if($data_menu['active']=='parent') echo 'class="active"';?>> <a class="waves-dark" href="<?php echo base_url('setting/parentList');?>" aria-expanded="false"><i class="fa fa-male"></i><span class="hide-menu">ผู้ปกครอง <span class="badge badge-pill badge-cyan ml-auto"></span></span></a></li>
                        <li <?php if($data_menu['active']=='student') echo 'class="active"';?>> <a class="waves-dark" href="<?php echo base_url('setting/studentList');?>" aria-expanded="false"><i class="fa fa-child"></i><span class="hide-menu">นักเรียน <span class="badge badge-pill badge-cyan ml-auto"></span></span></a></li>
                        <li <?php if($data_menu['active']=='behavior') echo 'class="active"';?>> <a class="waves-dark" href="<?php echo base_url('setting/behaviorList');?>" aria-expanded="false"><i class="fa fa-thumbs-o-up"></i><span class="hide-menu">คะแนนพฤติกรรม <span class="badge badge-pill badge-cyan ml-auto"></span></span></a></li>
                        <li <?php if($data_menu['active']=='rank') echo 'class="active"';?>> <a class="waves-dark" href="<?php echo base_url('setting/rankList');?>" aria-expanded="false"><i class="fa fa-signal"></i><span class="hide-menu">ระดับการตัดเกรด <span class="badge badge-pill badge-cyan ml-auto"></span></span></a></li>
                        <?php 
                        }
                        ?>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->

        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
               <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor"><?php echo $data_menu['subcat_menu_th']?></h4>
                    </div>    
                    
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb" style="font-size:14px;">
                                <li class="breadcrumb-item"><a href="<?php echo base_url();?>">หน้าหลัก</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo base_url('/').$data_menu['cat_menu'];?>"><?php echo $data_menu['cat_menu_th'];?></a></li>
                                <li class="breadcrumb-item active"><?php echo $data_menu['subcat_menu_th']?></li>
                            </ol>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->