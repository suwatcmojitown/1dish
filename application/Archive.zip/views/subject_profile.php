<!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <div class="text-right m-b-10">
                                        <button class="btn btn-success" type="submit" data-toggle="modal" data-target="#responsive-modal"> <span><i class="fa fa-file-o"></i> เพิ่มอาจารย์ประจำวิชา</span> </button>
                                </div>
                                
                                <hr class="m-t-0 m-b-20">
                                
                                <div class="row m-b-15">
                                        <?php 
                                        //console($profile);
                                        ?>
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <div class="col-md-3 col-xs-6 b-r"> <strong>ชั้นเรียน</strong>
                                                    <br>
                                                    <p class="text-muted m-t-5"><?php echo @$profile->education_sublevel_name_th;?></p>
                                                </div>
                                                <div class="col-md-3 col-xs-6 b-r"> <strong>กลุ่มสาระ</strong>
                                                    <br>
                                                    <p class="text-muted m-t-5"><?php echo @$profile->subject_group_name_th;?></p>
                                                </div>
                                                <div class="col-md-3 col-xs-6 b-r"> <strong>ประเภท</strong>
                                                    <br>
                                                    <p class="text-muted m-t-5"><?php echo @$profile->subject_type_name_th;?></p>
                                                </div>
                                                <div class="col-md-3 col-xs-6 m-t-5"> <strong>หน่วยกิจ</strong>
                                                    <br>
                                                    <p class="text-muted"><?php echo @$profile->unit;?></p>
                                                </div>
                                            </div>
                                            <!--
                                            <div class="m-b-20"></div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                        <input type="text" id="search" name="search" class="form-control" placeholder="กรอกคำค้นหา">
                                                </div>
                                                <div class="col-md-2">
                                                      <button type="button" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>
                                            </div>
                                            -->
                                        </div>
                                </div>
                                
                                
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper">
                                        <?php 
                                        //console($subjectOwner);
                                        ?>
                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <th style="width:30%;">ชื่อ - นามสกุล</th>
                                                    <th style="width:20%;">เบอร์โทรศัพท์</th>
                                                    <th style="width:20%;">รูปภาพ</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                if(isset($subjectOwner)&&!empty($subjectOwner)){
                                                $i = 1;
                                                foreach($subjectOwner as $row )
                                                {
                                                ?>
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo $row->name_th;?></td>
                                                    <td><?php echo $row->tel;?></td>
                                                    <td><img src="<?php echo $row->profile_img_url;?>" style="width:100px;"></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="ดู"> <i class="fa fa-eye text-success m-r-10"></i> </a>
                                                        <a href="<?php echo base_url('subject/delPersonnel').'?subject_id='.$subject_id.'&personnel_id='.$row->id;?>" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" > <i class="fa fa-close text-danger"></i> </a>
                                                    </td>
                                                </tr>
                                                <?php 
                                                    $i++;
                                                }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                       
                                    <hr>
                                    
                                </div>
                            </div>        
                            <!-- modal -->
                            <div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                                    <div class="modal-dialog modal-md" >
                                                                        <div class="modal-content">
                                                                            <div class="modal-header alert-success">
                                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> ค้นหารายชื่อ</h4>
                                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                            </div>
                                                                            
                                                                            <div class="modal-body">
                                                                                <?php 
                                                                                //console($personnelList);
                                                                                ?>
                                                                                <form method="post" action="cus_order_add.php" >
                                                                                    <div class="row">
                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                            อาจารย์ประจำวิชา
                                                                                        </div>
                                                                                        <div class="col-md-7" id="subjectGroup_div">
                                                                                                <select class="form-control custom-select text-muted" id="personnelSec" name="personnelSec">
                                                                                                                    <option value="0">--- เลือก ---</option>
                                                                                                                    <?php 
                                                                                                                    if(isset($personnelList)&&!empty($personnelList)){
                                                                                                                        foreach($personnelList as $row){
                                                                                                                    ?> 
                                                                                                                    <option value="<?php echo $row->id;?>"><?php echo $row->name_th;?></option>
                                                                                                                    <?php 
                                                                                                                        }
                                                                                                                    }    
                                                                                                                    ?>
                                                                                                </select>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <table class="table color-table primary-table" id="motherList">
                                                                                        
                                                                                        
                                                                                    </table>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <div class="text-right m-b-10">
                                                                                            <button type="canbel" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                                            <button type="button" id="addPersonnelBtn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                                    </div>
                                                                                </form>    
                                                                            </div>
                                                                                
                                                                        </div>
                                                                    </div>
                                </div>
                                <!-- modal -->
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

<script type="text/javascript">    
   $( "#addPersonnelBtn").click(function() {
            a = document.getElementById("personnelSec").value;
            $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'subject/addPersonnel'?>',
               data: 'personnel_id='+a+'&subject_id=<?php echo $subject_id;?>',
               success: function(result) {
                   //alert(result);
                   //$('#motherList').html(result);
               }
           });  
              
   });
</script>   