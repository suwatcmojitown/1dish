                                                <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" >ประเภท</label>
                                                                <div class="col-md-5">
                                                                    <select class="form-control custom-select text-muted" name="doctype_list" id="doctype_list">
                                                                        <option value="0">-- เลือกประเภท --</option>
                                                                        <?php 
                                                                        if(isset($data['doctype_list'])&&!empty($data['doctype_list']))
                                                                        {
                                                                            foreach($data['doctype_list'] as $row)
                                                                            {
                                                                        ?>    
                                                                                <option value="<?php echo $row['type_id'];?>"><?php echo $row['name'];?></option>
                                                                        <?php 
                                                                            }
                                                                        }
                                                                        ?>              
                                                                    </select>
                                                                    
                                                                </div>
                                                                <div class="offset-md-1 col-md-1">
                                                                    <button class="btn btn-info pull-left" id="add_doctype" type="button" data-toggle="modal" data-target="#doctype-responsive-modal"><i class="fa fa-plus"></i> เพิ่มประเภท</button>
                                                                </div>
                                                        </div>
                                                    </div>

                                                    
<!-- modal -->
<div id="doctype-responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                            <div class="modal-dialog modal-lg" >
                                                <div class="modal-content">
                                                    <div class="modal-header alert-success">
                                                        <h4 class="modal-title"><i class="mdi mdi-account-plus"></i> เพิ่มประเภท</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form method="post" action="cus_order_add.php" >
                                                            <div class="row">
                                                                <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                        ชื่อประเภท
                                                                </div>
                                                                <div class="col-md-5">
                                                                        <input type="text" name="type_title" id="type_title" class="form-control" placeholder="กรอกประเภทประกาศ" aria-describedby="search-txt">        
                                                                </div>
                                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                                        slug
                                                                </div>
                                                                <div class="col-md-3">
                                                                        <input type="text" name="type_slug" id="type_slug" class="form-control" placeholder="กรอก slug" aria-describedby="search-txt">        
                                                                </div>
                                                            </div>
                                                            <div style="margin-top:21px;"></div> 
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group row">
                                                                        <label class="control-label text-left col-md-2 text-success" style="padding-left: 14px;">หน่วยงาน</label>
                                                                        <div class="col-md-9">
                                                                            <div class="form-check form-check-inline text-muted">
                                                                                <input class="form-check-input" type="radio" name="is_department" id="type_1" value="1" checked>
                                                                                <label class="form-check-label" for="inlineRadio1">มี</label>
                                                                            </div>
                                                                            <div class="form-check form-check-inline text-muted">
                                                                                <input class="form-check-input" type="radio" name="is_department" id="type_2" value="0">
                                                                                <label class="form-check-label" for="inlineRadio2">ไม่มี</label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group row">
                                                                        <label class="control-label text-left col-md-2 text-success" style="padding-left: 14px;">สถานะ</label>
                                                                        <div class="col-md-9">
                                                                            <div class="form-check form-check-inline text-muted">
                                                                                <input class="form-check-input" type="radio" name="type_status" id="status_1" value="1" checked>
                                                                                <label class="form-check-label" for="inlineRadio1">ใช้งาน</label>
                                                                            </div>
                                                                            <div class="form-check form-check-inline text-muted">
                                                                                <input class="form-check-input" type="radio" name="type_status" id="status_2" value="0">
                                                                                <label class="form-check-label" for="inlineRadio2">ยกเลิก</label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div> 
                                                            <div class="text-right m-b-10">
                                                                <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                <button type="button" id="add_doctype_btn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                            </div>
                                                        </form>    
                                                    </div>
                                                        
                                                </div>
                                            </div>
</div>
<!-- modal -->


<script>
        
        $( "#doctype_list" ).change(function() {
            doc_id = document.getElementById("doctype_list").value;
            $.ajax({
                type: 'POST',
                url: 'load_department_create',
                data: 'doc_id='+doc_id,
                success: function(result) { 
                    $("#department").html(result);
                }
            });
            
        });
        

        $( "#add_doctype" ).click(function() {
            doc_id = document.getElementById("doctype_list").value;
            $.ajax({
                type: 'POST',
                url: 'load_doctypelist',
                data: 'doc_id='+doc_id,
                success: function(result) { 
                    $("#doctype_list").html(result);
                }
            });
        });

        $( "#add_doctype_btn" ).click(function() {
            is_department = $("input[name=is_department]:checked").val();
            type_status = $("input[name=type_status]:checked").val();
            type_title = document.getElementById("type_title").value;
            type_slug = document.getElementById("type_slug").value;
            doc_id = document.getElementById("doc_list").value;
            $.ajax({
                type: 'POST',
                url: 'add_doctype',
                data: 'title='+type_title+'&slug='+type_slug+'&is_department='+is_department+'&status='+type_status+'&doc_id='+doc_id,
                success: function(result) { 
                    location.reload();
                }
            });
        });         
</script>
