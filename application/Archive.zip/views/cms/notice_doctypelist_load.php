                                                
                                                        <?php 
                                                        if(isset($data['doctype_list'])&&!empty($data['doctype_list']))
                                                        {
                                                        ?>
                                                        <select class="form-control custom-select text-muted" id="type_id" name="type_id">
                                                                <option value="all">ทั้งหมด</option>
                                                            <?php 
                                                            foreach($data['doctype_list'] as $row)
                                                            {
                                                            ?>    
                                                                <option value="<?php echo $row['type_id'];?>"><?php echo $row['name'];?></option>
                                                            <?php 
                                                            }
                                                            ?>                
                                                        </select>
                                                        <?php 
                                                        }
                                                        ?>
                                                      

                                                <script>
$( "#type_id" ).change(function() {
            type_id = document.getElementById("type_id").value;
            $.ajax({
                type: 'POST',
                url: 'load_departmentlist',
                data: 'type_id='+type_id,
                success: function(result) {   
                    $("#department_list").html(result);
                }
            });
        });
</script>                                                
                                                