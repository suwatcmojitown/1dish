<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

 
<div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">เพิ่มหมวดหมู่</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">Create Category</li>
                            </ol>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <?php 
                        //console($data['result']);
                    ?>
                    <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <div class="text-right m-b-10">
                                        <a href="<?php echo base_url('cms/create_category');?>"><button class="btn btn-success" type="submit"> <span><i class="fa fa-file-o"></i>  เพิ่มหมวดหมู่</span> </button></a>
                                </div>
                                <hr class="m-t-0 m-b-20">
                                <div class="row m-b-15">
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <div class="col-md-1 text-primary" style="padding-top: 7px;">
                                                        หมวดหมู่
                                                </div>
                                                <div class="col-md-3">
                                                        <?php 
                                                        if(isset($data['cat_list'])&&!empty($data['cat_list']))
                                                        {
                                                        ?>
                                                        <select class="form-control custom-select text-muted" id="category_list" name="category_list">
                                                                            <option value="all">ทั้งหมด</option>
                                                            <?php 
                                                            foreach($data['cat_list'] as $row)
                                                            {
                                                            ?>    
                                                                <option value="<?php echo $row['slug'];?>"><?php echo $row['cat_name'];?></option>
                                                            <?php 
                                                            }
                                                            ?>                
                                                        </select>
                                                        <?php 
                                                        }
                                                        ?>
                                                                
                                                </div> 
                                                <div class="offset-md-1 col-md-2">
                                                      <button type="button" id="searchBtn" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                
                                <!--second tab-->
                                <!-- load content -->
                                <div class="table-responsive dataTables_wrapper" id="load_content">
                                        <table class="table color-table primary-table">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <th style="width:15%;">ชื่อ</th>
                                                    <th style="width:15%;">ตำแหน่ง</th>
                                                    <th style="width:25%;">ศูนย์</th>
                                                    <th style="width:10%;">สถานะ</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                if(isset($data['result'])&&!empty($data['result']))
                                                {
                                                    $i = 1;
                                                    foreach($data['result'] as $row)
                                                    {
                                                ?>
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo $row['name']?></td>
                                                    <td><?php echo $row['rank']?></td>
                                                    <td><?php echo $row['cat_name']?></td>
                                                    <td><?php if($row['status']=='1')echo 'ใช้งาน'; else echo 'ไม่ใช้งาน';?></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-danger"></i> </a>
                                                    </td>
                                                </tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>

                                       
                                    <div class="dataTables_paginate paging_simple_numbers" id="example23_paginate">
                                        <a class="paginate_button previous" aria-controls="example23" data-dt-idx="0" tabindex="0" id="example23_previous">ก่อนหน้า</a>
                                        <span><a class="paginate_button " aria-controls="example23" data-dt-idx="1" tabindex="0">1</a>
                                        <a class="paginate_button " aria-controls="example23" data-dt-idx="2" tabindex="0">2</a>
                                        <a class="paginate_button " aria-controls="example23" data-dt-idx="3" tabindex="0">3</a>
                                        <a class="paginate_button current" aria-controls="example23" data-dt-idx="4" tabindex="0">4</a>
                                        <a class="paginate_button " aria-controls="example23" data-dt-idx="5" tabindex="0">5</a>
                                        <a class="paginate_button " aria-controls="example23" data-dt-idx="6" tabindex="0">6</a></span>
                                        <a class="paginate_button next" aria-controls="example23" data-dt-idx="7" tabindex="0" id="example23_next">ถัดไป</a>
                                    </div>
                                    <hr>
                                    
                                </div>
                                <!-- load content -->
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- modal -->
                <div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog modal-md" >
                                                        <div class="modal-content">
                                                            <div class="modal-header alert-success">
                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> เพิ่มข้อมูลวิชา</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post" action="cus_order_add.php" >
                                                                    <div class="row">
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                ชื่อวิชา
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                                <input type="text" class="form-control" placeholder="กรอกชื่อวิชา" aria-describedby="search-txt">        
                                                                        </div>
                                                                    </div>
                                                                    <div style="margin-top:21px;"></div> 
                                                                    <div class="text-right m-b-10">
                                                                        <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                        <button type="button" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                    </div>
                                                                </form>    
                                                            </div>
                                                                
                                                        </div>
                                                    </div>
                </div>
                <!-- modal -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <script
  src="https://code.jquery.com/jquery-3.4.1.js"
  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
  crossorigin="anonymous"></script>
        <script>
        /*
        function serchCategory(){
            alert('d');
        $.ajax({
            type: "POST",
            url:"pathto/getdata.php",
            data: "id="+str,
            success:function(result){

            //here is your success action
            //get data on div  
                $("#result").html(result);
            });

        }
        */

        $("#searchBtn").click(function(){
            category = document.getElementById("category_list").value;
            $.ajax({
                type: 'POST',
                url: 'load_personnel',
                data: 'category='+category,
                success: function(result) {   
                    $("#load_content").html(result);
                }
            });
        });
        </script>