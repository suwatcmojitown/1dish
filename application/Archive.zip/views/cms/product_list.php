<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

 
<div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">ข่าว</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">Create News</li>
                            </ol>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <?php 
                        //console($data['result']);
                    ?>
                    <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <?php 
                                //console($data);
                                ?>
                                <div class="text-right m-b-10">
                                        <a href="<?php echo base_url('cms/create_news');?>"><button class="btn btn-success" type="submit"> <span><i class="fa fa-file-o"></i>  เพิ่มข่าว</span> </button></a>
                                </div>
                                <hr class="m-t-0 m-b-20">
                                <div class="row m-b-15">
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <div class="col-md-1 text-primary" style="padding-top: 7px;">
                                                        หมวดหมู่
                                                </div>
                                                <div class="col-md-4">
                                                        <?php 
                                                        if(isset($data['cat_list'])&&!empty($data['cat_list']))
                                                        {
                                                        ?>
                                                        <select class="form-control custom-select text-muted" id="news_type_list" name="news_type_list">
                                                                <option value="all">ทั้งหมด</option>
                                                            <?php 
                                                            foreach($data['cat_list'] as $row)
                                                            {
                                                            ?>    
                                                                <option value="<?php echo $row['slug'];?>"><?php echo $row['cat_name'];?></option>
                                                            <?php 
                                                            }
                                                            ?>                
                                                        </select>
                                                        <?php 
                                                        }
                                                        ?>
                                                                
                                                </div> 
                                                <div class="offset-md-2 col-md-2">
                                                      <button type="button" id="searchBtn" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                
                                <!--second tab-->
                                <!-- load content -->
                                <div class="table-responsive dataTables_wrapper" id="load_content">
                                        <table class="table color-table primary-table">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <th style="width:20%;">ชื่อ</th>
                                                    <th style="width:15%;">รูปภาพ</th>
                                                    <th style="width:15%;">ศูนย์</th>
                                                    <th style="width:10%;">หมวดหมู่</th>
                                                    <th style="width:10%;">สถานะ</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                if(isset($data['result'])&&!empty($data['result']))
                                                {
                                                    $i = 1;
                                                    foreach($data['result'] as $row)
                                                    {
                                                ?>
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo $row['title']?></td>
                                                    <td><img src="<?php echo base_url().$row['thumbnail']?>" alt="user-img" height="80"></td>
                                                    <td><?php echo $row['cat_name']?></td>
                                                    <td><?php echo $row['type_name']?></td>
                                                    <td><?php if($row['status']=='1')echo 'ใช้งาน'; else echo 'ไม่ใช้งาน';?></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-danger"></i> </a>
                                                    </td>
                                                </tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>

                                    <hr>
                                    
                                </div>
                                <!-- load content -->
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <script
  src="https://code.jquery.com/jquery-3.4.1.js"
  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
  crossorigin="anonymous"></script>
        <script>
        
        $("#searchBtn").click(function(){
            category = document.getElementById("news_type_list").value;
            $.ajax({
                type: 'POST',
                url: 'load_news',
                data: 'category='+category,
                success: function(result) {   
                    $("#load_content").html(result);
                }
            });
        });
        </script>