<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<script src="https://cdn.ckeditor.com/ckeditor5/12.4.0/classic/ckeditor.js"></script>
   

<div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">เพิ่มรายละเอียดศูนย์</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">Create Contact</li>
                            </ol>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">
                        <div class="card-body">
                                <form action="add_category_template" class="form-horizontal" method="post" enctype="multipart/form-data">
                                    <!-- form body -->
                                    <div class="form-body">
										<div class="card-header bg-cyan">
										<h4 class="m-b-0 text-white">เพิ่มรายละเอียดศูนย์</h4></div>
                                        <h3 class="box-title"></h3>
                                        <hr class="m-t-0 m-b-20">
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" >หมวดหมู่</label>
                                                                <div class="col-md-5">
                                                                    <select class="form-control custom-select text-muted" name="category" id="category">
                                                                    <?php 
                                                                        if(isset($cat_list)&&!empty($cat_list))
                                                                        {
                                                                            foreach($cat_list as $row){
                                                                    ?>        
                                                                        <option value="<?php echo $row['cat_id']?>"><?php echo $row['cat_name']?></option>
                                                                    <?php 
                                                                            }
                                                                        }
                                                                    ?>    
                                                                    </select>
                                                                    
                                                                </div>
                                                        </div>
                                                    </div>
                                                </div>  
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">รายละเอียด</label>
                                                            <div class="col-md-8">
                                                                <textarea class="form-control" id="description" name="description" rows="3" placeholder="กรอกรายละเอียด"></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">รายละเอียด Eng</label>
                                                            <div class="col-md-8">
                                                                <textarea class="form-control" id="description_en" name="description_en" rows="3" placeholder="กรอกรายละเอียด"></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>  
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">รหัสสี</label>
                                                            <div class="col-md-3">
                                                                <input type="text" id="code_color" name="code_color" class="form-control form-control-line" placeholder="กรอกรหัสสี">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">รูปภาพ</label>
                                                            <div class="col-md-7">
                                                                <input type="file" id="thumbnail" name="thumbnail" class="form-control form-control-line" placeholder="slug">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>  
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">เครื่องมือ</label>
                                                            <div class="col-md-8">
                                                                <textarea class="form-control" id="tools" name="tools" rows="4" placeholder=""></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">เครื่องมือ Eng</label>
                                                            <div class="col-md-8">
                                                                <textarea class="form-control" id="tools_en" name="tools_en" rows="3" ></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>          
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">บริการ</label>
                                                            <div class="col-md-8">
                                                                <textarea class="form-control" id="service" name="service" rows="4" placeholder=""></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">บริการ Eng</label>
                                                            <div class="col-md-8">
                                                                <textarea class="form-control" id="service_en" name="service_en" rows="3" ></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">อัตราค่าบริการ</label>
                                                            <div class="col-md-8">
                                                                <textarea class="form-control" id="rate" name="rate" rows="4" placeholder=""></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">อัตราค่าบริการ Eng</label>
                                                            <div class="col-md-8">
                                                                <textarea class="form-control" id="rate_en" name="rate_en" rows="3" ></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left: 14px;">สถานะ</label>
                                                            <div class="col-md-9">
                                                                <div class="form-check form-check-inline">
                                                                      <input class="form-check-input" type="radio" name="status" id="status_1" value="1" checked>
                                                                      <label class="form-check-label" for="inlineRadio1">ใช้งาน</label>
                                                                </div>
                                                                <div class="form-check form-check-inline">
                                                                      <input class="form-check-input" type="radio" name="status" id="status_2" value="0">
                                                                      <label class="form-check-label" for="inlineRadio2">ยกเลิก</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr class="m-t-0 m-b-20">
                                                <div class="row">
                                                    <div class="col-12 m-t-30">
                                                        <div class="form-group row">

                                                            <div class="offset-md-7 col-md-1">
                                                                 <button class="btn btn-danger pull-right" input type="reset" >ยกเลิก</button>
                                                                
                                                            </div>    
                                                            <div class="col-md-2">
                                                                 <button class="btn btn-success pull-right btn-outline" input type="submit"> บันทึก</button>
                                                            </div>     
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>      
										<!-- form body -->
                                </form>
                                <!-- form -->
                            </div>
                            <!-- card body -->    
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
<script>
            ClassicEditor
            .create( document.querySelector( '#service' ) ,{
                minHeight: '300px',
                ckfinder: {
                    uploadUrl: '../assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files&responseType=json'
    
                }
            } )
            .catch( error => {
                console.error( error );
            } );

            ClassicEditor
            .create( document.querySelector( '#service_en' ) ,{
                minHeight: '300px',
                ckfinder: {
                    uploadUrl: '../assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files&responseType=json'
    
                }
            } )
            .catch( error => {
                console.error( error );
            } ); 

            ClassicEditor
            .create( document.querySelector( '#description' ) ,{
                minHeight: '300px',
                ckfinder: {
                    uploadUrl: '../assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files&responseType=json'
    
                }
            } )
            .catch( error => {
                console.error( error );
            } ); 

            ClassicEditor
            .create( document.querySelector( '#description_en' ) ,{
                minHeight: '300px',
                ckfinder: {
                    uploadUrl: '../assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files&responseType=json'
    
                }
            } )
            .catch( error => {
                console.error( error );
            } ); 

            ClassicEditor
            .create( document.querySelector( '#tools' ) ,{
                minHeight: '300px',
                ckfinder: {
                    uploadUrl: '../assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files&responseType=json'
    
                }
            } )
            .catch( error => {
                console.error( error );
            } );

            ClassicEditor
            .create( document.querySelector( '#tools_en' ) ,{
                minHeight: '300px',
                ckfinder: {
                    uploadUrl: '../assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files&responseType=json'
    
                }
            } )
            .catch( error => {
                console.error( error );
            } );   

            ClassicEditor
            .create( document.querySelector( '#rate' ) ,{
                minHeight: '300px',
                ckfinder: {
                    uploadUrl: '../assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files&responseType=json'
    
                }
            } )
            .catch( error => {
                console.error( error );
            } ); 

            ClassicEditor
            .create( document.querySelector( '#rate_en' ) ,{
                minHeight: '300px',
                ckfinder: {
                    uploadUrl: '../assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files&responseType=json'
    
                }
            } )
            .catch( error => {
                console.error( error );
            } ); 
</script>        
       