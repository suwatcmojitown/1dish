                                                <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" >หน่วยงาน</label>
                                                                <div class="col-md-5">
                                                                <select class="form-control custom-select text-muted" name="department_list" id="department_list">
                                                                        <option value="0">-- เลือกหน่วยงาน --</option>
                                                                        <?php 
                                                                        if(isset($data['department_list'])&&!empty($data['department_list']))
                                                                        {
                                                                            foreach($data['department_list'] as $row)
                                                                            {
                                                                        ?>    
                                                                                <option value="<?php echo $row['department_id'];?>"><?php echo $row['name'];?></option>
                                                                        <?php 
                                                                            }
                                                                        }
                                                                        ?>              
                                                                    </select>
                                                                    
                                                                </div>
                                                                <div class="offset-md-1 col-md-1">
                                                                    <button class="btn btn-info pull-left" type="button" data-toggle="modal" data-target="#department-responsive-modal"><i class="fa fa-plus"></i> เพิ่มหน่วยงาน</button>
                                                                </div>
                                                        </div>
                                                    </div>

<!-- modal -->
<div id="department-responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                            <div class="modal-dialog modal-lg" >
                                                <div class="modal-content">
                                                    <div class="modal-header alert-success">
                                                        <h4 class="modal-title"><i class="mdi mdi-account-plus"></i> เพิ่มหน่วยงาน</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form method="post" action="cus_order_add.php" >
                                                            <div class="row">
                                                                <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                        ชื่อหน่วยงาน
                                                                </div>
                                                                <div class="col-md-5">
                                                                        <input type="text" name="department_title" id="department_title" class="form-control" placeholder="กรอกหน่วยงาน" aria-describedby="search-txt">        
                                                                </div>
                                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                                        slug
                                                                </div>
                                                                <div class="col-md-3">
                                                                        <input type="text" name="department_slug" id="department_slug" class="form-control" placeholder="กรอก slug" aria-describedby="search-txt">        
                                                                </div>
                                                            </div>
                                                            <div style="margin-top:21px;"></div> 
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group row">
                                                                        <label class="control-label text-left col-md-2 text-success" style="padding-left: 14px;">สถานะ</label>
                                                                        <div class="col-md-9">
                                                                            <div class="form-check form-check-inline text-muted">
                                                                                <input class="form-check-input" type="radio" name="department_status" id="status_1" value="1" checked>
                                                                                <label class="form-check-label" for="inlineRadio1">ใช้งาน</label>
                                                                            </div>
                                                                            <div class="form-check form-check-inline text-muted">
                                                                                <input class="form-check-input" type="radio" name="department_status" id="status_2" value="0">
                                                                                <label class="form-check-label" for="inlineRadio2">ยกเลิก</label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div> 
                                                            <div class="text-right m-b-10">
                                                                <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                <button type="button" id="add_department_btn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                            </div>
                                                        </form>    
                                                    </div>
                                                        
                                                </div>
                                            </div>
</div>
<!-- modal -->                                                    

<script>
       
        $( "#add_doctype" ).click(function() {
            doc_id = document.getElementById("doctype_list").value;
            $.ajax({
                type: 'POST',
                url: 'load_doctypelist',
                data: 'doc_id='+doc_id,
                success: function(result) { 
                    $("#doctype_list").html(result);
                }
            });
        }); 

        $( "#add_department_btn" ).click(function() {
            department_status = $("input[name=department_status]:checked").val();
            department_title = document.getElementById("department_title").value;
            department_slug = document.getElementById("department_slug").value;
            type_id = document.getElementById("doctype_list").value;
            $.ajax({
                type: 'POST',
                url: 'add_department',
                data: 'title='+department_title+'&slug='+department_slug+'&status='+department_status+'&type_id='+type_id,
                success: function(result) { 
                    location.reload();
                }
            });
        }); 

</script>

