<?php 
                                                        if(isset($data['department_list'])&&!empty($data['department_list']))
                                                        {
                                                        ?>
                                                        <select class="form-control custom-select text-muted" id="department_id" name="department_id">
                                                                <option value="all">ทั้งหมด</option>
                                                            <?php 
                                                            foreach($data['department_list'] as $row)
                                                            {
                                                            ?>    
                                                                <option value="<?php echo $row['department_id'];?>"><?php echo $row['name'];?></option>
                                                            <?php 
                                                            }
                                                            ?>                
                                                        </select>
                                                        <?php 
                                                        }
                                                        ?>