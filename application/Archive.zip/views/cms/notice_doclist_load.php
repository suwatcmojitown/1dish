                                                
<?php 
                                                        if(isset($data['doc_list'])&&!empty($data['doc_list']))
                                                        {
                                                        ?>
                                                        <select class="form-control custom-select text-muted" id="doc_id" name="doc_id">
                                                                <option value="all">ทั้งหมด</option>
                                                            <?php 
                                                            foreach($data['doc_list'] as $row)
                                                            {
                                                            ?>    
                                                                <option value="<?php echo $row['doc_id'];?>"><?php echo $row['title'];?></option>
                                                            <?php 
                                                            }
                                                            ?>                
                                                        </select>
                                                        <?php 
                                                        }
                                                        ?>


<script>
$( "#doc_id" ).change(function() {
            doc_id = document.getElementById("doc_id").value;
            $.ajax({
                type: 'POST',
                url: 'load_doctypelist',
                data: 'doc_id='+doc_id,
                success: function(result) { 
                    $("#doctype_list").html(result);
                }
            });
        });
</script>