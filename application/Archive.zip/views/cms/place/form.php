<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?php
$is_edit   = isset($place);
$place_id  = $is_edit ? $place->place_id  : '';
$review_id = ($is_edit && isset($review)) ? $review->review_id : '';
?>

<div class="page-form-header">
  <div class="page-form-title"><?php echo $is_edit ? 'แก้ไขร้านค้า' : 'เพิ่มร้านค้า'; ?></div>
  <div class="page-form-sub">ข้อมูลร้านค้าและรีวิวจะถูกบันทึกพร้อมกัน</div>
</div>

<form id="placeForm" method="POST" enctype="multipart/form-data"
      action="<?php echo base_url($is_edit ? 'cms/place/update' : 'cms/place/save'); ?>">

  <?php if ($is_edit): ?>
  <input type="hidden" name="place_id"  value="<?php echo $place_id; ?>">
  <input type="hidden" name="review_id" value="<?php echo $review_id; ?>">
  <?php endif; ?>

  <!-- ส่วนที่ 1: ข้อมูลร้านค้า -->
  <div class="form-section">
    <div class="form-section-title">1 — ข้อมูลร้านค้า</div>
    <div class="form-grid">
      <div class="form-group form-full">
        <label>ชื่อร้านค้า / สถานที่</label>
        <input type="text" name="name" placeholder="เช่น Krua Ban Phe"
               value="<?php echo $is_edit ? $place->name : ''; ?>" required>
      </div>
      <div class="form-group">
        <label>หมวดหมู่</label>
        <select name="category_id" required>
          <option value="">-- เลือกหมวดหมู่ --</option>
          <?php if ($categoryList): foreach ($categoryList as $cat): ?>
          <option value="<?php echo $cat->category_id; ?>"
            <?php echo ($is_edit && $place->category_id == $cat->category_id) ? 'selected' : ''; ?>>
            <?php echo $cat->name; ?>
          </option>
          <?php endforeach; endif; ?>
        </select>
      </div>
      <div class="form-group">
        <label>อำเภอ</label>
        <select name="district_id" required>
          <option value="">-- เลือกอำเภอ --</option>
          <?php if ($districtList): foreach ($districtList as $dist): ?>
          <option value="<?php echo $dist->district_id; ?>"
            <?php echo ($is_edit && $place->district_id == $dist->district_id) ? 'selected' : ''; ?>>
            <?php echo $dist->name; ?>
          </option>
          <?php endforeach; endif; ?>
        </select>
      </div>
      <div class="form-group">
        <label>เวลาเปิด-ปิด</label>
        <input type="text" name="open_hours" placeholder="เช่น ทุกวัน 10:00 - 21:00"
               value="<?php echo $is_edit ? $place->open_hours : ''; ?>">
      </div>
      <div class="form-group">
        <label>Facebook URL</label>
        <input type="text" name="fb_url" placeholder="https://facebook.com/..."
               value="<?php echo $is_edit ? $place->fb_url : ''; ?>">
      </div>
      <div class="form-group">
        <label>Instagram URL</label>
        <input type="text" name="ig_url" placeholder="https://instagram.com/..."
               value="<?php echo $is_edit ? $place->ig_url : ''; ?>">
      </div>
      <div class="form-group">
        <label>TikTok URL</label>
        <input type="text" name="tiktok_url" placeholder="https://tiktok.com/..."
               value="<?php echo $is_edit ? $place->tiktok_url : ''; ?>">
      </div>
    </div>
  </div>

  <!-- ส่วนที่ 2: พิกัดและภาพหน้าร้าน -->
  <div class="form-section">
    <div class="form-section-title">2 — พิกัดและภาพหน้าร้าน</div>
    <div class="form-grid">
      <div class="form-group">
        <label>Latitude</label>
        <input type="text" name="lat" placeholder="เช่น 12.6408"
               value="<?php echo $is_edit ? $place->lat : ''; ?>">
      </div>
      <div class="form-group">
        <label>Longitude</label>
        <input type="text" name="lng" placeholder="เช่น 101.5687"
               value="<?php echo $is_edit ? $place->lng : ''; ?>">
      </div>
      <div class="form-group form-full">
        <label>ภาพหน้าร้าน</label>
        <?php if ($is_edit && !empty($place->shop_image)): ?>
        <div style="margin-bottom:10px">
          <img src="<?php echo base_url($place->shop_image); ?>" style="max-width:200px;border-radius:8px;border:1px solid var(--border);">
        </div>
        <input type="hidden" name="shop_image_hidden" value="<?php echo $place->shop_image; ?>">
        <?php endif; ?>
        <input type="file" name="shop_image" accept="image/*" style="background:var(--bg3);border:1px solid var(--border);border-radius:8px;padding:8px;">
        <small style="color:var(--muted);font-size:12px">JPG, PNG — เพื่อให้รู้จักตำแหน่งร้านได้ง่ายขึ้น</small>
      </div>
    </div>
  </div>

  <!-- ส่วนที่ 3: รีวิว -->
  <div class="form-section">
    <div class="form-section-title">3 — รีวิว</div>
    <div class="form-grid">
      <div class="form-group form-full">
        <label>หัวข้อรีวิว</label>
        <input type="text" name="review_title" placeholder="เช่น The Salt-Crusted Sea Bass of Ban Phe"
               value="<?php echo ($is_edit && isset($review)) ? $review->title : ''; ?>">
      </div>
      <div class="form-group form-full">
        <label>ชื่อเมนูเด่น (Signature Dish)</label>
        <input type="text" name="signature_dish_name" placeholder="เช่น ปลากะพงเกลือ"
               value="<?php echo ($is_edit && isset($review)) ? $review->signature_dish_name : ''; ?>">
      </div>
      <div class="form-group form-full">
        <label>ภาพปกรีวิว</label>
        <?php if ($is_edit && isset($review) && !empty($review->cover_image)): ?>
        <div style="margin-bottom:10px">
          <img src="<?php echo base_url($review->cover_image); ?>" style="max-width:200px;border-radius:8px;border:1px solid var(--border);">
        </div>
        <input type="hidden" name="cover_image_hidden" value="<?php echo $review->cover_image; ?>">
        <?php endif; ?>
        <input type="file" name="cover_image" accept="image/*" style="background:var(--bg3);border:1px solid var(--border);border-radius:8px;padding:8px;width:100%">
        <small style="color:var(--muted);font-size:12px">JPG, PNG — ภาพปกสำหรับแสดงในหน้ารีวิว</small>
      </div>
      <div class="form-group form-full">
        <label>เนื้อหารีวิว <span style="color:var(--muted);font-weight:400;font-size:11px">— แทรกภาพในเนื้อหาได้ผ่าน Froala</span></label>
        <textarea id="review-body" name="body"><?php echo ($is_edit && isset($review)) ? $review->body : ''; ?></textarea>
      </div>
      <div class="form-group">
        <label>Link วิดีโอ TikTok / YouTube</label>
        <input type="text" name="video_url" placeholder="https://tiktok.com/... หรือ https://youtube.com/..."
               value="<?php echo ($is_edit && isset($review)) ? $review->video_url : ''; ?>">
      </div>
    </div>
  </div>

  <!-- ส่วนที่ 4: ตั้งค่า -->
  <div class="form-section">
    <div class="form-section-title">4 — ตั้งค่า</div>
    <div class="form-grid">
      <div class="form-group">
        <label>เขียนโดย Influencer</label>
        <select name="influencer_id">
          <option value="">-- เลือก Influencer --</option>
          <?php if ($influencerList): foreach ($influencerList as $inf): ?>
          <option value="<?php echo $inf->influencer_id; ?>"
            <?php echo ($is_edit && isset($review) && $review->influencer_id == $inf->influencer_id) ? 'selected' : ''; ?>>
            <?php echo $inf->display_name; ?>
          </option>
          <?php endforeach; endif; ?>
        </select>
      </div>
      <div class="form-group">
        <label>สถานะรีวิว</label>
        <select name="review_status">
          <option value="pending"       <?php echo ($is_edit && isset($review) && $review->status == 'pending')       ? 'selected' : ''; ?>>pending (รอ approve)</option>
          <option value="approved"      <?php echo ($is_edit && isset($review) && $review->status == 'approved')      ? 'selected' : ''; ?>>approved</option>
          <option value="approved_seal" <?php echo ($is_edit && isset($review) && $review->status == 'approved_seal') ? 'selected' : ''; ?>>approved + seal of approval</option>
        </select>
      </div>
    </div>
  </div>

  <div class="form-footer">
    <a href="<?php echo base_url('cms/place'); ?>" class="btn btn-ghost">ยกเลิก</a>
    <button type="submit" class="btn btn-primary">บันทึกร้านค้าและรีวิว</button>
  </div>

</form>

<script src="<?php echo base_url(); ?>froala_editor/js/froala_editor.pkgd.min.js"></script>
<script>
new FroalaEditor('#review-body', {
    key: '2J1B10dA5B4F4C3A3C3I3C-22VKOG1FGULVKHXDXNDXc2a1Kd1SNdF3H3A8B5D4A3C3E3B2A13==',
    heightMin: 300,
    imageUploadURL: '<?php echo base_url('upload_image.php'); ?>',
    imageUploadParams: {
        id: 'my_editor'
    }
});
</script>
