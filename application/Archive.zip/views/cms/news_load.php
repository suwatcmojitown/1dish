                                <!-- load content -->
                                
                                <table class="table color-table primary-table">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <th style="width:20%;">ชื่อ</th>
                                                    <th style="width:15%;">รูปภาพ</th>
                                                    <th style="width:15%;">หมวดหมู่</th>
                                                    <th style="width:10%;">แนะนำ</th>
                                                    <th style="width:10%;">สถานะ</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                if(isset($data['result'])&&!empty($data['result']))
                                                {
                                                    $i = 1;
                                                    foreach($data['result'] as $row)
                                                    {
                                                ?>
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo $row['title']?></td>
                                                    <td><img src="<?php echo base_url().$row['thumbnail']?>" alt="user-img" height="80"></td>
                                                    <td><?php echo $row['name']?></td>
                                                    <td><?php if($row['recommend']=='1')echo 'แนะนำ';?></td>
                                                    <td><?php if($row['status']=='1')echo 'ใช้งาน'; else echo 'ไม่ใช้งาน';?></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-danger"></i> </a>
                                                    </td>
                                                </tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>

                                    
                                <!-- load content -->
                            