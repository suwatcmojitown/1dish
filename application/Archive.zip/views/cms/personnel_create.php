<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>


<div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">บุคลากร</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">Create Personnel</li>
                            </ol>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">
                        <div class="card-body">
                                <form action="add_personnel" class="form-horizontal" method="post" enctype="multipart/form-data">
                                    <!-- form body -->
                                    <div class="form-body">
										<div class="card-header bg-cyan">
										<h4 class="m-b-0 text-white">เพิ่มบุคลากร</h4></div>
                                        <h3 class="box-title"></h3>
                                        <hr class="m-t-0 m-b-20">
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-12"> 
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">ชื่อ</label>
                                                            <div class="col-md-7">
                                                                <input type="text" id="name" name="name" class="form-control form-control-line" placeholder="กรอกชื่อ">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">ตำแหน่ง</label>
                                                            <div class="col-md-9">
                                                                <input type="text" id="rank" name="rank" class="form-control form-control-line" placeholder="กรอกชื่อตำแหน่ง">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" >ศูนย์</label>
                                                                <div class="col-md-5">
                                                                    <select class="form-control custom-select text-muted" name="category" id="category">
                                                                    <?php 
                                                                        if(isset($cat_list)&&!empty($cat_list))
                                                                        {
                                                                            foreach($cat_list as $row){
                                                                    ?>        
                                                                        <option value="<?php echo $row['cat_id']?>"><?php echo $row['cat_name']?></option>
                                                                    <?php 
                                                                            }
                                                                        }
                                                                    ?>    
                                                                    </select>
                                                                    
                                                                </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">รูปภาพ</label>
                                                            <div class="col-md-7">
                                                                <input type="file" id="thumbnail" name="thumbnail" class="form-control form-control-line" placeholder="slug">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" >อันดับ</label>
                                                                <div class="col-md-5">
                                                                    <select class="form-control custom-select text-muted" name="rank_order" id="rank_order">
                                                                        <option value="1">ผู้อำนวยการ</option>
                                                                        <option value="2">รองผู้อำนวยการ</option>
                                                                        <option value="3">บุคลากรทั่วไป</option>
                                                                    </select>
                                                                </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left: 14px;">สถานะ</label>
                                                            <div class="col-md-9">
                                                                <div class="form-check form-check-inline text-muted">
                                                                      <input class="form-check-input" type="radio" name="status" id="status_1" value="1" checked>
                                                                      <label class="form-check-label" for="inlineRadio1">ใช้งาน</label>
                                                                </div>
                                                                <div class="form-check form-check-inline text-muted">
                                                                      <input class="form-check-input" type="radio" name="status" id="status_2" value="0">
                                                                      <label class="form-check-label" for="inlineRadio2">ยกเลิก</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr class="m-t-0 m-b-20">
                                                <div class="row">
                                                    <div class="col-12 m-t-30">
                                                        <div class="form-group row">

                                                            <div class="offset-md-7 col-md-1">
                                                                 <button class="btn btn-danger pull-right" input type="reset" >ยกเลิก</button>
                                                                
                                                            </div>    
                                                            <div class="col-md-2">
                                                                 <button class="btn btn-success pull-right btn-outline" input type="submit"> บันทึก</button>
                                                            </div>     
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>      
										<!-- form body -->
                                </form>
                                <!-- form -->
                            </div>
                            <!-- card body -->    
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <div class="right-sidebar">
                    <div class="slimscrollright">
                        <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
                        <div class="r-panel-body">
                            <ul id="themecolors" class="m-t-20">
                                <li><b>With Light sidebar</b></li>
                                <li><a href="javascript:void(0)" data-skin="skin-default" class="default-theme working">1</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-green" class="green-theme">2</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-red" class="red-theme">3</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-blue" class="blue-theme">4</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-purple" class="purple-theme">5</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-megna" class="megna-theme">6</a></li>
                                <li class="d-block m-t-30"><b>With Dark sidebar</b></li>
                                <li><a href="javascript:void(0)" data-skin="skin-default-dark" class="default-dark-theme ">7</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-green-dark" class="green-dark-theme">8</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-red-dark" class="red-dark-theme">9</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-blue-dark" class="blue-dark-theme">10</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-purple-dark" class="purple-dark-theme">11</a></li>
                                <li><a href="javascript:void(0)" data-skin="skin-megna-dark" class="megna-dark-theme ">12</a></li>
                            </ul>
                            <ul class="m-t-20 chatonline">
                                <li><b>Chat option</b></li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/1.jpg" alt="user-img" class="img-circle"> <span>Varun Dhavan <small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/2.jpg" alt="user-img" class="img-circle"> <span>Genelia Deshmukh <small class="text-warning">Away</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/3.jpg" alt="user-img" class="img-circle"> <span>Ritesh Deshmukh <small class="text-danger">Busy</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/4.jpg" alt="user-img" class="img-circle"> <span>Arijit Sinh <small class="text-muted">Offline</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/5.jpg" alt="user-img" class="img-circle"> <span>Govinda Star <small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/6.jpg" alt="user-img" class="img-circle"> <span>John Abraham<small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/7.jpg" alt="user-img" class="img-circle"> <span>Hritik Roshan<small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="assets/images/users/8.jpg" alt="user-img" class="img-circle"> <span>Pwandeep rajan <small class="text-success">online</small></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
                <!-- modal -->
                <div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog modal-md" >
                                                        <div class="modal-content">
                                                            <div class="modal-header alert-success">
                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> เพิ่มข้อมูลวิชา</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post" action="cus_order_add.php" >
                                                                    <div class="row">
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                ชื่อวิชา
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                                <input type="text" class="form-control" placeholder="กรอกชื่อวิชา" aria-describedby="search-txt">        
                                                                        </div>
                                                                    </div>
                                                                    <div style="margin-top:21px;"></div> 
                                                                    <div class="text-right m-b-10">
                                                                        <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                        <button type="button" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                    </div>
                                                                </form>    
                                                            </div>
                                                                
                                                        </div>
                                                    </div>
                </div>
                <!-- modal -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->