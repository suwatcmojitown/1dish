                                                <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" >ผู้รับผิดชอบ</label>
                                                                <div class="col-md-5">
                                                                <select class="form-control custom-select text-muted" name="owner" id="owner">
                                                                        <?php 
                                                                        if(isset($data['owner_list'])&&!empty($data['owner_list']))
                                                                        {
                                                                            foreach($data['owner_list'] as $row)
                                                                            {
                                                                        ?>    
                                                                                <option value="<?php echo $row['personnel_id'];?>"><?php echo $row['name'];?></option>
                                                                        <?php 
                                                                            }
                                                                        }
                                                                        ?>              
                                                                    </select>
                                                                    
                                                                </div>
                                                        </div>
                                                    </div>

                                                  


