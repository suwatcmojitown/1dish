<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>


<div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">ประกาศ</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">Create Notice</li>
                            </ol>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">
                        <div class="card-body">
                                <form action="add_notice" class="form-horizontal" method="post" enctype="multipart/form-data">
                                    <!-- form body -->
                                    <div class="form-body">
										<div class="card-header bg-cyan">
										<h4 class="m-b-0 text-white">เพิ่มประกาศ</h4></div>
                                        <h3 class="box-title"></h3>
                                        <hr class="m-t-0 m-b-20">
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-12"> 
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" >หมวดหมู่</label>
                                                                <div class="col-md-5">
                                                                    <select class="form-control custom-select text-muted" name="category" id="category">
                                                                        <option value="all">หน้าหลัก</option>    
                                                                    <?php 
                                                                        if(isset($cat_list)&&!empty($cat_list))
                                                                        {
                                                                            foreach($cat_list as $row){
                                                                    ?>        
                                                                        <option value="<?php echo $row['cat_id']?>"><?php echo $row['cat_name']?></option>
                                                                    <?php 
                                                                            }
                                                                        }
                                                                    ?>    
                                                                    </select>
                                                                    
                                                                </div>
                                                                <div class="offset-md-1 col-md-1">
                                                                    <button class="btn btn-info pull-left" input="" type="reset" id="add_category"><i class="fa fa-plus"></i> เพิ่มหมวดหมู่</button>
                                                                </div>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <div class="row" id="doc"></div>
                                                <div class="row" id="doctype"></div>
                                                <div class="row" id="department"></div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">ชื่อ</label>
                                                            <div class="col-md-7">
                                                                <input type="text" id="name" name="name" class="form-control form-control-line" placeholder="กรอกชื่อ">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">ชื่อ Eng</label>
                                                            <div class="col-md-7">
                                                                <input type="text" id="name_en" name="name_en" class="form-control form-control-line" placeholder="กรอกชื่อ Eng">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">ไฟล์เอกสาร</label>
                                                            <div class="col-md-7">
                                                                <input type="file" id="doc" name="doc" class="form-control form-control-line" placeholder="slug">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left: 14px;">สถานะ</label>
                                                            <div class="col-md-9">
                                                                <div class="form-check form-check-inline text-muted">
                                                                      <input class="form-check-input" type="radio" name="status" id="status_1" value="1" checked>
                                                                      <label class="form-check-label" for="inlineRadio1">ใช้งาน</label>
                                                                </div>
                                                                <div class="form-check form-check-inline text-muted">
                                                                      <input class="form-check-input" type="radio" name="status" id="status_2" value="0">
                                                                      <label class="form-check-label" for="inlineRadio2">ยกเลิก</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr class="m-t-0 m-b-20">
                                                <div class="row">
                                                    <div class="col-12 m-t-30">
                                                        <div class="form-group row">

                                                            <div class="offset-md-7 col-md-1">
                                                                 <button class="btn btn-danger pull-right" input type="reset" >ยกเลิก</button>
                                                                
                                                            </div>    
                                                            <div class="col-md-2">
                                                                 <button class="btn btn-success pull-right btn-outline" input type="submit"> บันทึก</button>
                                                            </div>     
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>      
										<!-- form body -->
                                </form>
                                <!-- form -->
                            </div>
                            <!-- card body -->    
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

        <script
  src="https://code.jquery.com/jquery-3.4.1.js"
  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
  crossorigin="anonymous"></script>
        <script>
        
        $( "#category" ).change(function() {
            cat_id = document.getElementById("category").value;
            $.ajax({
                type: 'POST',
                url: 'load_doc_create',
                data: 'cat_id='+cat_id,
                success: function(result) {   
                    $("#doc").html(result);
                }
            });
        });


        </script>