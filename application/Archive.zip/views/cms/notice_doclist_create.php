                                                <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" >ชนิด</label>
                                                                <div class="col-md-5">
                                                                    <select class="form-control custom-select text-muted" name="doc_list" id="doc_list">
                                                                        <option value="0">-- เลือกชนิด --</option>
                                                                    <?php 
                                                                        
                                                                        if(isset($data['doc_list'])&&!empty($data['doc_list']))
                                                                        {
                                                                            foreach($data['doc_list'] as $row){
                                                                    ?>        
                                                                        <option value="<?php echo $row['doc_id']?>"><?php echo $row['title']?></option>
                                                                    <?php 
                                                                            }
                                                                        }
                                                                    ?>    
                                                                    </select>
                                                                    
                                                                </div>
                                                                <div class="offset-md-1 col-md-1">
                                                                    <button class="btn btn-info pull-left" id="add_doc" type="button" data-toggle="modal" data-target="#responsive-modal"><i class="fa fa-plus"></i> เพิ่มชนิด</button>
                                                                </div>
                                                        </div>
                                                    </div>

<!-- modal -->
<div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                            <div class="modal-dialog modal-lg" >
                                                <div class="modal-content">
                                                    <div class="modal-header alert-success">
                                                        <h4 class="modal-title"><i class="mdi mdi-account-plus"></i> เพิ่มชนิดประกาศ</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form method="post" action="add_document" >
                                                            <div class="row">
                                                                <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                        ชื่อชนิดประกาศ
                                                                </div>
                                                                <div class="col-md-5">
                                                                        <input type="text" name="doc_title" id="doc_title" class="form-control" placeholder="กรอกชนิดประกาศ" aria-describedby="search-txt">        
                                                                </div>
                                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                                        slug
                                                                </div>
                                                                <div class="col-md-3">
                                                                        <input type="text" name="doc_slug" id="doc_slug" class="form-control" placeholder="กรอก slug" aria-describedby="search-txt"> 
                                                                                
                                                                </div>
                                                            </div>
                                                            <div style="margin-top:21px;"></div> 
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group row">
                                                                        <label class="control-label text-left col-md-2 text-success" style="padding-left: 14px;">ประเภท</label>
                                                                        <div class="col-md-9">
                                                                            <div class="form-check form-check-inline text-muted">
                                                                                <input class="form-check-input" type="radio" name="is_type" id="type_1" value="1" checked>
                                                                                <label class="form-check-label" for="inlineRadio1">มี</label>
                                                                            </div>
                                                                            <div class="form-check form-check-inline text-muted">
                                                                                <input class="form-check-input" type="radio" name="is_type" id="type_2" value="0">
                                                                                <label class="form-check-label" for="inlineRadio2">ไม่มี</label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group row">
                                                                        <label class="control-label text-left col-md-2 text-success" style="padding-left: 14px;">สถานะ</label>
                                                                        <div class="col-md-9">
                                                                            <div class="form-check form-check-inline text-muted">
                                                                                <input class="form-check-input" type="radio" name="doc_status" id="status_1" value="1" checked>
                                                                                <label class="form-check-label" for="inlineRadio1">ใช้งาน</label>
                                                                            </div>
                                                                            <div class="form-check form-check-inline text-muted">
                                                                                <input class="form-check-input" type="radio" name="doc_status" id="status_2" value="0">
                                                                                <label class="form-check-label" for="inlineRadio2">ยกเลิก</label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div> 
                                                            <div class="text-right m-b-10">
                                                                <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                <button type="button" id="add_doc_btn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                            </div>
                                                        </form>    
                                                    </div>
                                                        
                                                </div>
                                            </div>
</div>
<!-- modal -->

<script>
        
        $( "#doc_list" ).change(function() {
            doc_id = document.getElementById("doc_list").value;
            $.ajax({
                type: 'POST',
                url: 'load_doctype_create',
                data: 'doc_id='+doc_id,
                success: function(result) { 
                    $("#doctype").html(result);
                }
            });
            
        });

        $( "#add_doc" ).click(function() {
            doc_id = document.getElementById("doc_list").value;
            $.ajax({
                type: 'POST',
                url: 'load_doctypelist',
                data: 'doc_id='+doc_id,
                success: function(result) { 
                    $("#doctype_list").html(result);
                }
            });
        }); 

        $( "#add_doc_btn" ).click(function() {
            is_type = $("input[name=is_type]:checked").val();
            status = $("input[name=status]:checked").val();
            type_title = document.getElementById("doc_title").value;
            type_slug = document.getElementById("doc_slug").value;
            category = document.getElementById("category").value;
            $.ajax({
                type: 'POST',
                url: 'add_document',
                data: 'title='+type_title+'&slug='+type_slug+'&cat_id='+category+'&is_type='+is_type+'&status='+status,
                success: function(result) { 
                    location.reload();
                }
            });
        });       
</script>