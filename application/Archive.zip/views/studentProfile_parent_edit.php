<!--second tab-->
                                
                                <div class="tab-pane active" id="family" role="tabpanel">
                                    
                                    <div class="card-body">
                                    <?php 
                                    //console($parentFather);
                                    //console($parentMother);
                                    ?>
                                        <table class="table color-table primary-table">
                                            <thead>
                                                <tr>
                                                    <th style="width:20%;">สถานะ</th>
                                                    <th style="width:40%;">ชื่อ - สกุล</th>
                                                    <th style="width:30%;">เบอร์โทรศัพท์</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>บิดา</td>
                                                    <?php 
                                                    if(isset($parentFather[0])&&!empty($parentFather[0]))
                                                    {
                                                    ?>
                                                    <td><?php echo $parentFather[0]->name;?></td>
                                                    <td><?php echo $parentFather[0]->cell_phone;?></td>
                                                    <td>
                                                        <a href="<?php echo base_url('student/deleteParent/').$parentFather[0]->parent_id.'/'.$student_id;?>"> <i class="fa fa-close text-danger"></i> </a>
                                                    </td>
                                                    <?php 
                                                    }
                                                    else
                                                    {
                                                    ?>
                                                    <td></td>
                                                    <td></td>
                                                    <td >
                                                        <a href="javascript:void(0)" data-toggle="modal" data-target="#responsive-modal-father" class="img-responsive model_img" > <i class="fa fa-pencil text-danger"></i> </a>
                                                    </td>
                                                    <?php 
                                                    }
                                                    ?>
                                                </tr>
                                                <tr>
                                                    <td>มารดา</td>
                                                    <?php 
                                                    if(isset($parentMother[0])&&!empty($parentMother[0]))
                                                    {
                                                    ?>
                                                    <td><?php echo $parentMother[0]->name;?></td>
                                                    <td><?php echo $parentMother[0]->cell_phone;?></td>
                                                    <td>
                                                    <a href="<?php echo base_url('student/deleteParent/').$parentMother[0]->parent_id.'/'.$student_id;?>"> <i class="fa fa-close text-danger"></i> </a>
                                                    </td> 
                                                    <?php 
                                                    }
                                                    else
                                                    {
                                                    ?>
                                                    <td></td>
                                                    <td></td>
                                                    <td >
                                                        <a href="javascript:void(0)" data-toggle="modal" data-target="#responsive-modal-mother" class="img-responsive model_img" > <i class="fa fa-pencil text-danger"></i> </a>
                                                    </td>
                                                    <?php 
                                                    }
                                                    ?>
                                                </tr>
                                                <tr>
                                                    <td>ผู้ปกครอง</td>
                                                    <?php 
                                                    //console($parentContactPoint);
                                                    if(isset($parentContactPoint[0])&&!empty($parentContactPoint[0]))
                                                    {
                                                    ?>
                                                    <td><?php echo $parentContactPoint[0]->name;?></td>
                                                    <td><?php echo $parentContactPoint[0]->cell_phone;?></td>
                                                    <td>
                                                    <a href="<?php echo base_url('student/deleteParentContactPoint/').$parentContactPoint[0]->parent_id.'/'.$student_id;?>"> <i class="fa fa-close text-danger"></i> </a>
                                                    </td> 
                                                    <?php 
                                                    }
                                                    else
                                                    {
                                                    ?>
                                                    <td></td>
                                                    <td></td>
                                                    <td >
                                                        <a href="javascript:void(0)" data-toggle="modal" data-target="#responsive-modal-2" class="img-responsive model_img" > <i class="fa fa-pencil text-danger"></i> </a>
                                                    </td>
                                                    <?php 
                                                    }
                                                    ?>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <hr>
                                    </div>
                                </div>
                                <!-- modal -->
                                <div id="responsive-modal-father" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                                    <div class="modal-dialog modal-md" >
                                                                        <div class="modal-content">
                                                                            <div class="modal-header alert-success">
                                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> ค้นหารายชื่อ</h4>
                                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                            </div>
                                                                            
                                                                            <div class="modal-body">
                                                                                <form method="post" action="cus_order_add.php" >
                                                                                    <div class="row">
                                                                                        <div class="col-md-6">
                                                                                                <input type="text" id="keysearchFather" class="form-control" placeholder="พิมพ์คำค้นหา" aria-describedby="search-txt">        
                                                                                        </div>
                                                                                        <div class="col-md-2 text-success">
                                                                                                 <button type="button" id="searchFatherBtn"class="btn btn-warning">ค้นหา</button>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <table class="table color-table primary-table" id="fatherList">
                                                                                        
                                                                                        
                                                                                    </table>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <div class="text-right m-b-10">
                                                                                            <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                                            <button type="button" id="addFatherBtn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                                    </div>
                                                                                </form>    
                                                                            </div>
                                                                                
                                                                        </div>
                                                                    </div>
                                </div>
                                <!-- modal -->
                                <!-- modal -->
                                <div id="responsive-modal-mother" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                                    <div class="modal-dialog modal-md" >
                                                                        <div class="modal-content">
                                                                            <div class="modal-header alert-success">
                                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> ค้นหารายชื่อ</h4>
                                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                            </div>
                                                                            
                                                                            <div class="modal-body">
                                                                                <form method="post" action="cus_order_add.php" >
                                                                                    <div class="row">
                                                                                        <div class="col-md-6">
                                                                                                <input type="text" id="keysearchMother" class="form-control" placeholder="พิมพ์คำค้นหา" aria-describedby="search-txt">        
                                                                                        </div>
                                                                                        <div class="col-md-2 text-success">
                                                                                                 <button type="button" id="searchMotherBtn" class="btn btn-warning">ค้นหา</button>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <table class="table color-table primary-table" id="motherList">
                                                                                        
                                                                                        
                                                                                    </table>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <div class="text-right m-b-10">
                                                                                            <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                                            <button type="button" id="addMotherBtn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                                    </div>
                                                                                </form>    
                                                                            </div>
                                                                                
                                                                        </div>
                                                                    </div>
                                </div>
                                <!-- modal -->
                                <!-- modal -->
                                <div id="responsive-modal-2" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                                    <div class="modal-dialog modal-md" >
                                                                        <div class="modal-content">
                                                                            <div class="modal-header alert-success">
                                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> เลือกผู้ปกครอง</h4>
                                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                            </div>
                                                                            <div class="modal-body">
                                                                                <form method="post" action="cus_order_add.php" >
                                                                                    <!--/row-->
                                                                                    <div class="row">
                                                                                        <div class="col-md-12">
                                                                                            <div class="form-group row">
                                                                                                <label class="control-label text-left col-md-3 text-primary p-t-5">ผู้ปกครอง</label>
                                                                                                <div class="col-md-6">
                                                                                                    <select id="addParentDropdown" class="form-control custom-select text-muted" data-placeholder="Choose a Category" tabindex="1">
                                                                                                        <?php 
                                                                                                        foreach($parentList as $row){
                                                                                                        ?>
                                                                                                        <option value="<?php echo $row->parent_id;?>"><?php echo $row->relationship_name;?></option>
                                                                                                        <?php 
                                                                                                        }
                                                                                                        ?>
                                                                                                    </select>
                                                                                                </div>
                                                                                                <div class="col-md-2 text-success">
                                                                                                         <button type="button" id="selectParentBtn" class="btn btn-success">ยืนยัน</button>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <!--
                                                                                    <div class="row m-t-10">
                                                                                        <div class="col-md-12">
                                                                                            <div class="form-group row">
                                                                                                <label class="control-label text-left col-md-3 text-primary p-t-5">ความสัมพันธ์</label>
                                                                                                <div class="col-md-6">
                                                                                                    <select id="addParentDropdown" class="form-control custom-select text-muted" data-placeholder="Choose a Category" tabindex="1">
                                                                                                        <option value="พ่อ">พ่อ</option>
                                                                                                        <option value="แม่">แม่</option>
                                                                                                    </select>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    --> 
                                                                                    <!--/row-->
                                                                                    <div class="row m-t-10">
                                                                                        <div class="col-md-6">
                                                                                                <input type="text" class="form-control" id="keysearchParent" placeholder="พิมพ์คำค้นหา" aria-describedby="search-txt">        
                                                                                        </div>
                                                                                        <div class="col-md-2 text-success">
                                                                                                 <button type="button" id="searchParentBtn"  class="btn btn-warning">ค้นหา</button>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <table class="table color-table primary-table " id="parentList">
                                                                                        
                                                                                        
                                                                                    </table>           
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <div class="text-right m-b-10">
                                                                                            <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                                            <button type="button" id="addParentBtn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                                    </div>
                                                                                </form>    
                                                                            </div>
                                                                                
                                                                        </div>
                                                                    </div>
                                </div>
                                <!-- modal -->

<script type="text/javascript">    
   $( "#searchFatherBtn").click(function() {
           a = document.getElementById("keysearchFather").value;
           $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'student/searchParent'?>',
               data: 'keysearch='+a+'&type=พ่อ&student_id=<?php echo $student_id?>',
               success: function(result) {
                   $('#fatherList').html(result);
               }
           });      
   });

   $( "#searchMotherBtn").click(function() {
           a = document.getElementById("keysearchMother").value;
           $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'student/searchParent'?>',
               data: 'keysearch='+a+'&type=แม่&student_id=<?php echo $student_id?>',
               success: function(result) {
                   $('#motherList').html(result);
               }
           });      
   });

   $( "#selectParentBtn").click(function() {
            var e = document.getElementById("addParentDropdown");
            var a = e.options[e.selectedIndex].value;
            $.ajax({ 
               type: 'POST',
               url: '<?php echo base_url().'student/updateParent'?>',
               data: 'parent_id='+a+'&student_id=<?php echo $student_id?>',
               success: function(result) {
                   //alert(result);
                   //$('#motherList').html(result);
               }
           });     
   });

   $( "#searchParentBtn").click(function() {
           a = document.getElementById("keysearchParent").value;
           $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'student/searchParent'?>',
               data: 'keysearch='+a+'&type=ไม่ระบุ&student_id=<?php echo $student_id?>',
               success: function(result) {
                   $('#parentList').html(result);
               }
           });      
   });
</script>

