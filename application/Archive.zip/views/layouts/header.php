<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php $current = $this->uri->segment(1) ?: 'home'; ?>

<!-- TOP BANNER AD -->
<div class="w-full bg-surface-container-low flex justify-center py-2 border-b border-outline-variant/20">
  <div class="w-full max-w-[1280px] h-[80px] rounded-xl overflow-hidden relative cursor-pointer mx-4">
    <img alt="TAT Rayong" class="w-full h-full object-cover"
         src="https://lh3.googleusercontent.com/aida-public/AB6AXuDXG4g9ZCWbfRTzsGfXUl8M4tY6tnRxL6zVClYc0BcDpdWf4un6CVhdHOtITkDAfmsN61BRJsC6FUhooj0IAD9uVtVq25CNzCBGEhbtmsvFc7BwQM3cW9WnpYgw9XJsiCu5w1zIFwKmiWOZNA8EKmuuvYfG0qelOXW1jsFhw1SoAI2XTIxXiasdpbxXmKAYRVtxOIPF8haGBAAdxAKyQFD1kMi5YaMPb8lA0MC1R_asjSZay08KmG0d1qXx_U6ths4PmEfGzvAI97M4"/>
    <div class="absolute inset-0 bg-black/40 flex items-center justify-between px-8 text-white">
      <div>
        <span class="text-[10px] uppercase tracking-widest font-bold bg-white/20 px-2 py-0.5 rounded mb-1 inline-block">สนับสนุนโดย ททท.</span>
        <h3 class="text-xl font-thai font-extrabold">เทศกาลผลไม้เมืองระยอง</h3>
      </div>
      <p class="text-sm font-medium hidden md:block text-right">ร่วมงานเทศกาลทุเรียนและมังคุด ประจำปี 2567<br/>สัมผัสรสชาติอันเป็นเอกลักษณ์</p>
    </div>
  </div>
</div>

<!-- NAVBAR -->
<nav class="sticky top-0 w-full z-50 bg-slate-50/80 backdrop-blur-xl border-b border-outline-variant/10">
  <div class="w-full max-w-[1280px] mx-auto flex justify-between items-center px-8 py-3">
    <div class="flex items-center gap-10">
      <a href="<?php echo base_url(); ?>" class="text-xl font-black text-blue-900 italic font-thai">Rayong Curator</a>
      <div class="hidden md:flex gap-6">
        <a href="<?php echo base_url(); ?>"
           class="<?php echo $current == 'home' || $current == '' ? 'text-blue-700 border-b-2 border-blue-700 pb-1' : 'text-slate-600 hover:text-blue-600'; ?> text-sm font-medium transition-colors">
          สำรวจ
        </a>
        <a href="#"
           class="text-slate-600 hover:text-blue-600 transition-colors text-sm font-medium">รสชาติ</a>
        <a href="#"
           class="text-slate-600 hover:text-blue-600 transition-colors text-sm font-medium">บันทึกการเดินทาง</a>
        <a href="#"
           class="text-slate-600 hover:text-blue-600 transition-colors text-sm font-medium">ท่องเที่ยวสีเขียว</a>
      </div>
    </div>
    <div class="flex items-center gap-4">
      <div class="hidden lg:flex items-center bg-surface-container-lowest px-4 py-1.5 rounded-xl border border-outline-variant/30 gap-2">
        <span class="material-symbols-outlined text-outline text-sm">search</span>
        <input class="bg-transparent border-none focus:ring-0 text-sm w-40 font-thai" placeholder="ค้นหารสชาติ..." type="text"/>
      </div>
      <button class="material-symbols-outlined text-on-surface-variant hover:bg-slate-100/50 p-2 rounded-full transition-colors">notifications</button>
      <?php if ($this->session->userdata('user_id')): ?>
      <a href="<?php echo base_url('user/profile'); ?>">
        <div class="w-9 h-9 rounded-full bg-primary-container flex items-center justify-center text-on-primary font-bold text-sm">
          <?php echo strtoupper(mb_substr($this->session->userdata('display_name'), 0, 1)); ?>
        </div>
      </a>
      <?php else: ?>
      <a href="<?php echo base_url('login'); ?>" class="bg-primary text-on-primary text-sm font-bold px-4 py-1.5 rounded-full hover:bg-primary-container transition-colors">เข้าสู่ระบบ</a>
      <?php endif; ?>
    </div>
  </div>
</nav>
