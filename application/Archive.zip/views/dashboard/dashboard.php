
    <link href="<?php echo base_url();?>assets/dist/css/pages/dashboard1.css" rel="stylesheet">
    <!-- chartist CSS -->
    <link href="<?php echo base_url();?>assets/node_modules/chartist-js/dist/chartist.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/node_modules/chartist-js/dist/chartist-init.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/node_modules/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css" rel="stylesheet">
<!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    
                   <?php 
                   //getParentList(12604);
                   //console($timesheet);
                   ?> 
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                    <div class="card">
                    <div class="ribbon-wrapper">
                        <div class="ribbon ribbon-success">วันที่ : <?php echo @$date;?></div>
                    </div>
                            <div class="card-group">
                            <!-- Column -->
                            <div class="card">
                                            <div class="card-body">
                                                <h3 style="color:#6c757d;"></h3>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <h2 class="text-info"><?php echo (@$timesheet->total_student);?></h2>
                                                        <p class="text-muted">จำนวน ทั้งหมด</p>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="progress">
                                                            <div class="progress-bar bg-info" role="progressbar" style="width: 100%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                            </div>
                            <!-- Column -->
                            <!-- Column -->
                            <div class="card">
                                            <div class="card-body">
                                                <h3 style="color:#6c757d;"></i></h3>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <h2 class="text-cyan"><?php echo @$timesheet->normal;?></h2>
                                                        <p class="text-muted">จำนวน มาเรียน</p>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="progress">
                                                            <div class="progress-bar bg-cyan" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                            </div>
                            <!-- Column -->
                            <!-- Column -->
                            <div class="card">
                                            <div class="card-body">
                                                <h3 style="color:#6c757d;"></h3>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <h2 class="text-warning"><?php echo @$timesheet->late;?></h2>
                                                        <p class="text-muted">จำนวน มาสาย</p>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="progress">
                                                            <div class="progress-bar bg-warning" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                            </div>
                            <!-- Column -->
                            <!-- Column -->
                            <div class="card">
                                            <div class="card-body">
                                                <h3 style="color:#6c757d;"></h3>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <h2 class="text-danger"><?php echo (@$timesheet->errand_leave+@$timesheet->sick_leave);?></h2>
                                                        <p class="text-muted">จำนวน ขาด/ลา</p>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="progress">
                                                            <div class="progress-bar bg-danger" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                            </div>
                            <!-- Column -->
                            <!-- Column -->
                            <div class="card">
                                            <div class="card-body">
                                                <h3 style="color:#6c757d;"></h3>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <h2 class="text-purple"><?php echo (@$timesheet->leave_before_time);?></h2>
                                                        <p class="text-muted">จำนวน กลับก่อนเวลา</p>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="progress">
                                                            <div class="progress-bar bg-purple" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                            </div>
                            <!-- Column -->
                            
                            
                        </div>
                        <!-- ============================================================== -->
                        <!-- Over Visitor, Our income , slaes different and  sales prediction -->
                        <!-- ============================================================== -->
                        <div class="row">
                            <!-- Column -->
                            <div class="col-lg-8 col-md-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex m-b-40 align-items-center no-block">
                                            <h5 class="card-title ">นักเรียนชั้น <?php echo @$room_name;?> ที่มาโรงเรียนวันนี้</h5>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6"> 
                                                    <div class="ct-gauge-chart" style="height: 240px;"></div>
                                            </div> 
                                            <div class="col-md-3">
                                                    <h5 class="text-muted">สถานะ</h5>
                                                    <div class="list-group b-0 mail-list"> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-cyan m-r-10"></span>ปกติ</a> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-warning m-r-10"></span>สาย</a> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-danger m-r-10"></span>ขาด/ลา</a> 
                                                    </div>
                                                        
                                                    
                                            </div>
                                            <div class="col-md-3">
                                                    <h5 class="text-muted ">จำนวน</h5>
                                                    <div class="list-group b-0 mail-list"> 
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;"><?php echo @$timesheet->normal;?></a> 
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;"><?php echo @$timesheet->late;?></a> 
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;"><?php echo @$timesheet->errand_leave+@$timesheet->sick_leave;?></a>
                                                        
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Column -->
                            
                            <div class="col-lg-4 col-md-12">
                                <div class="row">
                                    <!-- Column -->
                                    <div class="col-md-12">
                                        <div class="card bg-cyan text-white">
                                            <div class="card-body ">
                                                <div class="row weather">
                                                    <div class="col-6 m-t-40">
                                                        <h3>&nbsp;</h3>
                                                        <div class="display-4">0<sup> +</sup></div>
                                                        <!--<p class="text-white">ดูรายละเอียด</p>-->
                                                    </div>
                                                    <div class="col-6 text-right">
                                                        <h1 class="m-b-"><i class="far fa-grin"></i></h1>
                                                        <b class="text-white">เพิ่มคะแนนความประพฤติ</b>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Column -->
                                    <!-- Column -->
                                    <div class="col-md-12">
                                        <div class="card bg-primary text-white">
                                            <div class="card-body ">
                                                <div class="row weather">
                                                    <div class="col-6 m-t-40">
                                                        <h3>&nbsp;</h3>
                                                        <div class="display-4">0<sup> -</sup></div>
                                                        <!--<p class="text-white">ดูรายละเอียด</p>-->
                                                    </div>
                                                    <div class="col-6 text-right">
                                                        <h1 class="m-b-"><i class="far fa-frown"></i></i></h1>
                                                        b class="text-white">ลดคะแนนความประพฤติ</b>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Column -->
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- Over Visitor, Our income , slaes different and  sales prediction -->
                        <!-- ============================================================== -->
                        <!--  graph -->
                        <!--
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex m-b-40 align-items-center no-block">
                                            <h5 class="card-title ">สรุปจำนวนนักเรียนที่มาโรงเรียนในปี 2019</h5>
                                            <div class="ml-auto">
                                                <ul class="list-inline font-12">
                                                    <li><i class="fa fa-circle text-cyan"></i> ป.1</li>
                                                    <li><i class="fa fa-circle text-primary"></i> ป.2</li>
                                                    <li><i class="fa fa-circle text-primary"></i> ป.3</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div id="morris-area-chart3" style="height: 340px;"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        -->
                        <!-- graph -->
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

<!-- ============================================================== -->
    <!-- This page plugins -->
    <!-- ============================================================== -->
    <!--morris JavaScript -->
    <script src="<?php echo base_url()?>assets/node_modules/raphael/raphael-min.js"></script>
    <script src="<?php echo base_url()?>assets/node_modules/morrisjs/morris.min.js"></script>
    <script src="<?php echo base_url()?>assets/node_modules/jquery-sparkline/jquery.sparkline.min.js"></script>
    <!-- Popup message jquery -->
    <script src="<?php echo base_url()?>assets/node_modules/toast-master/js/jquery.toast.js"></script>
    <!-- Chart JS -->
    <script src="<?php echo base_url()?>assets/dist/js/dashboard1.js"></script>
    <script src="<?php echo base_url()?>assets/node_modules/toast-master/js/jquery.toast.js"></script>

    <!-- chartist chart -->
    <script src="<?php echo base_url()?>assets/node_modules/chartist-js/dist/chartist.min.js"></script>
    <script src="<?php echo base_url()?>assets/node_modules/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="<?php echo base_url()?>assets/node_modules/chartist-js/dist/chartist-init.js"></script>

    <style>
    .ct-series-a .ct-bar, .ct-series-a .ct-line, .ct-series-a .ct-point, .ct-series-a .ct-slice-donut {
    stroke: #01c0c8!important;
    }
    .ct-sm-line-chart .ct-series-b .ct-line, .ct-bar-chart .ct-series-b .ct-bar, .ct-sm-line-chart .ct-series-b .ct-point, .ct-donute-chart .ct-series-b .ct-slice-donut, .ct-gauge-chart .ct-series-b .ct-slice-donut, .ct-animation-chart .ct-series-b .ct-line, .ct-animation-chart .ct-series-b .ct-point, .ct-svg-chart .ct-series-b .ct-line {
    stroke: #fec107!important;
    }
    </style>

    <script>
        new Chartist.Pie('.ct-gauge-chart', {
                  series: [<?php echo @$timesheet->normal;?>,<?php echo @$timesheet->late;?>,<?php echo (@$timesheet->errand_leave+@$timesheet->sick_leave);?>,<?php echo (@$timesheet->leave_before_time);?> ]
                }, {
                  donut: true,
                  donutWidth: 30,
                  startAngle: 270,
                  total: <?php echo count($timesheet->student);?>,
                  low:0,
                  showLabel: false
                });
    </script>

    