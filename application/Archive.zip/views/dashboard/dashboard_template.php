
<!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <?php 
                   //getParentList(12604);
                   //console($list);
                   ?> 
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                            <div class="card-group">
                            <!-- Column -->
                            <div class="card">
                                            <div class="card-body">
                                                <h3 style="color:#6c757d;"><i class="fas fa-sms"></i></h3>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <h2 class="text-primary">2,621</h2>
                                                        <p class="text-muted">sms เครดิตที่เหลือ</p>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="progress">
                                                            <div class="progress-bar bg-primary" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                            </div>
                            <!-- Column -->
                            <!-- Column -->
                            <div class="card">
                                            <div class="card-body">
                                                <h3 style="color:#6c757d;"><i class="fas fa-users"></i></h3>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <h2 class="text-cyan">594</h2>
                                                        <p class="text-muted">จำนวน ทั้งหมด</p>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="progress">
                                                            <div class="progress-bar bg-cyan" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                            </div>
                            <!-- Column -->
                            <!-- Column -->
                            <div class="card">
                                            <div class="card-body">
                                                <h3 style="color:#6c757d;"><i class="fas fa-user-check"></i></h3>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <h2 class="text-purple">590</h2>
                                                        <p class="text-muted">จำนวน มาเรียน</p>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="progress">
                                                            <div class="progress-bar bg-purple" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                            </div>
                            <!-- Column -->
                            <!-- Column -->
                            <div class="card">
                                            <div class="card-body">
                                                <h3 style="color:#6c757d;"><i class="fas fa-user-times"></i></h3>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <h2 class="text-success">2</h2>
                                                        <p class="text-muted">จำนวน ยังไม่มา</p>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="progress">
                                                            <div class="progress-bar bg-success" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                            </div>
                            <!-- Column -->
                            <!-- Column -->
                            <div class="card">
                                            <div class="card-body">
                                                <h3 style="color:#6c757d;"><i class="fas fa-user-clock"></i></h3>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <h2 class="text-warning">2</h2>
                                                        <p class="text-muted">จำนวน มาสาย</p>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="progress">
                                                            <div class="progress-bar bg-warning" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                            </div>
                            <!-- Column -->
                            <!-- Column -->
                            <div class="card">
                                            <div class="card-body">
                                                <h3 style="color:#6c757d;"><i class="fas fa-user-minus"></i></h3>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <h2 class="text-danger">0</h2>
                                                        <p class="text-muted">จำนวน ขาด/ลา</p>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="progress">
                                                            <div class="progress-bar bg-danger" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                            </div>
                            <!-- Column -->
                        </div>
                        <!-- ============================================================== -->
                        <!-- Over Visitor, Our income , slaes different and  sales prediction -->
                        <!-- ============================================================== -->
                        <div class="row">
                            <!-- Column -->
                            <div class="col-lg-4 col-md-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex m-b-40 align-items-center no-block">
                                            <h5 class="card-title ">นักเรียนที่มาโรงเรียนวันนี้</h5>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6"> 
                                                    <div class="ct-gauge-chart" style="height: 240px;"></div>
                                            </div> 
                                            <div class="col-md-3">
                                                    <h5 class="text-muted">ระดับชั้น</h5>
                                                    <div class="list-group b-0 mail-list"> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-info m-r-10"></span>ป.1</a> 
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-warning m-r-10"></span>ป.2</a> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-purple m-r-10"></span>ป.3</a> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-danger m-r-10"></span>ป.4</a> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-success m-r-10"></span>ป.5</a> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-purple m-r-10"></span>ป.6</a> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-danger m-r-10"></span>อ.1</a> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-success m-r-10"></span>อ.2</a>
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-success m-r-10"></span>อ.3</a>
                                                    </div>
                                                        
                                                    
                                            </div>
                                            <div class="col-md-3">
                                                    <h5 class="text-muted ">อัตราส่วน</h5>
                                                    <div class="list-group b-0 mail-list"> 
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">20</a> 
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">10</a> 
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">10</a>
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">10</a>
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">15</a>
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">10</a>
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">5</a>
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">5</a>
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">5</a>
                                                        
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Column -->
                            <!-- Column -->
                            <div class="col-lg-4 col-md-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex m-b-40 align-items-center no-block">
                                            <h5 class="card-title ">นักเรียนที่ไม่มาโรงเรียนวันนี้</h5>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6"> 
                                                    <div class="ct-gauge-chart2" style="height: 240px;"></div>
                                            </div> 
                                            <div class="col-md-3">
                                                    <h5 class="text-muted">ระดับชั้น</h5>
                                                    <div class="list-group b-0 mail-list"> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-info m-r-10"></span>ป.1</a> 
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-warning m-r-10"></span>ป.2</a> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-purple m-r-10"></span>ป.3</a> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-danger m-r-10"></span>ป.4</a> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-success m-r-10"></span>ป.5</a> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-purple m-r-10"></span>ป.6</a> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-danger m-r-10"></span>อ.1</a> 
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-success m-r-10"></span>อ.2</a>
                                                        <a href="javascript:void(0)" class="list-group-item" style="padding:0!important;border:0px;margin:7px 0;"><span class="fa fa-circle text-success m-r-10"></span>อ.3</a>
                                                    </div>
                                                        
                                                    
                                            </div>
                                            <div class="col-md-3">
                                                    <h5 class="text-muted ">อัตราส่วน</h5>
                                                    <div class="list-group b-0 mail-list"> 
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">20</a> 
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">10</a> 
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">10</a>
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">10</a>
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">15</a>
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">10</a>
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">5</a>
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">5</a>
                                                        <a href="javascript:void(0)" class="list-group-item"  style="padding:0!important;border:0px;margin:7px 0;">5</a>
                                                        
                                                    </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                            </div>
                            <!-- Column -->
                            <div class="col-lg-4 col-md-12">
                                <div class="row">
                                    <!-- Column -->
                                    <div class="col-md-12">
                                        <div class="card bg-cyan text-white">
                                            <div class="card-body ">
                                                <div class="row weather">
                                                    <div class="col-6 m-t-40">
                                                        <h3>&nbsp;</h3>
                                                        <div class="display-4">10<sup> +</sup></div>
                                                        <p class="text-white">ดูรายละเอียด</p>
                                                    </div>
                                                    <div class="col-6 text-right">
                                                        <h1 class="m-b-"><i class="far fa-grin"></i></h1>
                                                        <b class="text-white">เพิ่มคะแนนความประพฤติ</b>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Column -->
                                    <!-- Column -->
                                    <div class="col-md-12">
                                        <div class="card bg-primary text-white">
                                            <div class="card-body ">
                                                <div class="row weather">
                                                    <div class="col-6 m-t-40">
                                                        <h3>&nbsp;</h3>
                                                        <div class="display-4">2<sup> -</sup></div>
                                                        <p class="text-white">ดูรายละเอียด</p>
                                                    </div>
                                                    <div class="col-6 text-right">
                                                        <h1 class="m-b-"><i class="far fa-frown"></i></i></h1>
                                                        <b class="text-white">ลดคะแนนความประพฤติ</b>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Column -->
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- Over Visitor, Our income , slaes different and  sales prediction -->
                        <!-- ============================================================== -->
                        <!--  graph -->
                        <div class="row">
                            <!-- Column -->
                            <div class="col-lg-12 col-md-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex m-b-40 align-items-center no-block">
                                            <h5 class="card-title ">สรุปจำนวนนักเรียนที่มาโรงเรียนในปี 2019</h5>
                                            <div class="ml-auto">
                                                <ul class="list-inline font-12">
                                                    <li><i class="fa fa-circle text-cyan"></i> ป.1</li>
                                                    <li><i class="fa fa-circle text-primary"></i> ป.2</li>
                                                    <li><i class="fa fa-circle text-primary"></i> ป.3</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div id="morris-area-chart3" style="height: 340px;"></div>
                                    </div>
                                </div>
                            </div>
                            <!-- Column -->
                        </div>
                        <!-- graph -->
                    
                    </div>
                    <!-- Column -->
                </div>
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
