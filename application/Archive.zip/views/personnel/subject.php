<?php

?>

                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                <?php 
                //console($profile);
                ?>
                    <div class="col-lg-12 col-xlg-9 col-md-7">
                    
                        <div class="card">
                            <div class="tab-content" id="content_div">
                                <div class="tab-pane active" id="home" role="tabpanel">
                                    <div class="card-body">
                                        <div class="row">
                                               
                                                    
                                                    <?php 
                                                    //console($profile);
                                                    if(isset($profile)&&!empty($profile))
                                                    {
                                                        foreach($profile as $row){
                                                    ?>
                                                    <div class="col-lg-12 col-md-12 col-xlg-2 col-xs-12">
                                                        <div class="ribbon-wrapper card">
                                                        <div class="ribbon ribbon-bookmark ribbon-success "><?php echo $row->subject_name;?></div>
                                                            <div class="table-responsive">
                                                                <table class="table">
                                                                    <tbody class="text-muted">
                                                                       <?php 
                                                                       foreach($row->classroom as $temp){
                                                                       ?> 
                                                                        <tr>
                                                                            <td width="20%">
                                                                                <a target="_blank" href=""><?php echo $temp->education_sublevel_name_th?> </a>
                                                                            </td>
                                                                            <td width="20%"><?php echo $temp->room?></td>
                                                                            <td width="30%">
                                                                                <a target="_blank" href="<?php echo base_url('classroom/classroomProfile/');?>" data-toggle="tooltip" > <i class="fa fa-list-ol text-purple m-r-10"> จัดการคะแนน</i> </a>
                                                                            </td>
                                                                        </tr>
                                                                        <?php 
                                                                       }
                                                                        ?>
                                                                        
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        </div>
                                                    </div>     
                                                    <?php 
                                                        }
                                                    }
                                                    ?>    
                                                       
                                            </div>
                                        </div>    
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- card -->                                       

                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

<!-- modal -->
<div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog modal-md" >
                                                        <div class="modal-content">
                                                            <div class="modal-header alert-success">
                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> แก้ไขข้อมูล</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post" action="cus_order_add.php" >
                                                                    <div class="row m-t-10">
                                                                        <input type="hidden" id="id" value="<?php echo @$profile->id;?>"> 
                                                                        
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                ชื่อ
                                                                        </div>
                                                                        <div class="col-md-5" >
                                                                                <input type="text" id="name" class="form-control text-muted" value="<?php echo @$profile->firstname_th;?>">     
                                                                        </div>
                                                                    </div>
                                                                    <div class="row m-t-15">
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                นามสกุล
                                                                        </div>
                                                                        <div class="col-md-5" >
                                                                                <input type="text" id="lastname" class="form-control text-muted" value="<?php echo @$profile->lastname_th;?>">     
                                                                        </div>
                                                                    </div>
                                                                    <div class="row m-t-15">
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                โทรศัพท์
                                                                        </div>
                                                                        <div class="col-md-4" >
                                                                                <input type="text" id="cellphone" class="form-control text-muted" value="<?php echo @$profile->cell_phone;?>">     
                                                                        </div>
                                                                    </div>
                                                                    <div class="row m-t-15">
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;" >
                                                                                e-mail
                                                                        </div>
                                                                        <div class="col-md-8">
                                                                                <input type="text" id="email" class="form-control text-muted" style="padding-top: 7px;" value="<?php echo @$profile->email;?>">  
                                                                        </div>
                                                                    </div>
                                                                    <hr style="margin-top:21px;">
                                                                    <div class="text-right m-b-10">
                                                                        <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                        <button type="button" class="btn btn-success waves-effect waves-light alert-success" id="submit_btn">บันทึก</button>
                                                                    </div>
                                                                </form>    
                                                            </div>
                                                                
                                                        </div>
                                                    </div>
            </div>
            <!-- modal -->


<!-- Modal -->
<div id="successModal" class="modal fade center" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                        <div class="modal-dialog modal-sm" >
                                                    <div class="alert alert-success">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                                                    <h3 class="text-success"><i class="fa fa-check-circle"></i> 
                                                    Success</h3> ระบบได้ทำรายการเรียบร้อยแล้ว
                                                    </div>
                                        </div>
</div> 
<div id="errorModal" class="modal fade center" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                        <div class="modal-dialog modal-sm" >
                                                    <div class="alert alert-danger">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                                                    <h3 class="text-denger"><i class="fa fa-exclamation-triangle">
                                                    </i> Error</h3>  ระบบไม่สามารถทำรายการได้ กรุณาลองใหม่อีกครั้ง
                                                    </div>
                                        </div>
</div>                                        
<!-- Modal --> 

<script>
$("#submit_btn").click(function(){
                        
                        id = document.getElementById("id").value;
                        name = document.getElementById("name").value;
                        lastname = document.getElementById("lastname").value;
                        cellphone = document.getElementById("cellphone").value;
                        email = document.getElementById("email").value;
                        
                        $.ajax({
                            type: 'POST',
                            url: '<?php echo base_url('personnel/')?>updateMiniProfile',
                            data: 'id='+id+'&name='+name+'&lastname='+lastname+'&cellphone='+cellphone+'&email='+email,
                            success: function(result) {  
                                
                                if(result==true )
                                {
                                    $("#successModal").modal('toggle'); 
                                } 
                                else $("#errorModal").modal('toggle'); 
                                $('#responsive-modal').modal('hide');
                                setTimeout(function(){
                                    location.reload();
                                }, 1000);
                                
                            }
                        });
                    });
</script>                                                            