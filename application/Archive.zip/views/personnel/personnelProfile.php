<?php
defined('BASEPATH') or exit('No direct script access allowed');
$name_title = @$profile->name_title_th;
$firstname = @$profile->firstname_th;
$lastname = @$profile->lastname_th;
$profile_img = @$profile->profile_ing_url;
$personnel_group_title = @$profile->personnel_group_title;
$subject_group_name_th = @$profile->subject_group_name_th;

$cell_phone = @$profile->cell_phone;
$email = @$profile->email;

//profile
$name_title_th = @$profile->name_title_th;
$firstname_th = @$profile->firstname_th;
$lastname_th = @$profile->lastname_th;
$name_title_en = @$profile->name_title_en;
$firstname_en = @$profile->firstname_en;
$lastname_en = @$profile->lastname_en;
$nickname = @$profile->nickname;

$student_no = @$profile->student_no;
$id_card = @$profile->id_card;
$id_1 = substr($id_card,0,1);
$id_2 = substr($id_card,1,4);
$id_3 = substr($id_card,5,5);
$id_4 = substr($id_card,10,2);
$id_5 = substr($id_card,12,1);
$birthdate = @$profile->birthdate;
$blood_type = @$profile->blood_type;
$congenital_disease = @$profile->congenital_disease;
$nationality = @$profile->nationality;
$race = @$profile->race;
$religion = @$profile->religion;

$address = @$profile->address;
$province_name = @$profile->province_name;
$district_name = @$profile->district_name;
$subdistrict_name = @$profile->subdistrict_name;
$zipcode = @$profile->zipcode;
$home_latitude = @$profile->home_latitude;
$home_longitude = @$profile->home_longitude;

$behavior_point = @$profile->behavior_point;

//console($profile);
?>

                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                <?php 
                //console($profile);
                ?>
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        <div class="card">
                            <div class="card-body">
                                <center class="m-t-30"> <img src="<?php echo $profile_img;?>" class="img-circle" width="150" />
                                    <h4 class="card-title m-t-10"><?php echo $name_title;?> <?php echo $firstname;?> <?php echo $lastname;?></h4>
                                </center>
                                <h6 class="text-muted">ฝ่าย : <span style="padding-left:7px;"><?php echo $personnel_group_title;?></span></h6> 
                                <h6 class="text-muted">หมวด : <span style="padding-left:7px;"><?php echo $subject_group_name_th;?></span></h6> 
                            
                            </div>
                            <div>
                                <hr> 
                            </div>
                            <div class="card-body"> 
                            <h6 class="text-muted">เบอร์โทรศัพท์ : <span style="padding-left:7px;"><?php echo $cell_phone;?></span></h6> 
                            <h6 class="text-muted">e-mail : <span style="padding-left:7px;"><?php echo $email;?></span></h6> 
                            <center>
                                <button type="button" class="btn btn-danger btn-rounded btn-xs" data-toggle="modal" data-target="#responsive-modal"><i class="fa fa-pencil"></i> แก้ไขข้อมูล</button>
                            </center>
                            </div>
                            <div>
                                <hr> 
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                    <!--
                    <div class="card">
                           <div class="card-body bg-light">
                                <div class="row">
                                    <div class="col-6">
                                        <h3>March 2017</h3>
                                        <h5 class="font-light m-t-0">Report for this month</h5></div>
                                    <div class="col-6 align-self-center display-6 text-right">
                                        <h2 class="text-success">$3,690</h2></div>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>ระดับชั้น</th>
                                            <th>ทั้งหมด</th>
                                            <th>มาเรียน</th>
                                            <th>มาสาย</th>
                                            <th>ขาด/ลา</th>
                                            <th>กลับก่อน</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="txt-oflo">Elite admin</td>
                                            <td><span class="text-success">$24</span></td>
                                            <td><span class="text-success">$24</span></td>
                                            <td><span class="text-success">$24</span></td>
                                            <td><span class="text-success">$24</span></td>
                                            <td><span class="text-success">$24</span></td>
                                        </tr>
                                        <tr>
                                            <td class="txt-oflo">Elite admin</td>
                                            <td><span class="text-success">$24</span></td>
                                            <td><span class="text-success">$24</span></td>
                                            <td><span class="text-success">$24</span></td>
                                            <td><span class="text-success">$24</span></td>
                                            <td><span class="text-success">$24</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        -->
                        <!-- card -->
                        <div class="card">
                            <div class="tab-content" id="content_div">
                                <div class="tab-pane active" id="home" role="tabpanel">
                                    <div class="card-body">
                                        <div class="row">
                                               <div class="col-lg-12 col-md-12 col-xlg-2 col-xs-12">
                                                    <form class="form-horizontal" role="form">
                                                        <div class="ribbon-wrapper card">
                                                        <div class="ribbon ribbon-bookmark ribbon-success ">ประจำชั้น</div>
                                                            <?php 
                                                            if(isset($profile->classroom)&&!empty($profile->classroom))
                                                            {
                                                            ?>
                                                            <div class="table-responsive">
                                                                <table class="table">
                                                                    <tbody class="text-muted">
                                                                        <?php 
                                                                        foreach( $profile->classroom as $row ){
                                                                        ?>
                                                                        <tr>
                                                                            <td width="30%">
                                                                                <a target="_blank" href="<?php echo base_url('classroom/classroomProfile/').$row->id;?>"><?php echo $row->education_sublevel_name_th;?></a>
                                                                            </td>
                                                                            <td width="30%">ห้อง <?php echo $row->room;?></td>
                                                                            <td width="20%">
                                                                                <a target="_blank" href="<?php echo base_url('classroom/classroomProfile/').$row->id;?>" data-toggle="tooltip" > <i class="fa fa-eye text-success m-r-10"></i> </a>
                                                                            </td>
                                                                        </tr>
                                                                        <?php 
                                                                        }
                                                                        ?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                            <?php 
                                                            }
                                                            ?>
                                                        </div>
                                                        <div class="ribbon-wrapper card">
                                                        <div class="ribbon ribbon-bookmark ribbon-info ">วิชาที่สอน</div>
                                                        <?php 
                                                            if(isset($profile->subject)&&!empty($profile->subject))
                                                            {
                                                            ?>
                                                            <div class="table-responsive">
                                                                <table class="table">
                                                                    <tbody class="text-muted">
                                                                        <?php 
                                                                        foreach( $profile->subject as $row ){
                                                                        ?>
                                                                        <tr>
                                                                            <td width="30%"><?php echo $row->subject_id;?></td>
                                                                            <td width="30%"><?php echo $row->name_th;?></td>
                                                                            <td width="20%">

                                                                                <a style="cursor:pointer;" onclick="" data-toggle="tooltip" data-title="ประเมิน"> <i class="fa fa-edit (alias) text-success m-r-10"> </i> </a>
                                                                                <a style="cursor:pointer;" onclick="" data-toggle="tooltip" data-title="ประเมิน"> <i class="fa fa-edit (alias) text-success m-r-10"> </i> </a>
                                                                                
                                                                                <!--
                                                                                <a href="<?php echo base_url('subject/subjectEdit/').$row->id;?>" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" > <i class="fa fa-pencil text-danger m-r-10"></i> </a>
                                                                                <a target="_blank" href="<?php echo base_url('subject/subjectEdit/').$row->id;?>" data-toggle="tooltip" data-original-title="แก้ไข"> <i class="fa fa-pencil text-danger"></i> </a>
                                                                                -->
                                                                            </td>
                                                                        </tr>
                                                                        <?php 
                                                                        }
                                                                        ?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                            <?php 
                                                            }
                                                            ?>
                                                        </div>
                                                        <!--
                                                        <hr class="m-t-0 m-b-20">
                                                        <div class="row">
                                                                    <div class="col-12">
                                                                        <div class="form-group row">

                                                                            <div class="offset-md-7 col-md-1">
                                                                                 <button class="btn btn-danger pull-right" input type="reset" >ยกเลิก</button>
                                                                                
                                                                            </div>    
                                                                            <div class="offset-md-1 col-md-1">
                                                                                 <button class="btn btn-success pull-right btn-outline" input type="submit"> บันทึก</button>
                                                                            </div>     
                                                                        </div>
                                                                    </div>
                                                        </div> 
                                                        -->          
                                                    </form>
                                                </div> 
                                            </div>
                                        </div>    
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- card -->                                       

                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

<!-- modal -->
<div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog modal-md" >
                                                        <div class="modal-content">
                                                            <div class="modal-header alert-success">
                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> แก้ไขข้อมูล</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post" action="cus_order_add.php" >
                                                                    <div class="row m-t-10">
                                                                        <input type="hidden" id="id" value="<?php echo @$profile->id;?>"> 
                                                                        
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                ชื่อ
                                                                        </div>
                                                                        <div class="col-md-5" >
                                                                                <input type="text" id="name" class="form-control text-muted" value="<?php echo @$profile->firstname_th;?>">     
                                                                        </div>
                                                                    </div>
                                                                    <div class="row m-t-15">
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                นามสกุล
                                                                        </div>
                                                                        <div class="col-md-5" >
                                                                                <input type="text" id="lastname" class="form-control text-muted" value="<?php echo @$profile->lastname_th;?>">     
                                                                        </div>
                                                                    </div>
                                                                    <div class="row m-t-15">
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                โทรศัพท์
                                                                        </div>
                                                                        <div class="col-md-4" >
                                                                                <input type="text" id="cellphone" class="form-control text-muted" value="<?php echo @$profile->cell_phone;?>">     
                                                                        </div>
                                                                    </div>
                                                                    <div class="row m-t-15">
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;" >
                                                                                e-mail
                                                                        </div>
                                                                        <div class="col-md-8">
                                                                                <input type="text" id="email" class="form-control text-muted" style="padding-top: 7px;" value="<?php echo @$profile->email;?>">  
                                                                        </div>
                                                                    </div>
                                                                    <hr style="margin-top:21px;">
                                                                    <div class="text-right m-b-10">
                                                                        <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                        <button type="button" class="btn btn-success waves-effect waves-light alert-success" id="submit_btn">บันทึก</button>
                                                                    </div>
                                                                </form>    
                                                            </div>
                                                                
                                                        </div>
                                                    </div>
            </div>
            <!-- modal -->


<!-- Modal -->
<div id="successModal" class="modal fade center" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                        <div class="modal-dialog modal-sm" >
                                                    <div class="alert alert-success">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                                                    <h3 class="text-success"><i class="fa fa-check-circle"></i> 
                                                    Success</h3> ระบบได้ทำรายการเรียบร้อยแล้ว
                                                    </div>
                                        </div>
</div> 
<div id="errorModal" class="modal fade center" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                        <div class="modal-dialog modal-sm" >
                                                    <div class="alert alert-danger">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                                                    <h3 class="text-denger"><i class="fa fa-exclamation-triangle">
                                                    </i> Error</h3>  ระบบไม่สามารถทำรายการได้ กรุณาลองใหม่อีกครั้ง
                                                    </div>
                                        </div>
</div>                                        
<!-- Modal --> 

<script>
$("#submit_btn").click(function(){
                        
                        id = document.getElementById("id").value;
                        name = document.getElementById("name").value;
                        lastname = document.getElementById("lastname").value;
                        cellphone = document.getElementById("cellphone").value;
                        email = document.getElementById("email").value;
                        
                        $.ajax({
                            type: 'POST',
                            url: '<?php echo base_url('personnel/')?>updateMiniProfile',
                            data: 'id='+id+'&name='+name+'&lastname='+lastname+'&cellphone='+cellphone+'&email='+email,
                            success: function(result) {  
                                
                                if(result==true )
                                {
                                    $("#successModal").modal('toggle'); 
                                } 
                                else $("#errorModal").modal('toggle'); 
                                $('#responsive-modal').modal('hide');
                                setTimeout(function(){
                                    location.reload();
                                }, 1000);
                                
                            }
                        });
                    });
</script>                                                            