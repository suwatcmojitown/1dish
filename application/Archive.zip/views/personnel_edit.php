<?php
defined('BASEPATH') or exit('No direct script access allowed');
$id_card = @$profile->id_card;
$id_1 = substr($id_card,0,1);
$id_2 = substr($id_card,1,4);
$id_3 = substr($id_card,5,5);
$id_4 = substr($id_card,10,2);
$id_5 = substr($id_card,12,1);
?>

                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">
                        <div class="card-body">
                                <?php //console($profile);?>

                                <form action="<?php echo base_url('setting/')?>personnelUpdate" class="form-horizontal" method="post" enctype="multipart/form-data" >
                                    <div class="form-body">
                                        <div class="card-header badge-success">
                                        <h4 class="m-b-0 text-white">แก้ไข ข้อมูลบุคลากร</h4></div>
                                        <h3 class="box-title"></h3>
                                        <div class="m-t-0 m-b-20"></div>
                                        <h4 class="box-title">รายละเอียดตำแหน่ง</h4>
                                        <hr class="m-t-0 m-b-30">
                                        <!--/row-->
                                        <input type="hidden" name="id" value="<?php echo $profile->id;?>">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary" style="padding-left:14px;padding-top:7px;">ตำแหน่ง</label>
                                                    <div class="col-md-9">
                                                        <select class="form-control custom-select text-muted" id="personnel_group_id" name="personnel_group_id" >
                                                                            <option value="0">--เลือก--</option>
                                                                            <?php 
                                                                            if(isset($personnelGroupList)&&!empty($personnelGroupList)){
                                                                                foreach($personnelGroupList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>" <?php if($profile->personnel_group_id==$row->id) echo "selected"; ?>><?php echo $row->title;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row--> 
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary" style="padding-left:14px;padding-top:7px;">หมวด</label>
                                                    <div class="col-md-9">
                                                        <select class="form-control custom-select text-muted" id="subject_group_id" name="subject_group_id" required>
                                                                            <option value="0">--เลือก--</option>
                                                                            <?php 
                                                                            if(isset($subjectGroupList)&&!empty($subjectGroupList)){
                                                                                foreach($subjectGroupList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>" <?php if($profile->subject_group_id==$row->id) echo "selected"; ?>><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <h4 class="box-title">รายละเอียดส่วนตัว</h4>
                                        <hr class="m-t-0 m-b-20">   
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-6 text-primary p-t-5">คำนำหน้า</label>
                                                    <div class="col-md-6">
                                                        <select class="form-control custom-select text-muted" name="name_title_th" data-placeholder="Choose a Category" tabindex="1" >
                                                            <option value="0">--เลือก--</option>
                                                            <option value="นาย" <?php if($profile->name_title_th=='นาย') echo "selected"; ?>>นาย</option>
                                                            <option value="นาง" <?php if($profile->name_title_th=='นาง') echo "selected"; ?>>นาง</option>
                                                            <option value="นางสาว" <?php if($profile->name_title_th=='นางสาว') echo "selected"; ?>>นางสาว</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-4 text-primary p-t-5">ชื่อ</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="firstname_th" name="firstname_th" class="form-control" placeholder="กรอกชื่อ" value="<?php echo @$profile->firstname_th;?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-4 text-primary p-t-5">นามสกุล</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="lastname_th" name="lastname_th" class="form-control" placeholder="กรอกนามสกุล" value="<?php echo @$profile->lastname_th;?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-6 text-primary p-t-5">คำนำหน้า Eng</label>
                                                    <div class="col-md-6">
                                                        <select class="form-control custom-select text-muted" name="name_title_en" data-placeholder="Choose a Category" tabindex="1">
                                                            <option value="0">--เลือก--</option>
                                                            <option value="Mr." <?php if($profile->name_title_en=='Mr.') echo "selected"; ?>>Mr.</option>
                                                            <option value="Mrs." <?php if($profile->name_title_en=='Mrs.') echo "selected"; ?>>Mrs.</option>
                                                            <option value="Miss." <?php if($profile->name_title_en=='Miss.') echo "selected"; ?>>Miss.</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-4 text-primary p-t-5">ชื่อ Eng</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="firstname_en" name="firstname_en" class="form-control" placeholder="กรอกชื่อ" value="<?php echo @$profile->firstname_en;?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-4 text-primary p-t-5">นามสกุล Eng</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="lastname_en" name="lastname_en" class="form-control" placeholder="กรอกนามสกุล" value="<?php echo @$profile->firstname_en;?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="m-t-20"></div>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-2 text-primary p-t-5 m-r-15">รหัสประชาชน</label>
                                                    <div class="col-md-1">
                                                        <input type="text" id="txtID1" name="txtID1" class="form-control" maxlength=1 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" value="<?php echo @$id_1;?>">
                                                    </div>
                                                    <span class="p-t-5">-</span>   
                                                    <div class="col-md-2">
                                                        <input type="text" id="txtID2" name="txtID2" class="form-control" maxlength=4 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" value="<?php echo @$id_2;?>">  
                                                    </div>
                                                    <span class="p-t-5">-</span> 
                                                    <div class="col-md-2">
                                                        <input type="text" id="txtID3" name="txtID3" class="form-control" maxlength=5 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" value="<?php echo @$id_3;?>" >  
                                                    </div>
                                                    <span class="p-t-5">-</span> 
                                                    <div class="col-md-2">
                                                        <input type="text" id="txtID4" name="txtID4" class="form-control" maxlength=2 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" value="<?php echo @$id_4;?>"> 
                                                    </div> 
                                                    <span class="p-t-5">-</span> 
                                                    <div class="col-md-1">
                                                        <input type="text" id="txtID5" name="txtID5" class="form-control" maxlength=1 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" value="<?php echo @$id_5;?>"> 
                                                    </div>
                                                       
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-6 text-primary p-t-5">เพศ</label>
                                                    <div class="col-md-6">
                                                        <select class="form-control custom-select text-muted" id="gender" name="gender" data-placeholder="Choose a Category" tabindex="1" >
                                                            <option value="">-- เลือก --</option>
                                                                            <option value="1" <?php if($profile->gender=='1') echo "selected"; ?>>ชาย</option>
                                                                            <option value="2" <?php if($profile->gender=='2') echo "selected"; ?>>หญิง</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="offset-md-1 col-md-4">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-4 text-primary p-t-5">วันเกิด</label>
                                                    <div class="col-md-8">
                                                         <input type="date" class="form-control text-muted" placeholder="กรอกวันเกิด" id="birthdate" name="birthdate" value="<?php echo @$profile->birthdate;?>" >
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <div class="m-t-20"></div>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-10">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-2 text-primary p-t-5">รูปภาพ</label>
                                                    <div class="col-md-6" style="margin-left:-15px;">
                                                        <input type="file" id="myfile" name="myfile" class="form-control">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <img src="<?php echo @$profile->profile_ing_url;?>" style="width:100px;"> 
                                                        <input type="hidden" id="profile_img" name="profile_img" class="form-control" value="<?php echo @$profile->profile_img;?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>    
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary p-t-5">E-mail</label>
                                                    <div class="col-md-6">
                                                        <input type="text" id="email" name="email" class="form-control" placeholder="กรอก E-mail" value="<?php echo @$profile->email;?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>    
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary p-t-5">เบอร์มือถือ</label>
                                                    <div class="col-md-6">
                                                        <input type="text" id="cell_phone" name="cell_phone" class="form-control" placeholder="กรอกเบอร์มือถือ" value="<?php echo @$profile->cell_phone;?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary p-t-5">เบอร์โทรศัพท์</label>
                                                    <div class="col-md-6">
                                                        <input type="text" id="tel" name="tel" class="form-control" placeholder="กรอกเบอร์โทรศัพท์" value="<?php echo @$profile->tel;?>">
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        <!--/row-->
                                        <h4 class="box-title">รายละเอียดการเข้าใช้งาน</h4>
                                        <hr class="m-t-0 m-b-40">
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary" style="padding-left:14px;padding-top:7px;">สิทธิ์การใช้งาน</label>
                                                    <div class="col-md-9">
                                                        <select class="form-control custom-select text-muted" id="permission_id" name="permission_id" >
                                                                            <option value="0">--เลือก--</option>
                                                                            <?php 
                                                                            if(isset($permissionList)&&!empty($permissionList)){
                                                                                foreach($permissionList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>" <?php if($profile->permission_id==$row->id) echo "selected"; ?>><?php echo $row->title;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <!--/row-->
                                        <h4 class="box-title">สถานะ</h4>
                                        <hr class="m-t-0 m-b-40">
                                        <!--/row--> 
                                        <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-3 text-primary" style="padding-left: 14px;">สถานะ</label>
                                                            <div class="col-md-4">
                                                                <select class="form-control custom-select text-muted" name="status" data-placeholder="" tabindex="1">
                                                                    <option value="0" <?php if($profile->status=='0') echo "selected"; ?>>เลิกสอน</option>
                                                                    <option value="1" <?php if($profile->status=='1') echo "selected"; ?>>กำลังสอน</option>
                                                                    <option value="2" <?php if($profile->status=='2') echo "selected"; ?>>ลาออก</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                        </div>
                                        <!--/row-->
                                        <!--
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary p-t-5">รหัสผ่าน</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="password" name="password" class="form-control" placeholder="กรอกรหัสเข้าใช้งาน" value="<?php echo $profile->password;?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        -->
                                         <!--/row-->
                                         <!--
                                        <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-3 text-primary" style="padding-left: 14px;">สถานะ</label>
                                                            <div class="col-md-9">
                                                                <div class="form-check form-check-inline text-muted">
                                                                      <input class="form-check-input" type="radio" name="status" id="status_1" value="1" checked>
                                                                      <label class="form-check-label" for="inlineRadio1">ใช้งาน</label>
                                                                </div>
                                                                <div class="form-check form-check-inline text-muted">
                                                                      <input class="form-check-input" type="radio" name="status" id="status_2" value="0">
                                                                      <label class="form-check-label" for="inlineRadio2">ยกเลิก</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                        </div>
                                         -->
                                        <!--/row-->
                                    </div>
                                    <hr class="m-t-0 m-b-20">
                                        <div class="row">
                                                    <div class="col-12">
                                                        <div class="form-group row">

                                                            <div class="offset-md-9 col-md-1">
                                                                 <button class="btn btn-danger pull-right" input type="reset" >ยกเลิก</button>
                                                                
                                                            </div>    
                                                            <div class="col-md-1">
                                                                 <button class="btn btn-success pull-right btn-outline" input type="submit"> บันทึก</button>
                                                            </div>     
                                                        </div>
                                                    </div>
                                        </div>
                                </form>
                                <!--- form -->
                            </div>
                            <!-- card body -->    
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

<script type="text/javascript"> 
    function Numbers(e){
        var keynum;
        var keychar;
        var numcheck;
        if(window.event) {// IE
        keynum = e.keyCode;
        }
        else if(e.which) {// Netscape/Firefox/Opera
        keynum = e.which;
        }
        if(keynum == 13 || keynum == 8 || typeof(keynum) == "undefined"){
                return true;
        }
        keychar= String.fromCharCode(keynum);
        numcheck = /^[0-9]$/;
        return numcheck.test(keychar);
    }

    function keyup(obj,e){
        var keynum;
        var keychar;
        var id = '';
        if(window.event) {// IE
        keynum = e.keyCode;
        }
        else if(e.which) {// Netscape/Firefox/Opera
        keynum = e.which;
        }
        keychar= String.fromCharCode(keynum); 

        var tagInput = document.getElementsByTagName('input');
        for(i=0;i<=tagInput.length;i++){
            if(tagInput[i] == obj){ 
                var prevObj = tagInput[i-1];
                var nextObj = tagInput[i+1];
                break;
            }
        } 
        if(obj.value.length == 0 && keynum == 8) prevObj.focus();
        
        if(obj.value.length == obj.getAttribute('maxlength')){ 
            for(i=0;i<=tagInput.length;i++){
                if(tagInput[i].id.substring(0,5) == 'txtID'){ 
                    if(tagInput[i].value.length == tagInput[i].getAttribute('maxlength')){
                        id += tagInput[i].value;
                        if(tagInput[i].id == 'txtID5') break;
                    }
                    else{
                        tagInput[i].focus();
                        return;
                    }
                }
            } 
            if(checkID(id)) nextObj.focus();
            else alert('รหัสประชาชนไม่ถูกต้อง');
            nextObj.focus();
        }
        
    }

    function checkID(id){
        if(id.length != 13) return false;
        for(i=0, sum=0; i < 12; i++)
            sum += parseFloat(id.charAt(i))*(13-i); 
        if((11-sum%11)%10!=parseFloat(id.charAt(12)))
            return false; 
        return true;
    }
</script>

    