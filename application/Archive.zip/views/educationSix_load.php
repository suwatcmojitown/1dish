<!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <div class="text-right m-b-10">
                                        <a href="<?php echo base_url('setting/studentCreate').'?clssroom_id='.@$classroom_id;?>"><button class="btn btn-success" type="button" > <span><i class="fa fa-edit (alias)"></i>  import ผลการประเมิน</span> </button> </a>
                                        <a href="<?php echo base_url('setting/studentCreate').'?clssroom_id='.@$classroom_id;?>"><button class="btn btn-success" type="button" > <span><i class="fa fa fa-mixcloud "></i>  import คะแนน O-NET</span> </button> </a>
                                </div>
                                
                                <hr class="m-t-0 m-b-20">
                                <div class="row m-b-15">
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <?php //console($roomList);?>
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ห้อง
                                                </div>
                                                <div class="col-md-2">
                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                        <?php 
                                                        
                                                        if(isset($roomList)&&!empty($roomList)){
                                                            foreach($roomList as $row)
                                                            {
                                                        ?>
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->room;?></option>
                                                                            
                                                        <?php 
                                                            }
                                                        }
                                                        ?>
                                                        </select>
                                                        
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper">
                                        <?php 
                                        //console($studentList);
                                        ?>
                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:10%;">เลขที่</th>
                                                    <th style="width:15%;">เลขประจำตัว</th>
                                                    <th style="width:40%;">ชื่อ - นามสกุล</th>
                                                    <!--<th style="width:15%;">รูปภาพ</th>-->
                                                    <th style="width:30%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                //console($studentList);
                                                if(isset($studentList->studentlist)&&!empty($studentList->studentlist)){
                                                $i = 1;
                                                foreach($studentList->studentlist as $row )
                                                {
                                                ?>
                                                <tr>
                                                    <td><?php echo $row->seat_no;?></td>
                                                    <td><?php echo $row->student_no;?></td>
                                                    <td><?php echo $row->name_th;?></td>
                                                    <!--<td><img src="<?php //echo $row->profile_img_url;?>" style="max-width:100px;">-->
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="<?php echo base_url('assessment/').$row->id;?>" data-toggle="modal" data-target="#responsive-modal-<?php echo $row->id;?>" data-original-title="ประเมิน"> <i class="fa fa-edit (alias) text-success m-r-10"> <span style="font-size:14px;">ประเมิน</span></i> </a>
                                                        <a href="<?php echo base_url('onet/').$row->id;?>" data-toggle="modal" data-target="#responsive-modal-onet-<?php echo $row->id;?>" data-original-title="O-NET"> <i class="fa fa fa-mixcloud text-danger m-r-10"> <span style="font-size:14px;">O-NET</span></i> </a>
                                                        <a href="<?php echo base_url('student/profile/').$row->id;?>" data-toggle="tooltip" data-original-title="ปพ.1"> <i class="fa fa-star text-purple m-r-10"> <span style="font-size:14px;">ปพ.1</span></i> </a>
                                                        <!--
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-warning"></i> </a>
                                                        -->
                                                    </td>
                                                </tr>
                                                <!-- modal -->
                                                <div id="responsive-modal-<?php echo $row->id;?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                                    <div class="modal-dialog modal-lg" >
                                                                        <div class="modal-content">
                                                                            <div class="modal-header alert-success">
                                                                                <h4 class="modal-title"><i class="fa fa-edit (alias)"></i> ประเมิน</h4>
                                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                            </div>
                                                                            <div class="modal-body">
                                                                                <form method="post" action="cus_order_add.php" >
                                                                                    <div class="row">
                                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                                                ผลการประเมินรายวิชาพื้นฐาน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                            <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>      
                                                                                                        </div>
                                                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                                                ผลการตัดสิน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                        <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>    
                                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-t-10"></div>
                                                                                    <div class="row">
                                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                                                ผลการประเมินการอ่าน คิด วิเคราะห์และเขียน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                        <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>      
                                                                                                        </div>
                                                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                                                ผลการตัดสิน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                        <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>    
                                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-t-10"></div>
                                                                                    <div class="row">
                                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                                                ผลการประเมินคุณลักษณะอันพึงประสงค์
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                        <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>      
                                                                                                        </div>
                                                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                                                ผลการตัดสิน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                        <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>    
                                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-t-10"></div>
                                                                                    <div class="row">
                                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                                                ผลการประเมินกิจกรรมพัฒนาผู้เรียน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                        <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>      
                                                                                                        </div>
                                                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                                                ผลการตัดสิน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                        <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>    
                                                                                                        </div>
                                                                                    </div>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <div class="text-right m-b-10">
                                                                                            <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                                            <button type="button" id="addStudentBtn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                                    </div>
                                                                                </form>    
                                                                            </div>
                                                                                
                                                                        </div>
                                                                    </div>
                                </div>
                                <!-- modal -->
                                <!-- modal -->
                                <div id="responsive-modal-onet-<?php echo $row->id;?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                                    <div class="modal-dialog modal-md" >
                                                                        <div class="modal-content">
                                                                            <div class="modal-header alert-danger">
                                                                                <h4 class="modal-title"><i class="fa fa-mixcloud"></i> O-NET</h4>
                                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                            </div>
                                                                            <div class="modal-body">
                                                                                <form method="post" action="cus_order_add.php" >
                                                                                    <?php
                                                                                    //console($onetList); 
                                                                                    if(isset($onetList)&&!empty($onetList)){
                                                                                        foreach($onetList as $row){
                                                                                    ?>
                                                                                    <div class="row">
                                                                                                        <div class="col-md-6 text-danger" style="padding-top: 7px;">
                                                                                                                <?php echo $row->name_th;?>
                                                                                                        </div>
                                                                                                        <div class="col-md-5">
                                                                                                            <input type="text" class="form-control text-muted" placeholder="คะแนน" id="onet-<?php echo $row->id?>" name="onet-<?php echo $row->id?>">
                                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-t-10"></div>
                                                                                    <?php 
                                                                                        }
                                                                                    }
                                                                                    ?>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <div class="text-right m-b-10">
                                                                                            <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                                            <button type="button" id="addStudentBtn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                                    </div>
                                                                                </form>    
                                                                            </div>
                                                                                
                                                                        </div>
                                                                    </div>
                                </div>
                                <!-- modal -->
                                                <?php 
                                                    $i++;
                                                }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    <hr>
                                    
                                </div>
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
                <!-- modal -->
                                <div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                                    <div class="modal-dialog modal-lg" >
                                                                        <div class="modal-content">
                                                                            <div class="modal-header alert-success">
                                                                                <h4 class="modal-title"><i class="fa fa-edit (alias)"></i> ประเมิน</h4>
                                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                            </div>
                                                                            <div class="modal-body">
                                                                                <form method="post" action="cus_order_add.php" >
                                                                                    <div class="row">
                                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                                                ผลการประเมินรายวิชาพื้นฐาน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                            <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>      
                                                                                                        </div>
                                                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                                                ผลการตัดสิน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                        <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>    
                                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-t-10"></div>
                                                                                    <div class="row">
                                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                                                ผลการประเมินการอ่าน คิด วิเคราะห์และเขียน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                        <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>      
                                                                                                        </div>
                                                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                                                ผลการตัดสิน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                        <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>    
                                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-t-10"></div>
                                                                                    <div class="row">
                                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                                                ผลการประเมินคุณลักษณะอันพึงประสงค์
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                        <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>      
                                                                                                        </div>
                                                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                                                ผลการตัดสิน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                        <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>    
                                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-t-10"></div>
                                                                                    <div class="row">
                                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                                                ผลการประเมินกิจกรรมพัฒนาผู้เรียน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                        <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>      
                                                                                                        </div>
                                                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                                                ผลการตัดสิน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                                                                        <option value="1">ดีเยี่ยม</option>
                                                                                                            <option value="1">ดีมาก</option>
                                                                                                            <option value="1">ดี</option>
                                                                                                            <option value="1">ค่อนข้างดี</option>
                                                                                                            <option value="1">ปานกลาง</option>
                                                                                                            <option value="1">พอใช้</option>
                                                                                                            <option value="1">ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="1">ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="1">รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="1">ผ่าน</option>
                                                                                                            <option value="1">ไม่ผ่าน</option>
                                                                                                        </select>    
                                                                                                        </div>
                                                                                    </div>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <div class="text-right m-b-10">
                                                                                            <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                                            <button type="button" id="addStudentBtn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                                    </div>
                                                                                </form>    
                                                                            </div>
                                                                                
                                                                        </div>
                                                                    </div>
                                </div>
                                <!-- modal -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

<script type="text/javascript">    
   $( "#searchStudentBtn").click(function() {
           a = document.getElementById("keysearchStudent").value;
           $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'classroom/searchStudent'?>',
               data: 'keysearch='+a+'&classroom_id=<?php echo $classroom_id;?>',
               success: function(result) {
                   $('#studentList').html(result);
               }
           });      
   });
</script>   