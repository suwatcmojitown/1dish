<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">
                        <div class="card-body">
                                
                                <form action="academicYearAdd" class="form-horizontal" method="post" enctype="multipart/form-data">
                                    <!-- form body -->
                                    <div class="form-body">
                                        <div class="card-header badge-primary">
                                        <h4 class="m-b-0 text-white">เพิ่มปีการศึกษา</h4></div>
                                        <h3 class="box-title"></h3>
                                        <hr class="m-t-0 m-b-20">
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">ปีการศึกษา</label>
                                                            <div class="col-md-3">
                                                                <input type="text" id="name" name="name" class="form-control form-control-line" placeholder="กรอกปีการศึกษา">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">รายละเอียด</label>
                                                            <div class="col-md-9">
                                                                <input type="text" id="description" name="description" class="form-control form-control-line" placeholder="กรอกรายละเอียด">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">วันที่เริ่ม</label>
                                                            <div class="col-md-3 text-muted">
                                                                <input type="date" class="form-control text-muted" placeholder="กรอกวันที่เริ่ม" id="startdate" name="startdate">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-2 text-muted" style="padding-left:14px;padding-top:7px;">วันที่สิ้นสุด</label>
                                                            <div class="col-md-3">
                                                                <input type="date" class="form-control text-muted" placeholder="กรอกวันที่สิ้นสุด" id="enddate" name="enddate">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <hr class="m-t-0 m-b-20">
                                                <div class="row">
                                                    <div class="col-12 m-t-30">
                                                        <div class="form-group row">

                                                            <div class="offset-md-7 col-md-1">
                                                                 <button class="btn btn-danger pull-right" input type="reset" >ยกเลิก</button>
                                                                
                                                            </div>    
                                                            <div class="col-md-2">
                                                                 <button class="btn btn-success pull-right btn-outline" input type="submit"> บันทึก</button>
                                                            </div>     
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>      
                                        <!-- form body -->
                                </form>
                                <!-- form -->
                            </div>
                            <!-- card body -->    
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->


    