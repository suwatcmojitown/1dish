<?php 
//console($result);
?>
<!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">

                            <hr class="m-t-0 m-b-20">
                                <?php 
                                //console($academicYearList);
                                ?>
                                <div class="row m-b-15">
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                        ปีการศึกษา
                                                </div>
                                                <div class="col-md-2">
                                                        <select class="form-control custom-select text-muted" id="academic_year_sec" name="academic_year_sec">
                                                        <?php 
                                                        if(isset($academicYearList)&&!empty($academicYearList)){
                                                            foreach($academicYearList as $row)
                                                            {
                                                        ?>
                                                                            <option value="<?php echo $row->academic_year;?>"><?php echo $row->academic_year;?></option>
                                                                            
                                                        <?php 
                                                            }
                                                        }
                                                        ?>
                                                        </select>
                                                        
                                                </div>
                                            </div>
                                        </div>
                                </div>   
                                <?php //console($result);?>
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper" id="content_div">
                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:10%;">#</th>
                                                    <th style="width:40%;">เกรด</th>
                                                    <th style="width:15%;">คะแนนน้อยสุด</th>
                                                    <th style="width:15%;">คะแนนมากสุด</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                if(isset($result)&&!empty($result))
                                                {
                                                    $i = 1;
                                                    foreach($result as $row)
                                                    {
                                                ?>
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo 'เกรด '.$row->grade;?></td>
                                                    <td><?php echo $row->point_min;?></td>
                                                    <td><?php echo $row->point_max;?></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="javascript:void(0)" data-toggle="modal" data-target="#responsive-modal-<?php echo $row->id;?>" data-original-title="แก้ไข"> <i class="fa fa-pencil text-warning m-r-10"></i> </a>
                                                    </td>
                                                </tr>
                                                <!-- modal -->
                                                <div id="responsive-modal-<?php echo $row->id;?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                                                    <div class="modal-dialog modal-md" >
                                                                                        <div class="modal-content">
                                                                                            <div class="modal-header alert-success">
                                                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> แก้ไขช่วงคะแนนตัดเกรด</h4>
                                                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                                            </div>
                                                                                            <div class="modal-body">
                                                                                                <form method="post" action="rankUpdate" >
                                                                                                    <div class="row">
                                                                                                        <div class="col-md-3 text-success" style="padding-top: 7px;">
                                                                                                                ชื่อ
                                                                                                        </div>
                                                                                                        <div class="col-md-8">
                                                                                                                <input type="text" id="grade" name="grade" class="form-control" value="<?php echo $row->grade;?>" aria-describedby="search-txt" readonly>        
                                                                                                                <input type="hidden" id="id" name="id" class="form-control" value="<?php echo $row->id;?>">
                                                                                                                <input type="hidden" id="academic_year" name="academic_year" class="form-control" value="<?php echo $row->academic_year;?>">
                                                                                                                <input type="hidden" id="status" name="status" class="form-control" value="<?php echo $row->status;?>">
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="m-t-10"></div>
                                                                                                    <div class="row">
                                                                                                        <div class="col-md-3 text-success" style="padding-top: 7px;">
                                                                                                                คะแนนน้อยสุด
                                                                                                        </div>
                                                                                                        <div class="col-md-4">
                                                                                                                <input type="text" id="point_min" name="point_min" class="form-control" placeholder="กรอกคะแนน" aria-describedby="search-txt" value="<?php echo $row->point_min;?>">        
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="m-t-10"></div>
                                                                                                    <div class="row">
                                                                                                        <div class="col-md-3 text-success" style="padding-top: 7px;">
                                                                                                                คะแนนมากสุด
                                                                                                        </div>
                                                                                                        <div class="col-md-4">
                                                                                                                <input type="text" id="point_max" name="point_max" class="form-control" placeholder="กรอกคะแนน" aria-describedby="search-txt" value="<?php echo $row->point_max;?>">        
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div style="margin-top:21px;"></div> 
                                                                                                    <div class="text-right m-b-10">
                                                                                                        <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                                                        <button type="submit" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                                                    </div>
                                                                                                </form>    
                                                                                            </div>
                                                                                                
                                                                                        </div>
                                                                                    </div>
                                                </div>
                                                <!-- modal -->
                                                <?php 
                                                    $i++;
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                            
                                    
                                    <hr>
                                    
                                </div>
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
                
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

        <script>
        $( "#academic_year_sec").change(function() {
            year = document.getElementById("academic_year_sec").value;
            
            $.ajax({
                type: 'POST',
                url: 'rankLoad',
                data: 'year='+year+'',
                success: function(result) { 
                    $("#content_div").html(result);
                }
            });
            
        });

        </script>