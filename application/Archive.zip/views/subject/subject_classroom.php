<!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <div class="text-right m-b-10">
                                        <button class="btn btn-success" type="submit" data-toggle="modal" data-target="#responsive-modal"> <span><i class="fa fa-file-o"></i> เพิ่มคะแนน</span> </button>
                                </div>
                                
                                <hr class="m-t-0 m-b-20">
                                <div class="row m-b-15">
                                        <?php 
                                        //console($profile);
                                        ?>
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <div class="col-md-2 col-xs-6 b-r"> <strong>วิชา</strong>
                                                    <br>
                                                    <p class="text-muted m-t-5"><?php echo @$profile->name_th.' '.@$profile->subject_id;?></p>
                                                </div>
                                                <div class="col-md-2 col-xs-6 b-r"> <strong>ชั้นเรียน</strong>
                                                    <br>
                                                    <p class="text-muted m-t-5"><?php echo @$profile->education_sublevel_name_th;?></p>
                                                </div>
                                                <div class="col-md-2 col-xs-6 b-r"> <strong>กลุ่มสาระ</strong>
                                                    <br>
                                                    <p class="text-muted m-t-5"><?php echo @$profile->subject_group_name_th;?></p>
                                                </div>
                                                <div class="col-md-2 col-xs-6 b-r"> <strong>ประเภท</strong>
                                                    <br>
                                                    <p class="text-muted m-t-5"><?php echo @$profile->subject_type_name_th;?></p>
                                                </div>
                                                <div class="col-md-2 col-xs-6 m-t-5"> <strong>หน่วยกิจ</strong>
                                                    <br>
                                                    <p class="text-muted"><?php echo @$profile->unit;?></p>
                                                </div>
                                                <div class="col-md-2 col-xs-6 m-t-5"> <strong>ครูผู้สอน</strong>
                                                    <br>
                                                    <p class="text-muted"><?php echo @$profile->personnel[0]->name_th;?></p>
                                                </div>
                                            </div>
                                            <!--
                                            <div class="m-b-20"></div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                        <input type="text" id="search" name="search" class="form-control" placeholder="กรอกคำค้นหา">
                                                </div>
                                                <div class="col-md-2">
                                                      <button type="button" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>
                                            </div>
                                            -->
                                        </div>
                                </div>

                                <hr class="m-t-0 m-b-20">

                                <div class="text-left m-b-10">
                                        <span class="badge badge-success" style="font-size:15px;"><i class="fa fa-fort-awesome"></i> รายชื่อนักเรียน <?php echo $classroom_profile->education_sublevel_name_th;?> ห้อง <?php echo $classroom_profile->room;?></span> 
                                </div>
                                
                                
                                
                                
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper">
                                        <?php 
                                        //console($classroom_profile);
                                        ?>
                                        <table class="table color-table purple-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:4%;">#</th>
                                                    <th style="width:20%;">ชื่อ - นามสกุล</th>
                                                    <th>เทอม </th>
                                                    <th>คะแนนเก็บ</th>
                                                    <th>กลางภาค</th>
                                                    <th>ปลายภาค</th>
                                                    <th>เกรด</th>
                                                    <th>เทอม </th>
                                                    <th>คะแนนเก็บ</th>
                                                    <th>กลางภาค</th>
                                                    <th>ปลายภาค</th>
                                                    <th>เกรด</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                //console($studentList);
                                                if(isset($studentList->student)&&!empty($studentList->student)){
                                                $i = 1;
                                                foreach($studentList->student as $row )
                                                {
                                                ?>
                                                <tr>
                                                    <td><?php echo $row->seat_no;?></td>
                                                    <td><?php echo $row->student_name;?></td>
                                                    <td style="color:#00c292";><strong>1</strong></td>
                                                    <td><?php echo @$row->score->term_1->test_score;?></td>
                                                    <td><?php echo @$row->score->term_1->midterm_score;?></td>
                                                    <td><?php echo @$row->score->term_1->finalterm_score;?></td>
                                                    <td><?php echo @$row->score->term_1->grade;?></td>
                                                    <td style="color:#00c292";><strong>2</strong></td>
                                                    <td><?php echo @$row->score->term_2->test_score;?></td>
                                                    <td><?php echo @$row->score->term_2->midterm_score;?></td>
                                                    <td><?php echo @$row->score->term_2->finalterm_score;?></td>
                                                    <td><?php echo @$row->score->term_2->grade;?></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a style="cursor:pointer;" alt="O-NET" onclick="myFunction()" data-toggle="tooltip" data-original-title="แก้ไขคะแนน"> <i class="fa fa-list-ol text-danger m-r-10"> <span style="font-size:14px;">แก้ไข</span></i> </a>
                                                        
                                                    </td>
                                                </tr>
                                                <?php 
                                                    $i++;
                                                }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                       
                                    <hr>
                                    
                                </div>
                            </div>        
                            <!-- modal -->
                            <div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                            <div class="modal-dialog modal-md" >
                                                                        <div class="modal-content">
                                                                            <div class="modal-header alert-success">
                                                                                <h4 class="modal-title"><i class="fa fa-list-ol"></i> แก้ไขคะแนน</h4>
                                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                            </div>
                                                                            
                                                                            <div class="modal-body">
                                                                                <?php 
                                                                                //console($personnelList);
                                                                                ?>
                                                                                <form method="post" action="<?php echo base_url('setting/subjectUpdateScore')?>" >
                                                                                    <input type="hidden" id="academic_year" name="academic_year" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->academic_year;?>">
                                                                                    <input type="hidden" id="subject_id" name="subject_id" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->id;?>">
                                                                                <div class="card border-warning">
                                                                                
                                                                                <div class="card-header bg-success m-b-15">
                                                                                    <h4 class="m-b-0 text-white">เทอม 1</h4>
                                                                                </div>
                            
                                                                                    <div class="row">
                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                            คะแนนเก็บ
                                                                                        </div>
                                                                                        <div class="col-md-7" id="subjectGroup_div">
                                                                                            <input type="text" id="term_1_test_score" name="term_1_test_score" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->term_1_test_score;?>">
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-b-15"></div> 
                                                                                    <div class="row">
                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                            คะแนนกลางภาค
                                                                                        </div>
                                                                                        <div class="col-md-7" id="subjectGroup_div">
                                                                                        <input type="text" id="term_1_midterm_score" name="term_1_midterm_score" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->term_1_midterm_score;?>">        
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-b-15"></div> 
                                                                                    <div class="row">
                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                            คะแนนปลายภาค
                                                                                        </div>
                                                                                        <div class="col-md-7" id="subjectGroup_div">
                                                                                        <input type="text" id="term_1_finalterm_score" name="term_1_finalterm_score" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->term_1_finalterm_score;?>">        
                                                                                        </div>
                                                                                    </div>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <div class="card-header bg-success m-b-15">
                                                                                    <h4 class="m-b-0 text-white">เทอม 2</h4>
                                                                                </div>
                            
                                                                                    <div class="row">
                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                            คะแนนเก็บ
                                                                                        </div>
                                                                                        <div class="col-md-7" id="subjectGroup_div">
                                                                                            <input type="text" id="term_2_test_score" name="term_2_test_score" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->term_2_test_score;?>">
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-b-15"></div> 
                                                                                    <div class="row">
                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                            คะแนนกลางภาค
                                                                                        </div>
                                                                                        <div class="col-md-7" id="subjectGroup_div">
                                                                                        <input type="text" id="term_2_midterm_score" name="term_2_midterm_score" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->term_2_midterm_score;?>">        
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-b-15"></div> 
                                                                                    <div class="row">
                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                            คะแนนปลายภาค
                                                                                        </div>
                                                                                        <div class="col-md-7" id="subjectGroup_div">
                                                                                        <input type="text" id="term_2_finalterm_score" name="term_2_finalterm_score" class="form-control form-control-line" placeholder="กรอกคะแนน" value="<?php echo @$subjectProfile->subjectlist[0]->term_2_finalterm_score;?>">        
                                                                                        </div>
                                                                                    </div>
                                                                                    <div style="margin-top:21px;"></div>     
                                                                                    
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <div class="text-right m-b-10">
                                                                                            <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                                            <button type="submit" id="addPersonnelBtn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                                    </div>
                                                                                </form>    
                                                                            </div>
                                                                                
                                                                        </div>
                                                                    </div>
                                                                    </div>
                                </div>
                                <!-- modal -->
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

<script type="text/javascript">    
   $( "#addPersonnelBtn").click(function() {
            a = document.getElementById("personnelSec").value;
            $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'subject/addPersonnel'?>',
               data: 'personnel_id='+a+'&subject_id=<?php echo $subject_id;?>',
               success: function(result) {
                   //alert(result);
                   //$('#motherList').html(result);
               }
           });  
              
   });

    function myFunction(a){
    $("#responsive-modal").modal();
    /*    
    $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'setting/getStudentOnetScore'?>',
               data: 'student_id='+student_id+'&academic_year='+academic_year,
               success: function(result) {
                    //$('#load_onet').html(result);
                    $("#responsive-modal").modal();
                    
                   //alert(result);
                   //$('#studentList').html(result);
               }
    }); 
    */
    }
</script> 

<script>
function myFunction() {
    $("#responsive-modal").modal();
  //document.getElementById("demo").style.color = "red";
}
</script>