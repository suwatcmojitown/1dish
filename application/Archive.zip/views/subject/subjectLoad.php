                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <th style="width:10%;">รหัสวิชา</th>
                                                    <th style="width:20%;">ชื่อวิชา</th>
                                                    <!--<th style="width:15%;">ประเภท</th>-->
                                                    <th style="width:20%;">กลุ่มสาระ</th>
                                                    <th style="width:20%;">ระดับชั้น</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                if(isset($result)&&!empty($result)){
                                                    $i = 1;
                                                    foreach($result as $row){
                                                ?> 
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo $row->subject_id;?></td>
                                                    <td><?php echo $row->name_th;?></td>
                                                    <!--<td><?php //echo $row->subject_type_name_th;?></td>-->
                                                    <td><?php echo $row->subject_group_name_th;?></td>
                                                    <td><?php echo $row->education_sublevel_name_th;?></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="<?php echo base_url('subject/subjectProfile/').$row->id;?>" data-toggle="tooltip" data-original-title="ดู"> <i class="fa fa-eye text-success m-r-10"></i> </a>
                                                        <!--
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-danger"></i> </a>
                                                        -->
                                                    </td>
                                                <tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }    
                                                ?> 
                                            </tbody>
                                        </table>    

                                    <?php 
                                    if(isset($page)&&!empty($page))
                                    { 
                                        $active_page = $page->page;
                                        $total = $page->total_page;
                                        
                                    ?>	            

                                    <div class="dataTables_paginate paging_simple_numbers" id="example23_paginate">
                                        <?php if($active_page-1>0){?>    
                                            <a class="paginate_button previous" aria-controls="example23" data-dt-idx="0" tabindex="0" id="example23_previous">ก่อนหน้า</a>
                                        <?php }?>
                                        
                                        <?php 
                                            if($active_page-2>0)
                                        {
                                        ?>     
                                            <a class="paginate_button " href="<?php echo base_url('setting/subjectList?page=').($active_page-2).'&type='.$type.'&group='.$group;?>" aria-controls="example23" data-dt-idx="2" tabindex="0"><?php echo $active_page-2;?></a>
                                        <?php
                                        } 
                                        if($active_page-1>0)
                                        {
                                        ?>     
                                            <a class="paginate_button " href="<?php echo base_url('setting/subjectList?page=').($active_page-1).'&type='.$type.'&group='.$group;?>" aria-controls="example23" data-dt-idx="3" tabindex="0"><?php echo $active_page-1;?></a>
                                        <?php 
                                        }
                                        ?>   
                                            <a class="paginate_button current" aria-controls="example23" data-dt-idx="4" tabindex="0"><?php echo $active_page;?></a>
                                        <?php 
                                            if($active_page+1<=$total)
                                        {
                                        ?>
                                            <a class="paginate_button " href="<?php echo base_url('setting/subjectList?page=').($active_page+1).'&type='.$type.'&group='.$group;?>" aria-controls="example23" data-dt-idx="5" tabindex="0"><?php echo $active_page+1;?></a>
                                        <?php 
                                        }
                                        ?>
                                        <?php 
                                            if($active_page+2<=$total)
                                        {
                                        ?>
                                            <a class="paginate_button " href="<?php echo base_url('setting/subjectList?page=').($active_page+2).'&type='.$type.'&group='.$group;?>" aria-controls="example23" data-dt-idx="6" tabindex="0"><?php echo $active_page+2;?></a></span>
                                        <?php 
                                        }
                                        ?>
                                            <?php if($active_page+1<$total){?>      
                                            <a class="paginate_button next" aria-controls="example23" data-dt-idx="7" tabindex="0" id="example23_next">ถัดไป</a>
                                        <?php }?>
                                    </div>
                                    <hr>
                                    <?php 
                                    }
                                    ?>
                                