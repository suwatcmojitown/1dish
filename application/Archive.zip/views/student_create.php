<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">
                        <div class="card-body">
                                

                                <form action="studentAdd" class="form-horizontal" method="post" enctype="multipart/form-data" >
                                    <div class="form-body">
                                        <div class="card-header badge-success">
                                        <h4 class="m-b-0 text-white">เพิ่มนักเรียน</h4></div>
                                        <h3 class="box-title"></h3>
                                        <div class="m-t-0 m-b-20"></div>
                                        <h4 class="box-title">รายละเอียดส่วนตัว</h4>
                                        <hr class="m-t-0 m-b-30">
                                        
                                        <div class="row">
                                            <!--/span-->
                                            <div class=" col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary p-t-5">รหัสนักเรียน</label>
                                                    <div class="col-md-5">
                                                         <input type="text" class="form-control" placeholder="กรอกรหัสนักเรียน" id="student_no" name="student_no">
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <!--/row-->  
                                        <!--/row-->    
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-6 text-primary p-t-5">คำนำหน้า</label>
                                                    <div class="col-md-6">
                                                        <select class="form-control custom-select text-muted" name="name_title_th" data-placeholder="Choose a Category" tabindex="1" >
                                                            <option value="">--เลือก--</option>
                                                            <option value="นาย">นาย</option>
                                                            <option value="นาง">นาง</option>
                                                            <option value="นางสาว">นางสาว</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-4 text-primary p-t-5">ชื่อ</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="firstname_th" name="firstname_th" class="form-control" placeholder="กรอกชื่อ" >
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-4 text-primary p-t-5">นามสกุล</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="lastname_th" name="lastname_th" class="form-control" placeholder="กรอกนามสกุล" >
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-6 text-primary p-t-5">คำนำหน้า Eng</label>
                                                    <div class="col-md-6">
                                                        <select class="form-control custom-select text-muted" name="name_title_en" data-placeholder="Choose a Category" tabindex="1">
                                                            <option value="">--เลือก--</option>
                                                            <option value="Mr.">Mr.</option>
                                                            <option value="Mrs.">Mrs.</option>
                                                            <option value="Miss.">Miss.</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-4 text-primary p-t-5">ชื่อ Eng</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="firstname_en" name="firstname_en" class="form-control" placeholder="กรอกชื่อ">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-4 text-primary p-t-5">นามสกุล Eng</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="lastname_en" name="lastname_en" class="form-control" placeholder="กรอกนามสกุล">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="m-t-20"></div>
                                        <!--/row-->
                                        <div class="row">
                                            <!--/span-->
                                            <div class=" col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary p-t-5">ชื่อเล่น</label>
                                                    <div class="col-md-5">
                                                         <input type="text" class="form-control" placeholder="กรอกชื่อเล่น" id="nickname" name="nickname">
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-2 text-primary p-t-5 m-r-15">รหัสประชาชน</label>
                                                    <div class="col-md-1">
                                                        <input type="text" id="txtID1" name="txtID1" class="form-control" maxlength=1 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" >
                                                    </div>
                                                    <span class="p-t-5">-</span>   
                                                    <div class="col-md-2">
                                                        <input type="text" id="txtID2" name="txtID2" class="form-control" maxlength=4 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" >  
                                                    </div>
                                                    <span class="p-t-5">-</span> 
                                                    <div class="col-md-2">
                                                        <input type="text" id="txtID3" name="txtID3" class="form-control" maxlength=5 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" >  
                                                    </div>
                                                    <span class="p-t-5">-</span> 
                                                    <div class="col-md-2">
                                                        <input type="text" id="txtID4" name="txtID4" class="form-control" maxlength=2 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" > 
                                                    </div> 
                                                    <span class="p-t-5">-</span> 
                                                    <div class="col-md-1">
                                                        <input type="text" id="txtID5" name="txtID5" class="form-control" maxlength=1 onkeyup="keyup(this,event)" onkeypress="return Numbers(event)" > 
                                                    </div>
                                                       
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <!--/row-->
                                        <div class="row">
                                            <!--/span-->
                                            <div class=" col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary p-t-5">วันเกิด</label>
                                                    <div class="col-md-6">
                                                         <input type="date" class="form-control text-muted" placeholder="กรอกวันเกิด" id="birthdate" name="birthdate">
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <!--/row-->    
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-6 text-primary p-t-5">เชื้อชาติ</label>
                                                    <div class="col-md-6">
                                                        <select class="form-control custom-select text-muted" id="nationality" name="nationality" data-placeholder="Choose a Category" tabindex="1" >
                                                            <option value="Thai">ไทย</option>
                                                            <option value="Chainess">จีน</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-4 text-primary p-t-5">สัญชาติ</label>
                                                    <div class="col-md-8">
                                                         <select class="form-control custom-select text-muted" id="race" name="race" data-placeholder="Choose a Category" tabindex="1" >
                                                            <option value="Thai">ไทย</option>
                                                            <option value="Chainess">จีน</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-4 text-primary p-t-5">ศาสนา</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="religion" name="religion" class="form-control" placeholder="กรอกศาสนา" >
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <div class="m-t-20"></div>
                                        <div class="row">
                                            <div class="col-md-10">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-2 text-primary p-t-5">รูปภาพ</label>
                                                    <div class="col-md-6" style="margin-left:-15px;">
                                                        <input type="file" id="myfile" name="myfile" class="form-control">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>    
                                        <!--/row-->
                                        <div class="row">
                                            <!--
                                            <div class="col-md-3">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-6 text-primary p-t-5">น้ำหนัก</label>
                                                    <div class="col-md-6">
                                                        <input type="text" id="weight" name="weight" class="form-control" placeholder="กรอกน้ำหนัก" >
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-4 text-primary p-t-5">ส่วนสูง</label>
                                                    <div class="col-md-6">
                                                        <input type="text" id="height" name="height" class="form-control" placeholder="กรอกส่วนสูง" >
                                                    </div>
                                                </div>
                                            </div>
                                            -->
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary p-t-5">กรุ๊ปเลือด</label>
                                                    <div class="col-md-6">
                                                        <input type="text" id="blood_type" name="blood_type" class="form-control" placeholder="กรอกกรุ๊ปเลือด" >
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary p-t-5">โรคประจำตัว</label>
                                                    <div class="col-md-7" style="margin-left: -41px;">
                                                         <textarea id="congenital_disease" name="congenital_disease" class="form-control" placeholder="กรอกรายละเอียด" ></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>    
                                        <!--/row-->
                                        <!--/row-->
                                        <h4 class="box-title">รายละเอียดที่อยู่</h4>
                                        <hr class="m-t-0 m-b-40">
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-2 text-primary p-t-5">ที่อยู่</label>
                                                    <div class="col-md-8" style="margin-left: -41px;">
                                                         <textarea id="address" name="address" class="form-control" placeholder="กรอกที่อยู่" ></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <span id="address_detail">  
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary" style="padding-left:14px;padding-top:7px;">ตำบล</label>
                                                    <div class="col-md-8">
                                                        <input type="text" id="subdistrict" name="subdistrict" class="form-control" placeholder="กรอกตำบล" >
                                                        <input type="hidden" id="subdistrict_id" name="subdistrict_id" class="form-control" >
                                                    </div>
                                                </div>
                                            </div>
                                          
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary p-t-5" style="padding-left:14px;padding-top:7px;">อำเภอ</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="district" name="district" class="form-control" placeholder="กรอกอำเภอ" >
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary p-t-5" style="padding-left:14px;padding-top:7px;">จังหวัด</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="province" name="province" class="form-control" placeholder="กรอกจังหวัด" >
                                                    </div>
                                                </div>
                                            </div>
                                             <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary p-t-5">รหัสไปรษณีย์</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="zipcode" name="zipcode" class="form-control" placeholder="กรอกรหัสไปรษณีย์" >
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </span>
                                        <div class="m-t-20"></div>
                                         <!--/row-->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary p-t-5" style="padding-left:14px;padding-top:7px;">longitude</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="home_longitude" name="home_longitude" class="form-control" placeholder="กรอกตำแหน่ง longitude" >
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3 text-primary p-t-5">latitude</label>
                                                    <div class="col-md-8">
                                                         <input type="text" id="home_latitude" name="home_latitude" class="form-control" placeholder="กรอกตำแหน่ง latitude" >
                                                    </div>
                                                </div>
                                            </div> 
                                        </div>
                                         <!--/row-->
                                         <!--
                                        <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="control-label text-left col-md-3 text-primary" style="padding-left: 14px;">สถานะ</label>
                                                            <div class="col-md-9">
                                                                <div class="form-check form-check-inline text-muted">
                                                                      <input class="form-check-input" type="radio" name="status" id="status_1" value="1" checked>
                                                                      <label class="form-check-label" for="inlineRadio1">ใช้งาน</label>
                                                                </div>
                                                                <div class="form-check form-check-inline text-muted">
                                                                      <input class="form-check-input" type="radio" name="status" id="status_2" value="0">
                                                                      <label class="form-check-label" for="inlineRadio2">ยกเลิก</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                        </div>
                                         -->
                                        <!--/row-->
                                    </div>
                                    <hr class="m-t-0 m-b-20">
                                        <div class="row">
                                                    <div class="col-12">
                                                        <div class="form-group row">

                                                            <div class="offset-md-9 col-md-1">
                                                                 <button class="btn btn-danger pull-right" input type="reset" >ยกเลิก</button>
                                                                
                                                            </div>    
                                                            <div class="col-md-1">
                                                                 <button class="btn btn-success pull-right btn-outline" input type="submit"> บันทึก</button>
                                                            </div>     
                                                        </div>
                                                    </div>
                                        </div>
                                </form>
                                <!--- form -->
                            </div>
                            <!-- card body -->    
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

<script type="text/javascript"> 
    function Numbers(e){
        var keynum;
        var keychar;
        var numcheck;
        if(window.event) {// IE
        keynum = e.keyCode;
        }
        else if(e.which) {// Netscape/Firefox/Opera
        keynum = e.which;
        }
        if(keynum == 13 || keynum == 8 || typeof(keynum) == "undefined"){
                return true;
        }
        keychar= String.fromCharCode(keynum);
        numcheck = /^[0-9]$/;
        return numcheck.test(keychar);
    }

    function keyup(obj,e){
        var keynum;
        var keychar;
        var id = '';
        if(window.event) {// IE
        keynum = e.keyCode;
        }
        else if(e.which) {// Netscape/Firefox/Opera
        keynum = e.which;
        }
        keychar= String.fromCharCode(keynum); 

        var tagInput = document.getElementsByTagName('input');
        for(i=0;i<=tagInput.length;i++){
            if(tagInput[i] == obj){ 
                var prevObj = tagInput[i-1];
                var nextObj = tagInput[i+1];
                break;
            }
        } 
        if(obj.value.length == 0 && keynum == 8) prevObj.focus();
        
        if(obj.value.length == obj.getAttribute('maxlength')){ 
            for(i=0;i<=tagInput.length;i++){
                if(tagInput[i].id.substring(0,5) == 'txtID'){ 
                    if(tagInput[i].value.length == tagInput[i].getAttribute('maxlength')){
                        id += tagInput[i].value;
                        if(tagInput[i].id == 'txtID5') break;
                    }
                    else{
                        tagInput[i].focus();
                        return;
                    }
                }
            } 
            if(checkID(id)) nextObj.focus();
            else alert('รหัสประชาชนไม่ถูกต้อง');
            nextObj.focus();
        }
        
    }

    function checkID(id){
        if(id.length != 13) return false;
        for(i=0, sum=0; i < 12; i++)
            sum += parseFloat(id.charAt(i))*(13-i); 
        if((11-sum%11)%10!=parseFloat(id.charAt(12)))
            return false; 
        return true;
    }

    $('#subdistrict').keyup(function(e) {
    clearTimeout($.data(this, 'timer'));
    if (e.keyCode == 13)
      search(true);
    else
      $(this).data('timer', setTimeout(search, 500));
    });
    function search(force) {
        var existingString = $("#subdistrict").val();
        if (!force && existingString.length < 3) return; //wasn't enter, not > 2 char
        //alert('d');
        $.get('getAddress/' + existingString, function(data) {
            $('#address_detail').html(data);
            /*
            $('#address_detail').html(data);
            $('#results').show();
            */
        });
    }
</script>

    