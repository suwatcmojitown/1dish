<select class="form-control custom-select text-muted" id="educationSub" name="educationSub">
                                                                        <option value="0">ทั้งหมด</option>
                                                                        <?php 
                                                                            if(isset($result)&&!empty($result)){
                                                                                foreach($result as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                        ?>
                                                        </select>

                                                        
        <script>
        $( "#educationSub").change(function() {

            academic_year = <?php echo $academicYearNow;?>;
            term_id = <?php echo $term_id;?>;
            education = document.getElementById("education").value;
            educationSub = document.getElementById("educationSub").value;
            
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url('classroom/')?>loadRoom',
                data: 'education='+education+'&educationSub='+educationSub+'&academic_year='+academic_year+'&term_id='+term_id+'',
                success: function(result) { 
                    
                    $("#room_div").html(result);
                    
                    academic_year = <?php echo $academicYearNow;?>;
                    term_id = <?php echo $term_id;?>;
                    education = document.getElementById("education").value;
                    educationSub = document.getElementById("educationSub").value;
                    room = document.getElementById("room").value;
                    
                    $.ajax({
                        type: 'POST',
                        url: '<?php echo base_url('classroom/')?>listLoad',
                        data: 'academic_year='+academic_year+'&term_id='+term_id+'&education='+education+'&educationSub='+educationSub+'&room='+room,
                        success: function(result) { 
                            $("#content_div").html(result);
                        }
                    });
                }
            });
            
            
        });
        </script>