<!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <div class="text-right m-b-10">
                                        <a href="<?php echo base_url('setting/studentCreate').'?clssroom_id='.$classroom_id;?>"><button class="btn btn-danger" type="button" > <span><i class="fa fa-file-o"></i>  สร้างข้อมูลนักเรียน</span> </button> </a>
                                        <button class="btn btn-success" type="submit" data-toggle="modal" data-target="#responsive-modal"> <span><i class="fa fa-file-o"></i>  เพิ่มนักเรียนในชั้น</span> </button>
                                </div>
                                
                                <hr class="m-t-0 m-b-20">
                                
                                <div class="row m-b-15">
                                        <?php 
                                        //console($profile);
                                        ?>
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <div class="col-md-3 col-xs-6 b-r"> <strong>ชั้นเรียน</strong>
                                                    <br>
                                                    <p class="text-muted m-t-5"><?php echo @$profile->education_sublevel_name_th;?> ห้อง <?php echo @$profile->room;?></p>
                                                </div>
                                                <div class="col-md-3 col-xs-6 b-r"> <strong>ครูประจำชั้น</strong>
                                                    <br>
                                                    <p class="text-muted m-t-5"><?php echo @$profile->personnel_name;?></p>
                                                </div>
                                                <div class="col-md-3 col-xs-6 b-r"> <strong>จำนวนนักเรียน</strong>
                                                    <br>
                                                    <p class="text-muted m-t-5"><?php echo @$profile->total_student;?> คน</p>
                                                </div>
                                                <div class="col-md-3 col-xs-6 m-t-5"> <strong>ปีการศึกษา</strong>
                                                    <br>
                                                    <p class="text-muted"><?php echo @$profile->academic_year;?></p>
                                                </div>
                                            </div>
                                            <!--
                                            <div class="m-b-20"></div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                        <input type="text" id="search" name="search" class="form-control" placeholder="กรอกคำค้นหา">
                                                </div>
                                                <div class="col-md-2">
                                                      <button type="button" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>
                                            </div>
                                            -->
                                        </div>
                                </div>
                                
                                
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper">
                                        <?php 
                                        //console($studentList);
                                        ?>
                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:10%;">เลขที่</th>
                                                    <th style="width:15%;">เลขประจำตัว</th>
                                                    <th style="width:40%;">ชื่อ - นามสกุล</th>
                                                    <!--<th style="width:15%;">รูปภาพ</th>-->
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                //console($studentList);
                                                if(isset($studentList[0]->student)&&!empty($studentList[0]->student)){
                                                $i = 1;
                                                foreach($studentList[0]->student as $row )
                                                {
                                                ?>
                                                <tr>
                                                    <td><?php echo $row->student_no;?></td>
                                                    <td><?php echo $row->student_id;?></td>
                                                    <td><?php echo $row->name_th;?></td>
                                                    <!--<td><img src="<?php //echo $row->profile_img_url;?>" style="max-width:100px;">-->
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="<?php echo base_url('student/profile/').$row->student_id;?>" data-toggle="tooltip" data-original-title="ดู"> <i class="fa fa-eye text-success m-r-10"></i> </a>
                                                        <!--
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-warning"></i> </a>
                                                        -->
                                                    </td>
                                                </tr>
                                                <?php 
                                                    $i++;
                                                }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    <hr>
                                    
                                </div>
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
                <!-- modal -->
                                <div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                                    <div class="modal-dialog modal-lg" >
                                                                        <div class="modal-content">
                                                                            <div class="modal-header alert-success">
                                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> ค้นหารายชื่อ</h4>
                                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                            </div>
                                                                            <div class="modal-body">
                                                                                <form method="post" action="cus_order_add.php" >
                                                                                    <div class="row">
                                                                                        <div class="col-md-6">
                                                                                                <input type="text" id="keysearchStudent" class="form-control" placeholder="พิมพ์คำค้นหา" aria-describedby="search-txt">        
                                                                                        </div>
                                                                                        <div class="col-md-2 text-success">
                                                                                                 <button type="button" id="searchStudentBtn" class="btn btn-warning">ค้นหา</button>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <table class="table color-table primary-table " id="studentList">
                                                                                        
                                                                                    </table>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <div class="text-right m-b-10">
                                                                                            <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                                            <button type="button" id="addStudentBtn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                                    </div>
                                                                                </form>    
                                                                            </div>
                                                                                
                                                                        </div>
                                                                    </div>
                                </div>
                                <!-- modal -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

<script type="text/javascript">    
   $( "#searchStudentBtn").click(function() {
           a = document.getElementById("keysearchStudent").value;
           $.ajax({
               type: 'POST',
               url: '<?php echo base_url().'classroom/searchStudent'?>',
               data: 'keysearch='+a+'&classroom_id=<?php echo $classroom_id;?>',
               success: function(result) {
                   $('#studentList').html(result);
               }
           });      
   });
</script>   