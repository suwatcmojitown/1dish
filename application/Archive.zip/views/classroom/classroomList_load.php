
                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <!--<th style="width:10%;">ปีการศึกษา</th>-->
                                                    <th style="width:20%;">ชั้น</th>
                                                    <th style="width:10%;">ห้อง</th>
                                                    <th style="width:15%;">จำนวนนักเรียน</th>
                                                    <th style="width:20%;">ครูประจำชั้น</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                if(isset($result)&&!empty($result)){
                                                    $i = 1;
                                                    foreach($result as $row){
                                                ?> 
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <!--<td><?php //echo $row->academic_year;?></td>-->
                                                    <td><?php echo $row->education_sublevel_name_th;?></td>
                                                    <td><?php echo $row->room;?></td>
                                                    <td><?php 
                                                        if(isset($row->student[0]->total_student)&&!empty($row->student[0]->total_student))
                                                        {
                                                            echo $row->student[0]->total_student;
                                                        }else echo "0";
                                                    ?></td>
                                                    <td><?php 
                                                        if(isset($row->personnel)&&!empty($row->personnel))
                                                        {
                                                            $i=1;
                                                            foreach($row->personnel as $temp)
                                                            {
                                                                echo $temp->personnel_name;
                                                                if($i>1)echo '<br>';
                                                                $i++;
                                                            }

                                                        }    
                                                    ?>
                                                    </td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="ดู"> <i class="fa fa-eye text-success m-r-10"></i> </a>
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-danger"></i> </a>
                                                    </td>
                                                <tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }    
                                                ?>     
                                            </tbody>
                                        </table>
                                    
