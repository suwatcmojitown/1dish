                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <?php 
                                //console($academicYearList);
                                ?>
                                <div class="text-right m-b-10">
                                        <a href="classroomCreate"><button class="btn btn-success" type="submit" data-toggle="modal" data-target="#responsive-modal"> <span><i class="fa fa-file-o"></i>  เพิ่มชั้นเรียน</span> </button></a>
                                </div>
                                
                                <hr class="m-t-0 m-b-20">
                                
                                <div class="row m-b-15">
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <?php 
                                                //console($educationList);
                                                ?>
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ชั้น
                                                </div>
                                                <div class="col-md-2" >
                                                        <select class="form-control custom-select text-muted" id="education" name="education">
                                                                        <option value="0">ทั้งหมด</option>
                                                                        <?php 
                                                                            if(isset($educationList)&&!empty($educationList)){
                                                                                foreach($educationList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                        ?>
                                                        </select>
                                                                
                                                </div> 
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ระดับ
                                                </div>
                                                <div class="col-md-2" id="educationSublevel_div">
                                                        <select class="form-control custom-select text-muted" id="educationSub" name="educationSub">
                                                                            <option value="0">ทั้งหมด</option>
                                                        </select>
                                                </div>

                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ห้อง
                                                </div>
                                                <div class="col-md-2" id="room_div">
                                                        <select class="form-control custom-select text-muted" id="room" name="room">
                                                                            <option value="0">ทั้งหมด</option>
                                                        </select>
                                                </div>
                                                <!--
                                                <div class="offset-md-1 col-md-2">
                                                      <button type="button" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>
                                                                        -->
                                            </div>
                                        </div>
                                </div>
                                
                                
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper" id="content_div">
                                        <?php //console($result);?>
                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <!--<th style="width:10%;">ปีการศึกษา</th>-->
                                                    <th style="width:20%;">ชั้น</th>
                                                    <th style="width:10%;">ห้อง</th>
                                                    <th style="width:15%;">จำนวนนักเรียน</th>
                                                    <th style="width:20%;">ครูประจำชั้น</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                if(isset($result)&&!empty($result)){
                                                    $i = 1;
                                                    foreach($result as $row){
                                                ?> 
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <!--<td><?php //echo $row->academic_year;?></td>-->
                                                    <td><?php echo $row->education_sublevel_name_th;?></td>
                                                    <td><?php echo $row->room;?></td>
                                                    <td><?php 
                                                        if(isset($row->student[0]->total_student)&&!empty($row->student[0]->total_student))
                                                        {
                                                            echo $row->student[0]->total_student;
                                                        }else echo "0";
                                                    ?></td>
                                                    <td><?php 
                                                        if(isset($row->personnel)&&!empty($row->personnel))
                                                        {
                                                            $i=1;
                                                            foreach($row->personnel as $temp)
                                                            {
                                                                echo $temp->personnel_name;
                                                                if($i>1)echo '<br>';
                                                                $i++;
                                                            }

                                                        }    
                                                    ?>
                                                    </td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="ดู"> <i class="fa fa-eye text-success m-r-10"></i> </a>
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-danger"></i> </a>
                                                    </td>
                                                <tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }    
                                                ?>     
                                            </tbody>
                                        </table>
                                    
                                </div>
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
 
        <script>
        $( "#education").change(function() {
            a = document.getElementById("education").value;
            //b = document.getElementById("subjectGroupSec").value;
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url('classroom/')?>loadEducationSub',
                data: 'education='+a+'&academic_year=<?php echo $academicYearNow;?>&term_id=<?php echo $term_id;?>',
                success: function(result) { 
                    $("#educationSublevel_div").html(result);
                    academic_year = <?php echo $academicYearNow;?>;
                    term_id = <?php echo $term_id;?>;
                    education = document.getElementById("education").value;
                    educationSub = document.getElementById("educationSub").value;
                    room = document.getElementById("room").value;
                    
                    $.ajax({
                        type: 'POST',
                        url: '<?php echo base_url('classroom/')?>listLoad',
                        data: 'academic_year='+academic_year+'&term_id='+term_id+'&education='+education+'&educationSub='+educationSub+'&room='+room,
                        success: function(result) { 
                            $("#content_div").html(result);
                        }
                    });
                    
                }
            });
            
        });

        $( "#academic_year").change(function() {
            academic_year = document.getElementById("academic_year").value;
            education = document.getElementById("education").value;
            educationSub = document.getElementById("educationSub").value;
            room = document.getElementById("room").value;
            
            $.ajax({
                type: 'POST',
                url: 'classroomLoad',
                data: 'academic_year='+academic_year+'&education='+education+'&educationSub='+educationSub+'&room='+room,
                success: function(result) { 
                    $("#content_div").html(result);
                }
            });
            
            
        });
        </script>
