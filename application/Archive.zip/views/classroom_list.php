<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
<?php 
if($alert!='')
{
    if($alert=='success'){
?>
        swal("success!", "ทำรายการสำเร็จ", "success");
<?php 
    }
    else
    {
?> 
        swal("Error!", "ไม่สามารถทำรายการได้", "error");
<?php 
    }
}
?>
</script>
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row --> 
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <?php 
                                //console($academicYearList);
                                ?>
                                <div class="text-right m-b-10">
                                        <a href="classroomCreate"><button class="btn btn-success" type="submit" data-toggle="modal" data-target="#responsive-modal"> <span><i class="fa fa-file-o"></i>  เพิ่มชั้นเรียน</span> </button></a>
                                </div>
                                
                                <hr class="m-t-0 m-b-20">
                                
                                <div class="row m-b-15">
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                        ปีการศึกษา
                                                </div>
                                                <div class="col-md-3">
                                                        <select class="form-control custom-select text-muted" id="academic_year" name="academic_year">
                                                                            <option value="0">ทั้งหมด</option>
                                                                        <?php 
                                                                            if(isset($academicYearList)&&!empty($academicYearList)){
                                                                                foreach($academicYearList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->academic_year;?>">ปี <?php echo $row->academic_year;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                        ?>
                                                        </select>
                                                                
                                                </div> 
                                                <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                        เทอม
                                                </div>
                                                <div class="col-md-3">
                                                        <select class="form-control custom-select text-muted" id="term_id" name="term_id">
                                                                        <option value="0">ทั้งหมด</option>
                                                                        <option value="1">1</option>
                                                                        <option value="2">2</option>
                                                        </select>
                                                                
                                                </div> 
                                            </div>
                                            <div class="m-b-20"></div>
                                            <div class="row">
                                                <?php 
                                                //console($educationList);
                                                ?>
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ชั้น
                                                </div>
                                                <div class="col-md-2" >
                                                        <select class="form-control custom-select text-muted" id="education" name="education">
                                                                        <option value="0">ทั้งหมด</option>
                                                                        <?php 
                                                                            if(isset($educationList)&&!empty($educationList)){
                                                                                foreach($educationList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                        ?>
                                                        </select>
                                                                
                                                </div> 
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ระดับ
                                                </div>
                                                <div class="col-md-2" id="educationSublevel_div">
                                                        <select class="form-control custom-select text-muted" id="educationSub" name="educationSub">
                                                                            <option value="0">ทั้งหมด</option>
                                                        </select>
                                                </div>

                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ห้อง
                                                </div>
                                                <div class="col-md-2" id="room_div">
                                                        <select class="form-control custom-select text-muted" id="room" name="room">
                                                                            <option value="0">ทั้งหมด</option>
                                                        </select>
                                                </div>
                                                <!--
                                                <div class="offset-md-1 col-md-2">
                                                      <button type="button" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>
                                                                        -->
                                            </div>
                                        </div>
                                </div>
                                
                                
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper" id="content_div">
                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <!--<th style="width:10%;">ปีการศึกษา</th>-->
                                                    <th style="width:20%;">ชั้น</th>
                                                    <th style="width:10%;">ห้อง</th>
                                                    <th style="width:15%;">จำนวนนักเรียน</th>
                                                    <th style="width:20%;">ครูประจำชั้น</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                            <?php 
                                                //console($result);
                                                if(isset($result)&&!empty($result)){
                                                    $i = 1;
                                                    foreach($result as $row){
                                                ?> 
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <!--<td><?php //echo $row->academic_year;?></td>-->
                                                    <td><?php echo $row->education_sublevel_name_th;?></td>
                                                    <td><?php echo $row->room;?></td>
                                                    <td><?php 
                                                        if(isset($row->student[0]->total_student)&&!empty($row->student[0]->total_student))
                                                        {
                                                            echo $row->student[0]->total_student;
                                                        }else echo "0";
                                                    ?></td>
                                                    <td><?php 
                                                        if(isset($row->personnel)&&!empty($row->personnel))
                                                        {
                                                            $c=1;
                                                            foreach($row->personnel as $temp)
                                                            {
                                                                if($c>1)echo '<br>';
                                                                echo $temp->personnel_name;
                                                                $c++;
                                                            }

                                                        }    
                                                    ?>
                                                    </td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="<?php echo base_url('classroom/classroomProfile/').$row->id;?>" data-toggle="tooltip" data-original-title="ดู"> <i class="fa fa-eye text-success m-r-10"></i> </a>
                                                        <a href="<?php echo base_url('setting/classroomEdit/').$row->academic_year.'/'.$row->id;?>" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-danger m-r-20"></i> </a>
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="เช็คชื่อทั้งห้อง" class="img-responsive model_img" onclick="check(<?php echo $row->id;?>)"> <i class="fa fa-clock-o text-purple"></i> </a>
                                                    </td>
                                                <tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }    
                                                ?>      
                                            </tbody>
                                        </table>
                                    
                                </div>
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

<!-- Modal -->
<div id="successModal" class="modal fade center" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                        <div class="modal-dialog modal-sm" >
                                                    <div class="alert alert-success">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                                                    <h3 class="text-success"><i class="fa fa-check-circle"></i> 
                                                    Success</h3> ระบบได้ทำรายการเรียบร้อยแล้ว
                                                    </div>
                                        </div>
</div> 
<div id="errorModal" class="modal fade center" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                        <div class="modal-dialog modal-sm" >
                                                    <div class="alert alert-danger">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                                                    <h3 class="text-denger"><i class="fa fa-exclamation-triangle">
                                                    </i> Error</h3>  ระบบไม่สามารถทำรายการได้ กรุณาลองใหม่อีกครั้ง
                                                    </div>
                                        </div>
</div>                                        
<!-- Modal --> 

        <script>

        function check(classroom_id)
        {
            $.ajax({
                type: 'POST',
                url: 'autoCheckInAllRoom',
                data: 'classroom_id='+classroom_id,
                success: function(result) { 
                    if(result)
                    {
                        $("#successModal").modal('toggle'); 
                    } 
                    else $("#errorModal").modal('toggle'); 
                }
            });
        }

        $( "#education").change(function() {
            a = document.getElementById("education").value;
            //b = document.getElementById("subjectGroupSec").value;
            $.ajax({
                type: 'POST',
                url: 'classroomLoadEducationSub',
                data: 'education='+a,
                success: function(result) { 
                    $("#educationSublevel_div").html(result);
                    academic_year = document.getElementById("academic_year").value;
                    term_id = document.getElementById("term_id").value;
                    education = document.getElementById("education").value;
                    educationSub = document.getElementById("educationSub").value;
                    room = document.getElementById("room").value;
                    
                    $.ajax({
                        type: 'POST',
                        url: 'classroomLoad',
                        data: 'academic_year='+academic_year+'&term_id='+term_id+'&education='+education+'&educationSub='+educationSub+'&room='+room,
                        success: function(result) { 
                            $("#content_div").html(result);
                        }
                    });
                }
            });
            
        });

        $( "#academic_year").change(function() {
            academic_year = document.getElementById("academic_year").value;
            term_id = document.getElementById("term_id").value;
            education = document.getElementById("education").value;
            educationSub = document.getElementById("educationSub").value;
            room = document.getElementById("room").value;
            
            $.ajax({
                type: 'POST',
                url: 'classroomLoad',
                data: 'academic_year='+academic_year+'&term_id='+term_id+'&education='+education+'&educationSub='+educationSub+'&room='+room,
                success: function(result) { 
                    $("#content_div").html(result);
                }
            });
            
            
        });
        </script>
