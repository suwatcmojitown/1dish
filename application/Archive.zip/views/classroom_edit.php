<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">
                        <div class="card-body">
                                <form id="classroom-create" action="<?php echo base_url('setting/classroomUpdate');?>" class="form-horizontal" method="post" enctype="multipart/form-data">
                                    <div class="form-body">
                                        <input type="hidden" value="<?php echo $profile->id;?>" class="form-control text-muted"  id="classroom_id" name="classroom_id">
                                        <?php 
                                        //console($profile);
                                        ?>
                                        <div class="card-header badge-primary">
                                        <h4 class="m-b-0 text-white">แก้ไขชั้นเรียน</h4></div>
                                        <h3 class="box-title"></h3>
                                        <hr class="m-t-0 m-b-20">
                                        <div class="row m-b-15">
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                        ปีการศึกษา
                                                </div>
                                                <div class="col-md-3">
                                                        <select class="form-control custom-select text-muted" id="academic_year" name="academic_year">
                                                                            <option value="0">ทั้งหมด</option>
                                                                        <?php 
                                                                            if(isset($academicYearList)&&!empty($academicYearList)){
                                                                                foreach($academicYearList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->academic_year;?>" <?php if($row->academic_year==$profile->academic_year)echo "selected";?>>ปี <?php echo $row->academic_year;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                        ?>
                                                        </select>
                                                                
                                                </div> 
                                            </div>
                                            <div class="m-b-20"></div>
                                            <div class="row">
                                                <?php 
                                                //console($educationList);
                                                ?>
                                                <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                        ชั้น
                                                </div>
                                                <div class="col-md-2" >
                                                        <select class="form-control custom-select text-muted" id="education" name="education">
                                                                        <option value="0">ทั้งหมด</option>
                                                                        <?php 
                                                                            if(isset($educationList)&&!empty($educationList)){
                                                                                foreach($educationList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>" <?php if($row->id==$profile->education_level_id)echo "selected";?>><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                        ?>
                                                        </select>
                                                                
                                                </div> 
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ระดับ
                                                </div>
                                                <div class="col-md-2" id="educationSublevel_div">
                                                        <select class="form-control custom-select text-muted" id="educationSub" name="educationSub">
                                                                        <option value="0">ทั้งหมด</option>
                                                                        <?php 
                                                                            if(isset($educationSubList)&&!empty($educationSubList)){
                                                                                foreach($educationSubList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>" <?php if($row->id==$profile->education_sublevel_id)echo "selected";?>><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                        ?>
                                                        </select>
                                                </div>

                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ห้อง
                                                </div>
                                                <div class="col-md-2" >
                                                        <!--
                                                        <select class="form-control custom-select text-muted" id="room" name="room">
                                                                            <option value="0">ทั้งหมด</option>
                                                        </select>
                                                        -->
                                                        <input type="text" value="<?php echo $profile->room;?>" class="form-control text-muted" placeholder="กรอกห้อง" id="room" name="room">
                                                            
                                                </div>
                                            </div>
                                            <div class="m-b-20"></div>
                                            <div class="row">
                                                <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                        ครูประจำชั้น
                                                </div>
                                                <div class="col-md-3">
                                                        <select class="form-control custom-select text-muted" id="personnel_id" name="personnel_id">
                                                                            <option value="0">-- เลือกครูประจำชั้น --</option>
                                                                        <?php 
                                                                            if(isset($personnelList)&&!empty($personnelList)){
                                                                                foreach($personnelList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>" <?php if($row->id==$profile->personnel_id)echo "selected";?>><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                        ?>
                                                        </select>
                                                                
                                                </div> 
                                            </div>
                                            <hr class="m-t-20 m-b-20">
                                            <div class="row">
                                                        <div class="col-12">
                                                            <div class="form-group row">

                                                                <div class="offset-md-9 col-md-1">
                                                                    <button class="btn btn-danger pull-right" input type="reset" >ยกเลิก</button>
                                                                    
                                                                </div>    
                                                                <div class="col-md-1">
                                                                    <button class="btn btn-success pull-right btn-outline" input type="submit"> บันทึก</button>
                                                                </div>     
                                                            </div>
                                                        </div>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                </form>  
                                <!-- form -->
                            </div>
                            <!-- card body -->    
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

        <script>
        /*
        $( "#education").change(function() {
            a = document.getElementById("education").value;
            //b = document.getElementById("subjectGroupSec").value;
            $.ajax({
                type: 'POST',
                url: 'classroomLoadEducationSub',
                data: 'education='+a,
                success: function(result) { 
                    $("#educationSublevel_div").html(result);
                }
            });
            
        });
        */

        $( "#academic_year").change(function() {
            academic_year = document.getElementById("academic_year").value;
            education = document.getElementById("education").value;
            educationSub = document.getElementById("educationSub").value;
            room = document.getElementById("room").value;
            $.ajax({
                type: 'POST',
                url: 'classroomLoad',
                data: 'academic_year='+academic_year+'&education='+education+'&educationSub='+educationSub+'&room='+room,
                success: function(result) { 
                    $("#content_div").html(result);
                }
            });
            
            
        });
        </script>

    