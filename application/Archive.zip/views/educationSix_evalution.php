<div class="modal-content">
                                                                            <div class="modal-header alert-success">
                                                                                <h4 class="modal-title"><i class="fa fa-edit (alias)"></i> ประเมิน</h4>
                                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                            </div>
                                                                            <div class="modal-body">
                                                                                <form method="post" action="<?php echo base_url('setting/updateEvalution/'.$student_id.'/'.$academic_year.'');?>" >
                                                                                    <?php 
                                                                                    //console($evalution);
                                                                                    $temp = $evalution->evaluation[0];
                                                                                    ?>
                                                                                    <div class="row">
                                                                                    
                                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                                                ผลการประเมินรายวิชาพื้นฐาน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="basic_subject_evaluation" name="basic_subject_evaluation">
                                                                                                            <option value="1" <?php if($temp->basic_subject_evaluation=='1') echo 'selected';?>>ดีเยี่ยม</option>
                                                                                                            <option value="2" <?php if($temp->basic_subject_evaluation=='2') echo 'selected';?>>ดีมาก</option>
                                                                                                            <option value="3" <?php if($temp->basic_subject_evaluation=='3') echo 'selected';?>>ดี</option>
                                                                                                            <option value="4" <?php if($temp->basic_subject_evaluation=='4') echo 'selected';?>>ค่อนข้างดี</option>
                                                                                                            <option value="5" <?php if($temp->basic_subject_evaluation=='5') echo 'selected';?>>ปานกลาง</option>
                                                                                                            <option value="6" <?php if($temp->basic_subject_evaluation=='6') echo 'selected';?>>พอใช้</option>
                                                                                                            <option value="7" <?php if($temp->basic_subject_evaluation=='7') echo 'selected';?>>ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="8" <?php if($temp->basic_subject_evaluation=='8') echo 'selected';?>>ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="9" <?php if($temp->basic_subject_evaluation=='9') echo 'selected';?>>รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="10" <?php if($temp->basic_subject_evaluation=='10') echo 'selected';?>>ผ่าน</option>
                                                                                                            <option value="11" <?php if($temp->basic_subject_evaluation=='11') echo 'selected';?>>ไม่ผ่าน</option>
                                                                                                        </select>      
                                                                                                        </div>
                                                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                                                ผลการตัดสิน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="attitude_evaluation" name="attitude_evaluation">
                                                                                                            <option value="1" <?php if($temp->attitude_evaluation=='1') echo 'selected';?>>ดีเยี่ยม</option>
                                                                                                            <option value="2" <?php if($temp->attitude_evaluation=='2') echo 'selected';?>>ดีมาก</option>
                                                                                                            <option value="3" <?php if($temp->attitude_evaluation=='3') echo 'selected';?>>ดี</option>
                                                                                                            <option value="4" <?php if($temp->attitude_evaluation=='4') echo 'selected';?>>ค่อนข้างดี</option>
                                                                                                            <option value="5" <?php if($temp->attitude_evaluation=='5') echo 'selected';?>>ปานกลาง</option>
                                                                                                            <option value="6" <?php if($temp->attitude_evaluation=='6') echo 'selected';?>>พอใช้</option>
                                                                                                            <option value="7" <?php if($temp->attitude_evaluation=='7') echo 'selected';?>>ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="8" <?php if($temp->attitude_evaluation=='8') echo 'selected';?>>ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="9" <?php if($temp->attitude_evaluation=='9') echo 'selected';?>>รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="10" <?php if($temp->attitude_evaluation=='10') echo 'selected';?>>ผ่าน</option>
                                                                                                            <option value="11" <?php if($temp->attitude_evaluation=='11') echo 'selected';?>>ไม่ผ่าน</option>
                                                                                                        </select>    
                                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-t-10"></div>
                                                                                    <div class="row">
                                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                                                ผลการประเมินการอ่าน คิด วิเคราะห์และเขียน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="basic_subject_decision" name="basic_subject_decision">
                                                                                                            <option value="1" <?php if($temp->basic_subject_decision=='1') echo 'selected';?>>ดีเยี่ยม</option>
                                                                                                            <option value="2" <?php if($temp->basic_subject_decision=='2') echo 'selected';?>>ดีมาก</option>
                                                                                                            <option value="3" <?php if($temp->basic_subject_decision=='3') echo 'selected';?>>ดี</option>
                                                                                                            <option value="4" <?php if($temp->basic_subject_decision=='4') echo 'selected';?>>ค่อนข้างดี</option>
                                                                                                            <option value="5" <?php if($temp->basic_subject_decision=='5') echo 'selected';?>>ปานกลาง</option>
                                                                                                            <option value="6" <?php if($temp->basic_subject_decision=='6') echo 'selected';?>>พอใช้</option>
                                                                                                            <option value="7" <?php if($temp->basic_subject_decision=='7') echo 'selected';?>>ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="8" <?php if($temp->basic_subject_decision=='8') echo 'selected';?>>ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="9" <?php if($temp->basic_subject_decision=='9') echo 'selected';?>>รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="10" <?php if($temp->basic_subject_decision=='10') echo 'selected';?>>ผ่าน</option>
                                                                                                            <option value="11" <?php if($temp->basic_subject_decision=='11') echo 'selected';?>>ไม่ผ่าน</option>
                                                                                                        </select>      
                                                                                                        </div>
                                                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                                                ผลการตัดสิน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="attitude_decision" name="attitude_decision">
                                                                                                            <option value="1" <?php if($temp->attitude_decision=='1') echo 'selected';?>>ดีเยี่ยม</option>
                                                                                                            <option value="2" <?php if($temp->attitude_decision=='2') echo 'selected';?>>ดีมาก</option>
                                                                                                            <option value="3" <?php if($temp->attitude_decision=='3') echo 'selected';?>>ดี</option>
                                                                                                            <option value="4" <?php if($temp->attitude_decision=='4') echo 'selected';?>>ค่อนข้างดี</option>
                                                                                                            <option value="5" <?php if($temp->attitude_decision=='5') echo 'selected';?>>ปานกลาง</option>
                                                                                                            <option value="6" <?php if($temp->attitude_decision=='6') echo 'selected';?>>พอใช้</option>
                                                                                                            <option value="7" <?php if($temp->attitude_decision=='7') echo 'selected';?>>ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="8" <?php if($temp->attitude_decision=='8') echo 'selected';?>>ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="9" <?php if($temp->attitude_decision=='9') echo 'selected';?>>รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="10" <?php if($temp->attitude_decision=='10') echo 'selected';?>>ผ่าน</option>
                                                                                                            <option value="11" <?php if($temp->attitude_decision=='11') echo 'selected';?>>ไม่ผ่าน</option>
                                                                                                        </select>    
                                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-t-10"></div>
                                                                                    <div class="row">
                                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                                                ผลการประเมินคุณลักษณะอันพึงประสงค์
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="reading_evaluation" name="reading_evaluation">
                                                                                                            <option value="1" <?php if($temp->reading_evaluation=='1') echo 'selected';?>>ดีเยี่ยม</option>
                                                                                                            <option value="2" <?php if($temp->reading_evaluation=='2') echo 'selected';?>>ดีมาก</option>
                                                                                                            <option value="3" <?php if($temp->reading_evaluation=='3') echo 'selected';?>>ดี</option>
                                                                                                            <option value="4" <?php if($temp->reading_evaluation=='4') echo 'selected';?>>ค่อนข้างดี</option>
                                                                                                            <option value="5" <?php if($temp->reading_evaluation=='5') echo 'selected';?>>ปานกลาง</option>
                                                                                                            <option value="6" <?php if($temp->reading_evaluation=='6') echo 'selected';?>>พอใช้</option>
                                                                                                            <option value="7" <?php if($temp->reading_evaluation=='7') echo 'selected';?>>ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="8" <?php if($temp->reading_evaluation=='8') echo 'selected';?>>ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="9" <?php if($temp->reading_evaluation=='9') echo 'selected';?>>รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="10" <?php if($temp->reading_evaluation=='10') echo 'selected';?>>ผ่าน</option>
                                                                                                            <option value="11" <?php if($temp->reading_evaluation=='11') echo 'selected';?>>ไม่ผ่าน</option>
                                                                                                        </select>      
                                                                                                        </div>
                                                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                                                ผลการตัดสิน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="activity_evaluation" name="activity_evaluation">
                                                                                                            <option value="1" <?php if($temp->activity_evaluation=='1') echo 'selected';?>>ดีเยี่ยม</option>
                                                                                                            <option value="2" <?php if($temp->activity_evaluation=='2') echo 'selected';?>>ดีมาก</option>
                                                                                                            <option value="3" <?php if($temp->activity_evaluation=='3') echo 'selected';?>>ดี</option>
                                                                                                            <option value="4" <?php if($temp->activity_evaluation=='4') echo 'selected';?>>ค่อนข้างดี</option>
                                                                                                            <option value="5" <?php if($temp->activity_evaluation=='5') echo 'selected';?>>ปานกลาง</option>
                                                                                                            <option value="6" <?php if($temp->activity_evaluation=='6') echo 'selected';?>>พอใช้</option>
                                                                                                            <option value="7" <?php if($temp->activity_evaluation=='7') echo 'selected';?>>ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="8" <?php if($temp->activity_evaluation=='8') echo 'selected';?>>ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="9" <?php if($temp->activity_evaluation=='9') echo 'selected';?>>รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="10" <?php if($temp->activity_evaluation=='10') echo 'selected';?>>ผ่าน</option>
                                                                                                            <option value="11" <?php if($temp->activity_evaluation=='11') echo 'selected';?>>ไม่ผ่าน</option>
                                                                                                        </select>    
                                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="m-t-10"></div>
                                                                                    <div class="row">
                                                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                                                ผลการประเมินกิจกรรมพัฒนาผู้เรียน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="reading_decision" name="reading_decision">
                                                                                                            <option value="1" <?php if($temp->reading_decision=='1') echo 'selected';?>>ดีเยี่ยม</option>
                                                                                                            <option value="2" <?php if($temp->reading_decision=='2') echo 'selected';?>>ดีมาก</option>
                                                                                                            <option value="3" <?php if($temp->reading_decision=='3') echo 'selected';?>>ดี</option>
                                                                                                            <option value="4" <?php if($temp->reading_decision=='4') echo 'selected';?>>ค่อนข้างดี</option>
                                                                                                            <option value="5" <?php if($temp->reading_decision=='5') echo 'selected';?>>ปานกลาง</option>
                                                                                                            <option value="6" <?php if($temp->reading_decision=='6') echo 'selected';?>>พอใช้</option>
                                                                                                            <option value="7" <?php if($temp->reading_decision=='7') echo 'selected';?>>ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="8" <?php if($temp->reading_decision=='8') echo 'selected';?>>ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="9" <?php if($temp->reading_decision=='9') echo 'selected';?>>รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="10" <?php if($temp->reading_decision=='10') echo 'selected';?>>ผ่าน</option>
                                                                                                            <option value="11" <?php if($temp->reading_decision=='11') echo 'selected';?>>ไม่ผ่าน</option>
                                                                                                        </select>      
                                                                                                        </div>
                                                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                                                ผลการตัดสิน
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                        <select class="form-control custom-select text-muted" id="activity_decision" name="activity_decision">
                                                                                                            <option value="1" <?php if($temp->activity_decision=='1') echo 'selected';?>>ดีเยี่ยม</option>
                                                                                                            <option value="2" <?php if($temp->activity_decision=='2') echo 'selected';?>>ดีมาก</option>
                                                                                                            <option value="3" <?php if($temp->activity_decision=='3') echo 'selected';?>>ดี</option>
                                                                                                            <option value="4" <?php if($temp->activity_decision=='4') echo 'selected';?>>ค่อนข้างดี</option>
                                                                                                            <option value="5" <?php if($temp->activity_decision=='5') echo 'selected';?>>ปานกลาง</option>
                                                                                                            <option value="6" <?php if($temp->activity_decision=='6') echo 'selected';?>>พอใช้</option>
                                                                                                            <option value="7" <?php if($temp->activity_decision=='7') echo 'selected';?>>ผ่านเกณฑ์ขั้นต่ำ</option>
                                                                                                            <option value="8" <?php if($temp->activity_decision=='8') echo 'selected';?>>ต่ำกว่าเกณฑ์</option>
                                                                                                            <option value="9" <?php if($temp->activity_decision=='9') echo 'selected';?>>รอการตัดสินผลการเรียน</option>
                                                                                                            <option value="10" <?php if($temp->activity_decision=='10') echo 'selected';?>>ผ่าน</option>
                                                                                                            <option value="11" <?php if($temp->activity_decision=='11') echo 'selected';?>>ไม่ผ่าน</option>
                                                                                                        </select>    
                                                                                                        </div>
                                                                                    </div>
                                                                                    <div style="margin-top:21px;"></div> 
                                                                                    <div class="text-right m-b-10">
                                                                                            <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                                            <button type="submit" id="addStudentBtn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                                    </div>
                                                                                </form>    
                                                                            </div>
                                                                                
                                                                        </div>