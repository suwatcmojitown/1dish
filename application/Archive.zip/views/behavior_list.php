<?php 
//console($result);
?>
<!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <div class="text-right m-b-10">
                                        <button class="btn btn-success" type="submit" data-toggle="modal" data-target="#responsive-modal"> <span><i class="fa fa-file-o"></i>  เพิ่มหัวข้อความประพฤติ</span> </button>
                                </div>
                                
                                <hr class="m-t-0 m-b-20">
                                
                                <div class="row m-b-15">
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ประเภท
                                                </div>
                                                <div class="col-md-2">
                                                        <select class="form-control custom-select text-muted" id="type" name="type">
                                                                            <option value="">ทั้งหมด</option>
                                                                            <option value="plus">เพิ่มคะแนน</option>
                                                                            <option value="minus">หักคะแนน</option>
                                                        </select>
                                                </div>
                                                <div class="offset-md-1 col-md-3">
                                                        <input type="text" id="search" name="search" class="form-control" placeholder="คำค้นหา">
                                                </div>  
                                                <div class="offset-md-1 col-md-2">
                                                      <button type="button" id="searchBtn" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                
                                
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper" id="content_div">
                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <th style="width:40%;">ชื่อ</th>
                                                    <th style="width:15%;">ประเภท</th>
                                                    <th style="width:15%;">คะแนน</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                if(isset($result)&&!empty($result))
                                                {
                                                    $i = 1;
                                                    foreach($result as $row)
                                                    {
                                                ?>
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo $row->title;?></td>
                                                    <td><?php echo $row->point_type;?></td>
                                                    <td><?php echo $row->point;?></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข"> <i class="fa fa-pencil text-warning m-r-10"></i> </a>
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="ลบ" > <i class="fa fa-close text-danger"></i> </a>
                                                    </td>
                                                </tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                            
                                    
                                    <hr>
                                    
                                </div>
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
                <!-- modal -->
                <div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog modal-lg" >
                                                        <div class="modal-content">
                                                            <div class="modal-header alert-success">
                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> เพิ่มหัวข้อความประพฤติ</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post" action="cus_order_add.php" >
                                                                    <div class="row">
                                                                        <div class="col-md-3 text-success" style="padding-top: 7px;">
                                                                                ชื่อ
                                                                        </div>
                                                                        <div class="col-md-8">
                                                                                <input type="text" id="title" name="title" class="form-control" placeholder="กรอกหัวข้อคะแนนความประพฤติ" aria-describedby="search-txt">        
                                                                        </div>
                                                                    </div>
                                                                    <div class="m-t-10"></div>
                                                                    <div class="row">
                                                                        <div class="col-md-3 text-success" style="padding-top: 7px;">
                                                                                ประเภท
                                                                        </div>
                                                                        <div class="col-md-3">
                                                                                <select class="form-control custom-select text-muted" id="btype" name="btype">
                                                                                                    <option value="0">--เลือก--</option>
                                                                                                    <option value="plus">เพิ่มคะแนน</option>
                                                                                                    <option value="minus">หักคะแนน</option>
                                                                                </select>       
                                                                        </div>
                                                                    </div>
                                                                    <div class="m-t-10"></div>
                                                                    <div class="row">
                                                                        <div class="col-md-3 text-success" style="padding-top: 7px;">
                                                                                คะแนน
                                                                        </div>
                                                                        <div class="col-md-4">
                                                                                <input type="text" id="score" name="score" class="form-control" placeholder="กรอกคะแนน" aria-describedby="search-txt">        
                                                                        </div>
                                                                    </div>
                                                                    <!--
                                                                    <div class="m-t-10"></div>
                                                                    <div class="row">
                                                                        <div class="col-md-3 text-success" style="padding-top: 7px;">
                                                                                สถานะ
                                                                        </div>
                                                                        <div class="col-md-6" style="padding-top: 7px;">
                                                                                <div class="custom-control custom-radio custom-control-inline">
                                                                                    <input type="radio" id="status-enable" name="status" class="custom-control-input" checked>
                                                                                    <label class="custom-control-label" for="customRadioInline1">ใช้งาน</label>
                                                                                </div>
                                                                                <div class="custom-control custom-radio custom-control-inline">
                                                                                    <input type="radio" id="status-disable" name="status" class="custom-control-input" >
                                                                                    <label class="custom-control-label" for="customRadioInline2">เลิกใช้งาน</label>
                                                                                </div>       
                                                                        </div>
                                                                    </div>
                                                                    -->
                                                                    <div style="margin-top:21px;"></div> 
                                                                    <div class="text-right m-b-10">
                                                                        <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                        <button type="button" id="addBehavior" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                    </div>
                                                                </form>    
                                                            </div>
                                                                
                                                        </div>
                                                    </div>
                </div>
                <!-- modal -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

        <script>
        $( "#type").change(function() {
            type = document.getElementById("type").value;
            //alert(type);
            $.ajax({
                type: 'POST',
                url: 'behaviorLoad',
                data: 'type='+type+'',
                success: function(result) { 
                    //alert(result);
                    $("#content_div").html(result);
                }
            });
        });

        $( "#searchBtn").click(function() {
            search = document.getElementById("search").value;
            location.href = '<?php echo base_url('setting/behaviorList?search=')?>'+search+'';      
        });

        $( "#addBehavior").click(function() {
            title = document.getElementById("title").value;
            btype = document.getElementById("btype").value;
            score = document.getElementById("score").value;

            $.ajax({
                type: 'POST',
                url: 'behaviorAdd',
                data: 'type='+btype+'&title='+title+'&score='+score+'',
                success: function(result) { 
                    alert(result);
                }
            });    
        });
        </script>