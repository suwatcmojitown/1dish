<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">
                        <div class="card-body">
                                <form id="classroom-create" action="subjectAdd" class="form-horizontal" method="post" enctype="multipart/form-data">
                                    <div class="form-body">
                                        <div class="card-header badge-success">
                                        <h4 class="m-b-0 text-white">เพิ่มวิชา</h4></div>
                                        <h3 class="box-title"></h3>
                                        <hr class="m-t-0 m-b-20">
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="control-label p-l-5 m-b-5 text-primary">ชั้น</label>
                                                    <select class="form-control custom-select text-muted" id="education" name="education" required>
                                                                            <option value="0">ทั้งหมด</option>
                                                                            <?php 
                                                                            if(isset($educationList)&&!empty($educationList)){
                                                                                foreach($educationList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                            ?>
                                                    </select>   
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="control-label p-l-5 m-b-5 text-primary">ระดับ</label>
                                                    <select class="form-control custom-select text-muted" id="educationSub" name="educationSub" required>
                                                                            <option value="0">ทั้งหมด</option>
                                                                            <?php 
                                                                            if(isset($educationSubList)&&!empty($educationSubList)){
                                                                                foreach($educationSubList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                            ?>
                                                    </select>   
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="control-label p-l-5 m-b-5 text-primary">กลุ่มสาระ</label>
                                                    <select class="form-control custom-select text-muted" id="subjectGroup" name="subjectGroup" required>
                                                                            <option value="0">ทั้งหมด</option>
                                                                            <?php 
                                                                            if(isset($subjectGroupList)&&!empty($subjectGroupList)){
                                                                                foreach($subjectGroupList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                            ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="control-label p-l-5 m-b-5 text-primary">ประเภท</label>
                                                    <select class="form-control custom-select text-muted" id="subjectType" name="subjectType" required>
                                                                            <option value="0">ทั้งหมด</option>
                                                                            <?php 
                                                                            if(isset($subjectTypeList)&&!empty($subjectTypeList)){
                                                                                foreach($subjectTypeList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                            ?>               
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <hr>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="control-label p-l-5 m-b-5 text-primary">รหัสวิชา</label>
                                                        <input type="text" id="code" name="code" class="form-control" placeholder="กรอกรหัสวิชา">  
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-5">
                                                <div class="form-group">
                                                    <label class="control-label p-l-5 m-b-5 text-primary">ชื่อวิชา</label>
                                                        <input type="text" id="name_th" name="name_th" class="form-control" placeholder="กรอกชื่อวิชา">  
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-5">
                                                <div class="form-group">
                                                    <label class="control-label p-l-5 m-b-5 text-primary">ชื่อวิชา Eng</label>
                                                        <input type="text" id="name_en" name="name_en" class="form-control" placeholder="กรอกชื่อวิชา Eng">  
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label class="control-label p-l-5 m-b-5 text-primary">หน่วยกิจ</label>
                                                        <input type="text" id="unit" name="unit" class="form-control" placeholder="กรอกหน่วยกิจ">  
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <!--/row-->
                                        <!--
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="p-l-5 m-b-5 text-primary">สถานะ</label>
                                                    <br>
                                                    <div class="custom-control custom-radio custom-control-inline">
                                                        <input type="radio" id="status-enable" name="status" class="custom-control-input" checked>
                                                        <label class="custom-control-label" for="customRadioInline1">ใช้งาน</label>
                                                    </div>
                                                    <div class="custom-control custom-radio custom-control-inline">
                                                        <input type="radio" id="status-disable" name="status" class="custom-control-input" >
                                                        <label class="custom-control-label" for="customRadioInline2">เลิกใช้งาน</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        -->
                                        <!--/row-->
                                        <hr class="m-t-0 m-b-20">
                                        <div class="row">
                                                    <div class="col-12">
                                                        <div class="form-group row">

                                                            <div class="offset-md-9 col-md-1">
                                                                 <button class="btn btn-danger pull-right" input type="reset" >ยกเลิก</button>
                                                                
                                                            </div>    
                                                            <div class="col-md-1">
                                                                 <button class="btn btn-success pull-right btn-outline" input type="submit"> บันทึก</button>
                                                            </div>     
                                                        </div>
                                                    </div>
                                        </div>
                                    </div>
                                </form>  
                                <!-- form -->
                            </div>
                            <!-- card body -->    
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

    