<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
<?php 
if($alert!='')
{
    if($alert=='success'){
?>
        swal("success!", "ทำรายการสำเร็จ", "success");
<?php 
    }
    else
    {
?> 
        swal("Error!", "ไม่สามารถทำรายการได้", "error");
<?php 
    }
}
?>
</script>
<!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <?php 
                   //getParentList(12604);
                   //console($list);
                   ?> 
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                
                                <div class="row m-b-15">
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <div class="col-md-4">
                                                        <input type="text" id="search" name="search" class="form-control" placeholder="คำค้นหา : เลขประจำตัว,เลขประชาชน,ชื่อ,นามสกุล" value="<?php if($keysearch!='')echo $keysearch;?>">
                                                </div> 
                                                <div class="col-md-2">
                                                      <button type="button" id="searchBtn" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                
                                
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper">
                                        <table class="table color-table">
                                            <thead>
                                                <tr style="background-color: #00a5a6;color: #fff;">
                                                    <th style="width:5%;">#</th>
                                                    <th style="width:10%;">รหัสนักเรียน</th>
                                                    <th style="width:15%;">ชื่อ - นามสกุล</th>
                                                    <th style="width:15%;">ระดับชั้น</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                    if(isset($list)&&!empty($list)){
                                                        $i = 1;
                                                        foreach($list as $row)
                                                        {
                                                ?>
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo $row->student_no;?></td>
                                                    <td><?php echo $row->name_th;?></td>
                                                    <td><?php echo $row->room;?></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <button class="open-AddBookDialog btn btn-success" type="button" data-id="<?php echo $row->id;?>" data-toggle="modal" data-target="#responsive-modal"> <span>เพิ่มคะแนน</span> </button>
                                                        <button class="open-AddBookDialog2 btn btn-danger" type="button" data-id="<?php echo $row->id;?>" data-toggle="modal" data-target="#responsive-modal2"> <span>หักคะแนน</span></button>
                                                    </td>
                                                </tr>
                                                <?php 
                                                        $i++;
                                                        }
                                                    }    
                                                ?>
                                            </tbody>
                                        </table>
                                    <hr>
                                    
                                </div>
                                   
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

            <!-- modal -->
            <div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog modal-lg" >
                                                        <div class="modal-content">
                                                            <div class="modal-header alert-success">
                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> เพิ่มคะแนน</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post" action="cus_order_add.php" >
                                                                    <div class="row m-t-10">
                                                                        <input type="hidden" id="bookId" class="form-control" placeholder="กรอกชื่อวิชา" aria-describedby="search-txt"> 
                                                                        
                                                                        <div class="col-md-2 text-success" >
                                                                                หัวข้อ
                                                                        </div>
                                                                        <div class="col-md-7" >
                                                                                <select class="form-control custom-select text-muted" id="point" >
                                                                                                <option value="0">-- เลือกหัวข้อ --</option>
                                                                                                <?php 
                                                                                                if(isset($behaviorPlusList)&&!empty($behaviorPlusList))
                                                                                                {
                                                                                                    foreach($behaviorPlusList as $row)
                                                                                                    {
                                                                                                ?>
                                                                                                <option value="<?php echo $row->point;?>"><?php echo $row->title?> : <?php echo $row->point;?></option>
                                                                                                <?php 
                                                                                                    }
                                                                                                }    
                                                                                                ?>
                                                                                </select>     
                                                                        </div>
                                                                    </div>
                                                                    <div class="row m-t-15">
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                รายละเอียด
                                                                        </div>
                                                                        <div class="col-md-8">
                                                                                <textarea type="text" id="description" class="form-control"></textarea>  
                                                                        </div>
                                                                    </div>
                                                                    <div style="margin-top:21px;"></div> 
                                                                    <div class="text-right m-b-10">
                                                                        <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                        <button type="button" class="btn btn-success waves-effect waves-light alert-success" id="submitPlus">บันทึก</button>
                                                                    </div>
                                                                </form>    
                                                            </div>
                                                                
                                                        </div>
                                                    </div>
            </div>
            <!-- modal --> 

            <!-- modal -->
            <div id="responsive-modal2" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog modal-lg" >
                                                        <div class="modal-content">
                                                            <div class="modal-header alert-danger">
                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> หักคะแนน</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post" action="cus_order_add.php" >
                                                                    <div class="row m-t-10">
                                                                        <input type="hidden" id="bookId" class="form-control" placeholder="กรอกชื่อวิชา" aria-describedby="search-txt"> 
                                                                        <div class="col-md-2 text-success" >
                                                                                หัวข้อ
                                                                        </div>
                                                                        <div class="col-md-7" >
                                                                                <select class="form-control custom-select text-muted" id="m_point" >
                                                                                                <option value="0">-- เลือกหัวข้อ --</option>
                                                                                                <?php 
                                                                                                if(isset($behaviorMinusList)&&!empty($behaviorMinusList))
                                                                                                {
                                                                                                    foreach($behaviorMinusList as $row)
                                                                                                    {
                                                                                                ?>
                                                                                                <option value="<?php echo $row->point;?>"><?php echo $row->title?> : <?php echo $row->point;?></option>
                                                                                                <?php 
                                                                                                    }
                                                                                                }    
                                                                                                ?>
                                                                                </select>     
                                                                        </div>
                                                                    </div>
                                                                    <div class="row m-t-15">
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                รายละเอียด
                                                                        </div>
                                                                        <div class="col-md-8">
                                                                                <textarea type="text" id="m_description" class="form-control"></textarea>   
                                                                               
                                                                        </div>
                                                                    </div>
                                                                    <div style="margin-top:21px;"></div> 
                                                                    <div class="text-right m-b-10">
                                                                        <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                        <button type="button" id="submitMinus" class="btn btn-success waves-effect waves-light alert-success" id="submit_btn">บันทึก</button>
                                                                    </div>
                                                                </form>    
                                                            </div>
                                                                
                                                        </div>
                                                    </div>
            </div>
            <!-- modal -->   
            <!-- Button trigger modal -->


<!-- Modal -->
<div id="successModal" class="modal fade center" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                        <div class="modal-dialog modal-sm" >
                                                    <div class="alert alert-success">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                                                    <h3 class="text-success"><i class="fa fa-check-circle"></i> 
                                                    Success</h3> ระบบได้ทำรายการเรียบร้อยแล้ว
                                                    </div>
                                        </div>
</div> 
<div id="errorModal" class="modal fade center" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                        <div class="modal-dialog modal-sm" >
                                                    <div class="alert alert-danger">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                                                    <h3 class="text-denger"><i class="fa fa-exclamation-triangle">
                                                    </i> Error</h3>  ระบบไม่สามารถทำรายการได้ กรุณาลองใหม่อีกครั้ง
                                                    </div>
                                        </div>
</div>                                        
<!-- Modal -->            

            <script>
                    
                    $( "#searchBtn").click(function() {
                        search = document.getElementById("search").value;
                        location.href = '<?php echo base_url('behavior/createEvent?keysearch=')?>'+search+'';      
                    });                                

                    $(document).on("click", ".open-AddBookDialog", function () {

                        var myBookId = $(this).data('id');
                        $(".modal-body #bookId").val( myBookId );
                        
                    });

                    $("#submitPlus").click(function(){
                        
                        student_id = document.getElementById("bookId").value;
                        description = document.getElementById("description").value;
                        point = document.getElementById("point").value;
                        title = $('#point').find("option:selected").text();;
                        $.ajax({
                            type: 'POST',
                            url: '<?php echo base_url('behavior/')?>addEvent',
                            data: 'student_id='+student_id+'&description='+description+'&point='+point+'&title='+title,
                            success: function(result) { 
                                if(result)
                                {
                                    $("#successModal").modal('toggle'); 
                                } 
                                else $("#errorModal").modal('toggle'); 
                                $('#responsive-modal').modal('hide');
                            }
                        });
                        
                    });

                    $(document).on("click", ".open-AddBookDialog2", function () {
                        var myBookId = $(this).data('id');
                        $(".modal-body #bookId").val( myBookId );
                        
                    });

                    $("#submitMinus").click(function(){
                        student_id = document.getElementById("bookId").value;
                        description = document.getElementById("m_description").value;
                        point = document.getElementById("m_point").value;
                        title = $('#m_point').find("option:selected").text();;
                        $.ajax({
                            type: 'POST',
                            url: '<?php echo base_url('behavior/')?>addEvent',
                            data: 'student_id='+student_id+'&description='+description+'&point='+point+'&title='+title,
                            success: function(result) { 
                                if(result)
                                {
                                    $("#successModal").modal('toggle'); 
                                } 
                                else $("#errorModal").modal('toggle'); 
                                $('#responsive-modal2').modal('hide');
                            }
                        });
                    });
     </script>