                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <div class="text-right m-b-10">
                                        <button class="btn btn-success" type="submit" data-toggle="modal" data-target="#responsive-modal"> <span><i class="fa fa-file-o"></i>  เพิ่มประเภท</span> </button>
                                </div>
                                
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper">
                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <th style="width:20%;">ชื่อ</th>
                                                    <th style="width:20%;">ชื่อ Eng</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                
                                                <?php 
                                                if(isset($result)&&!empty($result)){
                                                    $i = 1;
                                                    foreach($result as $row){
                                                ?> 
                                                <tr>   
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo $row->name_th;?></td>
                                                    <td><?php echo $row->name_en;?></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-alert"></i> </a>
                                                    </td>
                                                </tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }    
                                                ?>
                                            </tbody>
                                        </table>
                                        
                                    <hr>
                                    
                                </div>
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- modal -->
                <div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog modal-md" >
                                                        <div class="modal-content">
                                                            <div class="modal-header alert-success">
                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> เพิ่มประเภท</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post" action="cus_order_add.php" >
                                                                    <div class="row">
                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                ชื่อประเภท
                                                                        </div>
                                                                        <div class="col-md-7">
                                                                                <input type="text" class="form-control" id="m_name" name="m_name" placeholder="กรอกประเภท" aria-describedby="search-txt">        
                                                                        </div>
                                                                    </div>
                                                                    <div class="m-t-10"></div>
                                                                    <div class="row">
                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                ชื่อประเภท Eng
                                                                        </div>
                                                                        <div class="col-md-7">
                                                                                <input type="text" class="form-control" id="m_name_en" name="m_name_en" placeholder="กรอกประเภท Eng" aria-describedby="search-txt">        
                                                                        </div>
                                                                    </div>
                                                                    <!--
                                                                     <div class="m-t-10"></div>
                                                                    <div class="row">
                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                สถานะ
                                                                        </div>
                                                                        <div class="col-md-6" style="padding-top: 7px;">
                                                                                <div class="custom-control custom-radio custom-control-inline">
                                                                                    <input type="radio" id="status-enable" name="status" class="custom-control-input" checked>
                                                                                    <label class="custom-control-label" for="customRadioInline1">ใช้งาน</label>
                                                                                </div>
                                                                                <div class="custom-control custom-radio custom-control-inline">
                                                                                    <input type="radio" id="status-disable" name="status" class="custom-control-input" >
                                                                                    <label class="custom-control-label" for="customRadioInline2">เลิกใช้งาน</label>
                                                                                </div>       
                                                                        </div>
                                                                    </div>
                                                                    -->
                                                                    <div style="margin-top:21px;"></div> 
                                                                    <div class="text-right m-b-10">
                                                                        <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                        <button type="button" id="submit_btn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                    </div>
                                                                </form>    
                                                            </div>
                                                                
                                                        </div>
                                                    </div>
                </div>
                <!-- modal -->
                </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

        <script>
        
        $("#submit_btn").click(function(){
            name = document.getElementById("m_name").value;
            name_en = document.getElementById("m_name_en").value;
            $.ajax({
                type: 'POST',
                url: 'subjectTypeAdd',
                data: 'name='+name+'&name_en='+name_en,
                success: function(result) {   
                    location.reload();
                }
            });
        });
        </script>