                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <?php 
                                //console($academicYearList);
                                ?>
                                <!--
                                <div class="text-right m-b-10">
                                        <a href="classroomCreate"><button class="btn btn-success" type="submit" data-toggle="modal" data-target="#responsive-modal"> <span><i class="fa fa-file-o"></i>  เพิ่มชั้นเรียน</span> </button></a>
                                </div>
                                -->
                                
                                <div class="row m-b-15">
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <?php 
                                                //console($educationList);
                                                ?>
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ชั้น
                                                </div>
                                                <div class="col-md-2" >
                                                        <select class="form-control custom-select text-muted" id="education" name="education">
                                                                        <option value="0">ทั้งหมด</option>
                                                                        <?php 
                                                                            if(isset($educationList)&&!empty($educationList)){
                                                                                foreach($educationList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                        ?>
                                                        </select>
                                                                
                                                </div> 
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ระดับ
                                                </div>
                                                <div class="col-md-2" id="educationSublevel_div">
                                                        <select class="form-control custom-select text-muted" id="educationSub" name="educationSub">
                                                                            <option value="0">ทั้งหมด</option>
                                                        </select>
                                                </div>

                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        ห้อง
                                                </div>
                                                <div class="col-md-2" id="room_div">
                                                        <select class="form-control custom-select text-muted" id="room" name="room">
                                                                            <option value="0">ทั้งหมด</option>
                                                        </select>
                                                </div>
                                                <!--
                                                <div class="offset-md-1 col-md-2">
                                                      <button type="button" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>
                                                                        -->
                                            </div>
                                            
                                            <div class="row m-t-10">
                                                <?php 
                                                //console($educationList);
                                                ?>
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                        วันที่
                                                </div>
                                                <div class="col-md-3" >
                                                    <input placeholder="เลือกวันที่ต้องการดู" class="form-control text-muted" type="text" onfocus="(this.type='date')" <?php echo date('Y-m-d'); ?> id="date">    
                                                    
                                                </div> 
                                                <div class="offset-md-6 col-md-2" >
                                                    <button class="btn btn-info" type="button" id="refresh" > <span><i class="fa fa-refresh"></i> โหลดข้อมูลอีกครั้ง</span> </button></a>
                                                </div> 
                                            </div>
                                        </div>
                                </div>
                                
                                <hr class="m-t-0 m-b-10">
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper" id="content_div">
                                                                    
                                        <table class="table color-table danger-table ">
                                            <thead>
                                                <tr>
                                                    <!--<th style="width:10%;">ปีการศึกษา</th>-->
                                                    <th style="width:10%;">เลขที่</th>
                                                    <th style="width:30%;">ชื่อ - นามสกุล</th>
                                                    <th style="width:20%;">เวลาเข้าโรงเรียน</th>
                                                    <th style="width:20%;">เวลาออกโรงเรียน</th>
                                                    <th style="width:15%;"></th>
                                                    <th ></th>
                                                </tr>
                                            </thead>
                                        </table>
                                    
                                </div>
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
 
        <script>
        $( "#education").change(function() {
            a = document.getElementById("education").value;
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url('timesheet/')?>loadEducationSub',
                data: 'education='+a+'&academic_year=<?php echo $academicYearNow;?>&term_id=<?php echo $term_id;?>',
                success: function(result) { 
                    $("#educationSublevel_div").html(result);
                    
                }
            });    
        });

        $( "#date").change(function() {
            educationSub = document.getElementById("educationSub").value;
            room = document.getElementById("room").value;
            date = document.getElementById("date").value;
            //alert(date);
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url('timesheet/')?>listLoad',
                data: 'educationSub='+educationSub+'&room='+room+'&date='+date+'',
                success: function(result) { 
                            $("#content_div").html(result);
                }
            }); 
        });

        $( "#refresh").click(function() {
            educationSub = document.getElementById("educationSub").value;
            room = document.getElementById("room").value;
            date = document.getElementById("date").value;
            //alert(date);
            if(date=='') date = 'now';
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url('timesheet/')?>listLoad',
                data: 'educationSub='+educationSub+'&room='+room+'&date='+date+'',
                success: function(result) { 
                            $("#content_div").html(result);
                }
            }); 
        });

        
 
        </script>
