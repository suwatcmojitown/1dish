                                <?php //console($result);?>
                                <div class="ribbon-wrapper">
                                    <div class="ribbon ribbon-success">วันที่ : <?php echo $active_date;?></div>
                                </div>
                                        
                                        <div class="card-group">
                                            <!-- Column -->
                                            <div class="card">
                                                            <div class="card-body">
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <h2 class="text-info"><?php echo @$result->total_student;?></h2>
                                                                        <p class="text-muted">จำนวน ทั้งหมด</p>
                                                                    </div>
                                                                    <div class="col-12">
                                                                        <div class="progress">
                                                                            <div class="progress-bar bg-info" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                            </div>
                                            <!-- Column -->
                                            <!-- Column -->
                                            <div class="card">
                                                            <div class="card-body">
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <h2 class="text-cyan"><?php echo @$result->normal;?></h2>
                                                                        <p class="text-muted">จำนวน มาเรียน</p>
                                                                    </div>
                                                                    <div class="col-12">
                                                                        <div class="progress">
                                                                            <div class="progress-bar bg-cyan" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                            </div>
                                            <!-- Column -->
                                            <!-- Column -->
                                            <div class="card">
                                                            <div class="card-body">
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <h2 class="text-warning"><?php echo @$result->late;?></h2>
                                                                        <p class="text-muted">จำนวน มาสาย</p>
                                                                    </div>
                                                                    <div class="col-12">
                                                                        <div class="progress">
                                                                            <div class="progress-bar bg-warning" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                            </div>
                                            <!-- Column -->
                                            <!-- Column -->
                                            <div class="card">
                                                            <div class="card-body">
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <h2 class="text-danger"><?php echo @$result->absent;?></h2>
                                                                        <p class="text-muted">จำนวน ขาด/ลา</p>
                                                                    </div>
                                                                    <div class="col-12">
                                                                        <div class="progress">
                                                                            <div class="progress-bar bg-danger" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                            </div>
                                            <!-- Column -->
                                            <!-- Column -->
                                            <div class="card">
                                                            <div class="card-body">
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <h2 class="text-purple"><?php echo @$result->leave_before_time;?></h2>
                                                                        <p class="text-muted">จำนวน กลับก่อนเวลา</p>
                                                                    </div>
                                                                    <div class="col-12">
                                                                        <div class="progress">
                                                                            <div class="progress-bar bg-purple" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                            </div>
                                            <!-- Column -->
                                        </div> 
                                        <table class="table color-table danger-table ">
                                            <thead>
                                                <tr>
                                                    <!--<th style="width:10%;">ปีการศึกษา</th>-->
                                                    <th style="width:10%;">เลขที่</th>
                                                    <th style="width:30%;">ชื่อ - นามสกุล</th>
                                                    <th style="width:18%;">เวลาเข้าโรงเรียน</th>
                                                    <th style="width:18%;">เวลาออกโรงเรียน</th>
                                                    <th style="width:15%;"></th>
                                                    <th ></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                //console($result);
                                                if(isset($result->student)&&!empty($result->student)){
                                                    $i = 1;
                                                    foreach($result->student as $row){
                                                ?> 
                                                <tr>
                                                    <td><?php echo @$row->student_no;?></td>
                                                    <td><a href="<?php echo base_url('student/profile/').$row->student_id;?>" target="_blank"><?php echo @$row->student_name;?></a></td>
                                                    <td><?php echo @$row->time_log[0]->checkin_time;?></td>
                                                    <td><?php echo @$row->time_log[0]->checkout_time;?></td>
                                                    <td>
                                                    <?php if(@$row->time_log[0]->status!='1'){?>
                                                        <a onclick="showModal('<?php echo @$row->time_log[0]->description;?>','<?php echo @$row->time_log[0]->parent_name;?>','<?php echo @$row->time_log[0]->cell_phone;?>');"><?php 
                                                        echo statusShow(@$row->time_log[0]->status);
                                                    ?></a>
                                                    <?php 
                                                    }else{
                                                        echo statusShow(@$row->time_log[0]->status);
                                                    }
                                                    ?>
                                                    </td>
                                                    <td>
                                                        <button class="open-AddBookDialog btn btn-success btn-sm" type="button" data-id="<?php echo $row->student_id;?>" data-toggle="modal" data-target="#add-modal"> <span><i class="fa fa-clock-o"></i></span> </button>
                                                        
                                                    <?php if(!empty(@$row->time_log[0]->checkin_time)||!empty(@$row->time_log[0]->checkout_time)){?>
                                                        <a onclick="del(<?php echo $row->student_id;?>)" ><button class="btn btn-danger btn-sm" type="button" > <span><i class="fa fa-trash-o"></i></span> </button></a>
                                                    <?php }?>
                                                    </td>
                                                <tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }    
                                                ?>     
                                            </tbody>
                                        </table>

    
                <div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog modal-md" >
                                                        <div class="modal-content">
                                                            <div class="modal-header alert-success">
                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> รายละเอียด</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post" action="cus_order_add.php" >
                                                                    <div class="row m-b-10">
                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                รายละเอียด      
                                                                        </div>
                                                                        <div class="col-md-8 p-t-10" id="m_detail">
                                                                                <span class="text-muted"></span>        
                                                                        </div>
                                                                    </div>
                                                                    <div class="row m-b-10">
                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                ผู้ปกครอง      
                                                                        </div>
                                                                        <div class="col-md-8 p-t-10" id="m_parent">
                                                                                <span class="text-muted"></span>        
                                                                        </div>
                                                                    </div>
                                                                    <div class="row m-b-10" >
                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                เบอร์โทรศัพท์      
                                                                        </div>
                                                                        <div class="col-md-8 p-t-10" id="m_tel">
                                                                                <span class="text-muted"></span>        
                                                                        </div>
                                                                    </div>
                                                                    <div style="margin-top:21px;"></div> 
                                                                    <!--
                                                                    <div class="text-right m-b-10">
                                                                        <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                        <button type="button" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                    </div>
                                                                    -->
                                                                </form>    
                                                            </div>
                                                                
                                                        </div>
                                                    </div>
                </div>

                <!-- modal -->
                <div id="add-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog modal-lg" >
                                                        <div class="modal-content">
                                                            <div class="modal-header alert-success">
                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> แจ้งบันทึกเวลา</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post" action="cus_order_add.php" >
                                                                    <div class="row m-t-15 m-b-15">
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                ประเภทการลงเวลา
                                                                        </div>
                                                                        <div class="col-md-3" >
                                                                                <select class="form-control custom-select text-muted" id="type_check" >
                                                                                                <option value="all">-- เลือกประเภทเช็คชื่อ --</option>
                                                                                                <option value="1">เช็คชื่อเข้าโรงเรียน</option>
                                                                                                <option value="0">เช็คชื่อออกโรงเรียน</option>
                                                                                </select>     
                                                                        </div>
                                                                    </div>
                                                                    <div class="row m-t-10">
                                                                        <input type="hidden" id="bookId" class="form-control" placeholder="กรอกชื่อวิชา" aria-describedby="search-txt"> 
                                                                        <input type="hidden" id="status" value="6"> 
                                                                        
                                                                        <div class="col-md-2 text-success" >
                                                                                ผู้ติดต่อ
                                                                        </div>
                                                                        <div class="col-md-3" >
                                                                                <select class="form-control custom-select text-muted" id="is_parent" >
                                                                                                <option value="all">-- เลือกผู้ติดต่อ --</option>
                                                                                                <option value="1">ผู้ปกครอง</option>
                                                                                                <option value="0">บุคคลอื่น</option>
                                                                                </select>     
                                                                        </div>
                                                                    </div>
                                                                    <div class="row m-t-15">
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                รายละเอียด
                                                                        </div>
                                                                        <div class="col-md-8">
                                                                                <textarea type="text" id="description" class="form-control"></textarea>   
                                                                                <small class="form-control-feedback text-danger">ในกรณีที่เป็นบุคคลอื่นมาแจ้ง ให้ใส่ชื่อและเบอร์โทรศัพท์ติดต่อ</small>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row m-t-15">
                                                                        <div class="col-md-2 text-success" >
                                                                                เวลา
                                                                        </div>
                                                                        <div class="col-md-4">
                                                                                <input type="time" id="add_time" class="form-control" style="padding-top: 7px;">  
                                                                        </div>
                                                                    </div>
                                                                    <div style="margin-top:21px;"></div> 
                                                                    <div class="text-right m-b-10">
                                                                        <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                        <button type="button" class="btn btn-success waves-effect waves-light alert-success" id="submit_btn">บันทึก</button>
                                                                    </div>
                                                                </form>    
                                                            </div>
                                                                
                                                        </div>
                                                    </div>
            </div>
            <!-- modal --> 

            <!-- Modal -->
            <div id="successModal" class="modal fade center" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog modal-sm" >
                                                                <div class="alert alert-success">
                                                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                                                                <h3 class="text-success"><i class="fa fa-check-circle"></i> 
                                                                Success</h3> ระบบได้ทำรายการเรียบร้อยแล้ว
                                                                </div>
                                                    </div>
            </div> 
            <div id="errorModal" class="modal fade center" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog modal-sm" >
                                                                <div class="alert alert-danger">
                                                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                                                                <h3 class="text-denger"><i class="fa fa-exclamation-triangle">
                                                                </i> Error</h3>  ระบบไม่สามารถทำรายการได้ กรุณาลองใหม่อีกครั้ง
                                                                </div>
                                                    </div>
            </div>                                        
            <!-- Modal -->    
    <script>
    function showModal(detail,parent,tel) {
        t_detail = '<span class="text-muted">'+detail+'</span>';
        $(".modal-body #m_detail").html(t_detail);
        t_parent = '<span class="text-muted">'+parent+'</span>';
        $(".modal-body #m_parent").html(t_parent);
        t_tel = '<span class="text-muted">'+tel+'</span>';
        $(".modal-body #m_tel").html(t_tel);
        $("#responsive-modal").modal();
    }
    /*
        $( "#subjectGroupSec").click(function() {
            a = 0;
            b = document.getElementById("subjectGroupSec").value;
            c = document.getElementById("educationSubSec").value;
            page = <?php echo $active_page;?>;
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url('subject/')?>listLoad',
                data: 'subjectType='+a+'&subjectGroup='+b+'&page='+page+'&educationSub='+c,
                success: function(result) { 
                    $("#load_content").html(result);
                }
            });
        });
    */ 

    function del(id){
            educationSub = document.getElementById("educationSub").value;
            room = document.getElementById("room").value;
            date = document.getElementById("date").value;
            if(date=='') date = 'now';
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url('timesheet/del')?>',
                data: 'educationSub='+educationSub+'&room='+room+'&date='+date+'&student_id='+id,
                success: function(result) { 
                            //alert(result);
                            $("#content_div").html(result);
                }
            }); 
            
        };  

    $(document).on("click", ".open-AddBookDialog", function () {
                        var myBookId = $(this).data('id');
                        $(".modal-body #bookId").val( myBookId );
                        
                    });

                    $("#submit_btn").click(function(){
                        
                        student_id = document.getElementById("bookId").value;
                        date = document.getElementById("date").value;
                        if(date=='') date = 'now';
                        time = document.getElementById("add_time").value;
                        description = document.getElementById("description").value;
                        is_parent = document.getElementById("is_parent").value;
                        type_check = document.getElementById("type_check").value;
                        status = document.getElementById("status").value;
                        
                        $.ajax({
                            type: 'POST',
                            url: '<?php echo base_url('hr/')?>addEventTimesheet',
                            data: 'student_id='+student_id+'&description='+description+'&time='+time+'&status='+status+'&is_parent='+is_parent+'&date='+date+'&type_check='+type_check,
                            success: function(result) {   
                                
                                if(result)
                                {
                                    $("#successModal").modal('toggle'); 
                                } 
                                else $("#errorModal").modal('toggle'); 
                                $('#add-modal').modal('hide');
                                
                            }
                        });
    });     
    </script>     
                                    