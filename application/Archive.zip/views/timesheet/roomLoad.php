<select class="form-control custom-select text-muted" id="room" name="room">
                                                                        <option value="0">ทั้งหมด</option>
                                                                        <?php 
                                                                            if(isset($result)&&!empty($result)){
                                                                                foreach($result as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->room;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                        ?>
</select>

<script>
        $( "#room").change(function() {
            academic_year = <?php echo $academicYearNow;?>;
            term_id = <?php echo $term_id;?>;
            education = document.getElementById("education").value;
            educationSub = document.getElementById("educationSub").value;
            room = document.getElementById("room").value;
            date = document.getElementById("date").value;
            
            //alert(date);

            if(date!='')
            {
                $.ajax({
                            type: 'POST',
                            url: '<?php echo base_url('timesheet/')?>listLoad',
                            data: 'educationSub='+educationSub+'&room='+room+'&date='+date,
                            success: function(result) { 
                                //alert(result);
                                $("#content_div").html(result);
                            }
                });
            }
            else
            {
                $.ajax({
                            type: 'POST',
                            url: '<?php echo base_url('timesheet/')?>listLoad',
                            data: 'educationSub='+educationSub+'&room='+room+'&date=now',
                            success: function(result) { 
                                //alert(result);
                                $("#content_div").html(result);
                            }
                }); 
            }
        });
</script>

                                                        
        