                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <div class="text-right m-b-10">
                                        <button class="btn btn-success" type="submit" data-toggle="modal" data-target="#responsive-modal"> <span><i class="fa fa-file-o"></i>  เพิ่มตำแหน่ง</span> </button>
                                </div>
                                
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper">
                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <th style="width:40%;">ชื่อ</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                
                                                <?php 
                                                if(isset($result)&&!empty($result)){
                                                    $i = 1;
                                                    foreach($result as $row){
                                                ?> 
                                                <tr>   
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo $row->title;?></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-warning"></i> </a>
                                                    </td>
                                                </tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }    
                                                ?>
                                            </tbody>
                                        </table>
                                        
                                    <hr>
                                    
                                </div>
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- modal -->
                <div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog modal-md" >
                                                        <div class="modal-content">
                                                            <div class="modal-header alert-success">
                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> เพิ่มตำแหน่ง</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post" action="cus_order_add.php" >
                                                                <div class="row">
                                                                        <div class="col-md-4 text-success" style="padding-top: 7px;">
                                                                                ชื่อตำแหน่ง
                                                                        </div>
                                                                        <div class="col-md-7">
                                                                                <input type="text" name="name" id="name" class="form-control" placeholder="กรอกชื่อตำแหน่ง" aria-describedby="search-txt">        
                                                                        </div>
                                                                    </div>
                                                                    <div style="margin-top:21px;"></div> 
                                                                    <div class="text-right m-b-10">
                                                                        <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                        <button type="button" id="submit_btn" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                    </div>
                                                                </form>    
                                                            </div>
                                                                
                                                        </div>
                                                    </div>
                </div>
                <!-- modal -->
                </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

        <script>
        
        $("#submit_btn").click(function(){
            name = document.getElementById("name").value;
            $.ajax({
                type: 'POST',
                url: 'personnelGroupAdd',
                data: 'name='+name,
                success: function(result) {   
                    location.reload();
                }
            });
        });
        </script>