<select class="form-control custom-select text-muted" id="room" name="room">
                                                                        <option value="0">ทั้งหมด</option>
                                                                        <?php 
                                                                            if(isset($result)&&!empty($result)){
                                                                                foreach($result as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->room;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                        ?>
</select>

<script>
        $( "#room").change(function() {
            academic_year = document.getElementById("academic_year").value;
            term_id = document.getElementById("term_id").value;
            education = document.getElementById("education").value;
            educationSub = document.getElementById("educationSub").value;
            room = document.getElementById("room").value;
            
            $.ajax({
                type: 'POST',
                url: 'classroomLoad',
                data: 'academic_year='+academic_year+'&term_id='+term_id+'&education='+education+'&educationSub='+educationSub+'&room='+room,
                success: function(result) { 
                    $("#content_div").html(result);
                }
            });
            
            
        });
</script>

                                                        
        