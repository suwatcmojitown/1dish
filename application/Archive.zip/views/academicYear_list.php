<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <div class="text-right m-b-10">
                                        <a href="<?php echo base_url('setting/academicYearCreate');?>"><button class="btn btn-success" type="button" > <span><i class="fa fa-file-o"></i>  เพิ่มปีการศึกษา</span> </button></a>
                                </div>
                                
                                <hr class="m-t-0 m-b-20">
                                <!--
                                <div class="row m-b-15">
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                <div class="col-md-1 text-cyan" style="padding-top: 7px;">
                                                        รายวิชา
                                                </div>
                                                <div class="col-md-3">
                                                        <select class="form-control custom-select text-muted">
                                                                            <option value="">ทั้งหมด</option>
                                                                            <option value="">ภาษาไทย</option>
                                                                            <option value="">ภาษาอังกฤษ</option>
                                                                            <option value="">คณิตศาสตร์</option>
                                                        </select>
                                                                
                                                </div> 
                                                <div class="col-md-1 text-cyan" style="padding-top: 7px;">
                                                        ผู้สร้าง
                                                </div>
                                                <div class="col-md-3">
                                                        <select class="form-control custom-select text-muted">
                                                                            <option value="">ทั้งหมด</option>
                                                                            <option value="">ภาษาไทย</option>
                                                                            <option value="">ภาษาอังกฤษ</option>
                                                                            <option value="">คณิตศาสตร์</option>
                                                        </select>
                                                </div>
                                                <div class="col-md-2">
                                                      <button type="button" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                -->
                                
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper">
                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <th style="width:10%;">ปีการศึกษา</th>
                                                    <th style="width:10%;">เทอม</th>
                                                    <th style="width:55%;">รายละเอียด</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                $i = 1;
                                                if(isset($result)&&!empty($result)){
                                                    //console($result);
                                                    foreach($result as $row)
                                                    {
                                                ?>
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo $row->academic_year;?></td>
                                                    <td><?php echo $row->term_id;?></td>
                                                    <td>เริ่มตั้งแต่ <?php echo $row->begin_date;?> ถึงวันที่ <?php echo $row->end_date;?></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-alert"></i> </a>
                                                    </td>
                                                </tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>

                                    <hr>
                                    
                                </div>
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- modal -->
                <div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog modal-md" >
                                                        <div class="modal-content">
                                                            <div class="modal-header alert-success">
                                                                <h4 class="modal-title"><i class="fa fa-file-o"></i> เพิ่มข้อมูลวิชา</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post" action="cus_order_add.php" >
                                                                    <div class="row">
                                                                        <div class="col-md-2 text-success" style="padding-top: 7px;">
                                                                                ชื่อวิชา
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                                <input type="text" class="form-control" placeholder="กรอกชื่อวิชา" aria-describedby="search-txt">        
                                                                        </div>
                                                                    </div>
                                                                    <div style="margin-top:21px;"></div> 
                                                                    <div class="text-right m-b-10">
                                                                        <button type="button" class="btn btn-danger waves-effect waves-light alert-primary">ยกเลิก</button>
                                                                        <button type="button" class="btn btn-success waves-effect waves-light alert-success">บันทึก</button>
                                                                    </div>
                                                                </form>    
                                                            </div>
                                                                
                                                        </div>
                                                    </div>
                </div>
                <!-- modal -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <script
  src="https://code.jquery.com/jquery-3.4.1.js"
  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
  crossorigin="anonymous"></script>
        <script>
        

        $("#searchBtn").click(function(){
            category = document.getElementById("category_list").value;
            $.ajax({
                type: 'POST',
                url: 'load_category',
                data: 'category='+category,
                success: function(result) {   
                    $("#load_content").html(result);
                }
            });
        });
        </script>