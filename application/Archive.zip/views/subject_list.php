                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                   <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">

                            <div class="card-body">
                                <div class="text-right m-b-10">
                                        <a href="subjectCreate"><button class="btn btn-success" type="button"> <span><i class="fa fa-file-o"></i>  เพิ่มวิชา</span> </button></a>
                                </div>
                                
                                <hr class="m-t-0 m-b-20">
                                
                                <div class="row m-b-15">
                                        <div class="col-md-12 align-self-right">
                                            <div class="row">
                                                 <?php 
                                                 //console($personnelGroup);

                                                 ?>
                                                <div class="col-md-1 text-success" style="padding-top: 7px;">
                                                    กลุ่มสาระ
                                                </div>
                                                <div class="col-md-2" id="subjectGroup_div">
                                                        <select class="form-control custom-select text-muted" id="subjectGroupSec" name="subjectGroupSec">
                                                                            <option value="0">ทั้งหมด</option>
                                                                            <?php 
                                                                            if(isset($subjectGroupList)&&!empty($subjectGroupList)){
                                                                                foreach($subjectGroupList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                            ?>
                                                        </select>
                                                </div>
                                                                               
                                                <div class="offset-md-1 col-md-1 text-success" style="padding-top: 7px;">
                                                    ระดับชั้น
                                                </div>
                                                <div class="col-md-3" id="subjectList_div">
                                                        <select class="form-control custom-select text-muted" id="subEducationSec" name="subEducationSec">
                                                                            <option value="0">ทั้งหมด</option>
                                                                            <?php 
                                                                            if(isset($educationSubList)&&!empty($educationSubList)){
                                                                                foreach($educationSubList as $row){
                                                                            ?> 
                                                                            <option value="<?php echo $row->id;?>"><?php echo $row->name_th;?></option>
                                                                            <?php 
                                                                                }
                                                                            }    
                                                                            ?>
                                                        </select>
                                                                
                                                </div>
                                                
                                                <!--                                
                                                <div class="offset-md-1 col-md-2">
                                                      <button type="button" class="btn btn-info d-none d-lg-block m-l-15" style="background-color:#f9a935;border:1px solid #f9a935;"><i class="fa fa-search"></i> ค้นหา</button>
                                                </div>
                                                -->
                                            </div>
                                        </div>
                                </div>
                                
                                
                                <!--second tab-->
                                <div class="table-responsive dataTables_wrapper" id="load_content">
                                        <table class="table color-table primary-table ">
                                            <thead>
                                                <tr>
                                                    <th style="width:5%;">#</th>
                                                    <th style="width:10%;">รหัสวิชา</th>
                                                    <th style="width:20%;">ชื่อวิชา</th>
                                                    <!--<th style="width:15%;">ประเภท</th>-->
                                                    <th style="width:20%;">กลุ่มสาระ</th>
                                                    <th style="width:20%;">ระดับชั้น</th>
                                                    <th style="width:10%;"></th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-muted">
                                                <?php 
                                                if(isset($result)&&!empty($result)){
                                                    //console($result);
                                                    $i = 1;
                                                    foreach($result as $row){
                                                ?> 
                                                <tr>
                                                    <td><?php echo $i;?></td>
                                                    <td><?php echo $row->subject_id;?></td>
                                                    <td><?php echo $row->name_th;?></td>
                                                    <!--<td><?php echo $row->subject_type_name_th;?></td>-->
                                                    <td><?php echo $row->subject_group_name_th;?></td>
                                                    <td><?php echo $row->education_sublevel_name_th;?></td>
                                                    <td class="text-nowrap" style="font-size: 17px;">
                                                        <a href="<?php echo base_url('subject/subjectProfile/').$row->id;?>" data-toggle="tooltip" data-original-title="ดู"> <i class="fa fa-eye text-success m-r-10"></i> </a>
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-original-title="แก้ไข" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-pencil text-danger m-r-10"></i> </a>
                                                        <a href="<?php echo base_url('setting/subjectAddScore/').$row->id;?>" data-toggle="tooltip" data-original-title="ตั้งค่าคะแนน" class="img-responsive model_img" onclick="msg(1)"> <i class="fa fa-book text-purple m-r-10"></i> </a>
                                                    </td>
                                                    
                                                <tr>
                                                <?php 
                                                    $i++;
                                                    }
                                                }    
                                                ?> 
                                            </tbody>
                                        </table>    

                                    <?php 
                                    if(isset($page)&&!empty($page))
                                    { 
                                        $active_page = $page->page;
                                        $total = $page->total_page;
                                        
                                    ?>	            

                                    <div class="dataTables_paginate paging_simple_numbers" id="example23_paginate">
                                        <?php if($active_page-1>0){?>    
                                            <a class="paginate_button previous" aria-controls="example23" data-dt-idx="0" tabindex="0" id="example23_previous">ก่อนหน้า</a>
                                        <?php }?>
                                        
                                        <?php 
                                            if($active_page-2>0)
                                        {
                                        ?>     
                                            <a class="paginate_button " href="<?php echo base_url('setting/subjectList?page=').($active_page-2).'&type='.$type.'&group='.$group;?>" aria-controls="example23" data-dt-idx="2" tabindex="0"><?php echo $active_page-2;?></a>
                                        <?php
                                        } 
                                        if($active_page-1>0)
                                        {
                                        ?>     
                                            <a class="paginate_button " href="<?php echo base_url('setting/subjectList?page=').($active_page-1).'&type='.$type.'&group='.$group;?>" aria-controls="example23" data-dt-idx="3" tabindex="0"><?php echo $active_page-1;?></a>
                                        <?php 
                                        }
                                        ?>   
                                            <a class="paginate_button current" aria-controls="example23" data-dt-idx="4" tabindex="0"><?php echo $active_page;?></a>
                                        <?php 
                                            if($active_page+1<=$total)
                                        {
                                        ?>
                                            <a class="paginate_button " href="<?php echo base_url('setting/subjectList?page=').($active_page+1).'&type='.$type.'&group='.$group;?>" aria-controls="example23" data-dt-idx="5" tabindex="0"><?php echo $active_page+1;?></a>
                                        <?php 
                                        }
                                        ?>
                                        <?php 
                                            if($active_page+2<=$total)
                                        {
                                        ?>
                                            <a class="paginate_button " href="<?php echo base_url('setting/subjectList?page=').($active_page+2).'&type='.$type.'&group='.$group;?>" aria-controls="example23" data-dt-idx="6" tabindex="0"><?php echo $active_page+2;?></a></span>
                                        <?php 
                                        }
                                        ?>
                                            <?php if($active_page+1<$total){?>      
                                            <a class="paginate_button next" aria-controls="example23" data-dt-idx="7" tabindex="0" id="example23_next">ถัดไป</a>
                                        <?php }?>
                                    </div>
                                    <hr>
                                    <?php 
                                    }
                                    ?>
                                                
                                </div>
                            </div>        
                            
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>

        <script>
        $( "#subjectGroupSec").change(function() {
            a = document.getElementById("subEducationSec").value;
            b = document.getElementById("subjectGroupSec").value;
            page = <?php echo $active_page;?>;
            $.ajax({
                type: 'POST',
                url: 'subjectLoad',
                data: 'educationSub='+a+'&subjectGroup='+b+'&page='+page,
                success: function(result) { 
                    $("#load_content").html(result);
                }
            });
        });

        $( "#subEducationSec").change(function() {
            a = document.getElementById("subEducationSec").value;
            b = document.getElementById("subjectGroupSec").value;
            page = <?php echo $active_page;?>;
            $.ajax({
                type: 'POST',
                url: 'subjectLoad',
                data: 'educationSub='+a+'&subjectGroup='+b+'&page='+page,
                success: function(result) { 
                    $("#load_content").html(result);
                }
            });
        });

        
        </script>