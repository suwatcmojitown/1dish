<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Student extends MY_Controller {

    function __construct() {
		parent::__construct();

		if(!isset($this->session->userdata['login_id'])){
			redirect('login', 'refresh');
		}

		$this->load->model('student_model');
		$this->load->model('setting_model');
	}
	
	//--------------------------- Student ----------------------------//

    public function editProfile($student_id){
		
		$result_datamenu['cat_menu'] 		= 'student';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า';
		$result_datamenu['subcat_menu'] 	= 'editProfile';
		$result_datamenu['subcat_menu_th'] 	= 'แก้ไขประวัติส่วนตัว';
		$result_datamenu['active'] 			= 'student-profile';
		$result_datamenu['sub_active'] 		= '';

		$temp_academicYearNow = $this->setting_model->getAcademicYearNow();
		
		$data['academicYearNow'] = $temp_academicYearNow->academic_year;
		$data['term_id'] = $temp_academicYearNow->term_id;

		$academicYearNow = $temp_academicYearNow->academic_year;;
		$term_id = $temp_academicYearNow->term_id;

		$data_menu['data_menu'] = $result_datamenu;
		$data['student_id'] = $student_id;

		$result = $this->student_model->getStudentProfile($academicYearNow,$term_id,$student_id);
		$data['profile'] = $result[0];

		//console($data['profile']);

		$parentContactPoint = $this->student_model->getParentContactPoint($student_id);
		$data['parentContactPoint'] = $parentContactPoint;
		
		$point = $this->student_model->getBehaviorPoint($student_id);
		$data['point'] = $point;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'student/studentProfile_profile_edit',$data, true);
		$this->master_layout();
	}

	public function editProfile_load(){
		
		$student_id = $_POST['student_id'];

		$result_datamenu['cat_menu'] 		= 'student';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า';
		$result_datamenu['subcat_menu'] 	= 'editProfile';
		$result_datamenu['subcat_menu_th'] 	= 'แก้ไขประวัติส่วนตัว';

		$data_menu['data_menu'] = $result_datamenu;
		$data['student_id'] = $student_id;

		$temp_academicYearNow = $this->setting_model->getAcademicYearNow();
		
		$academicYearNow = $temp_academicYearNow->academic_year;;
		$term_id = $temp_academicYearNow->term_id;

		$result = $this->student_model->getStudentProfile($academicYearNow,$term_id,$student_id);
		$data['profile'] = $result[0];

		$this->load->view ('student/studentProfile_profile_edit_load',$data);
	}

	public function editParent()
	{
		$student_id = check_empty($_POST['id']);

		$parentFather = $this->student_model->getParentByRelationship($student_id,1);
		$parentMother = $this->student_model->getParentByRelationship($student_id,2);
		
		$data['parentFather'] = $parentFather;
		$data['parentMother'] = $parentMother;


		$parentContactPoint = $this->student_model->getParentContactPoint($student_id);
		$data['parentContactPoint'] = $parentContactPoint;

		$parentList = $this->student_model->getParent($student_id);
		$data['parentList'] = $parentList;

		$data['student_id'] = $student_id;

		$this->load->view ('student/studentProfile_parent_edit',$data);
		
	}

	public function searchParent()
	{
		
		$keysearch = check_empty($_POST['keysearch']);
		$type = check_empty($_POST['type']);
		$student_id = check_empty($_POST['student_id']);

		$parent = $this->student_model->searchParent($keysearch);
		$data['parent'] = $parent;
		$data['type'] = $type;
		$data['student_id'] = $student_id;

		$this->load->view ('studentProfile_parent_load',$data);
		
	}

	public function addParent()
	{
		$create_by = $this->session->userdata['login_id'];

		$data = new stdClass(); 
		$data->student_id = check_empty($_POST['student_id']);
		$data->parent_id = check_empty($_POST['parent_id']);
		$data->relationship = getRelationshipId($_POST['type']);
		
		$is_parent = check_empty($_POST['is_parent']);
		
		if($is_parent=='1')
		{
			$data->contact_point = 1;
		}else $data->contact_point = 0;

		$data->created_by = $create_by;
		//console($data);
		$this->student_model->addParent($data);

		$student_id = $_POST['student_id'];
		echo  base_url('student/editProfile/'.$student_id);
			
			
	}
	
	public function updateParent()
	{
		$data = new stdClass(); 
		$data->student_id = check_empty($_POST['student_id']);
		$data->parent_id = check_empty($_POST['parent_id']);
        $data->contact_point = 1;
		$this->student_model->updateParent($data);
		
		$student_id = $_POST['student_id'];
		echo base_url('student/editProfile/'.$student_id);
		
	}

	public function deleteParentContactPoint($parent_id,$student_id)
	{
		$data = new stdClass(); 
		$data->student_id = $student_id;
		$data->parent_id = $parent_id;
        $data->contact_point = 0;
		$this->student_model->updateParent($data);
		
		$url = base_url('student/editProfile/'.$student_id);
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
	}

	public function deleteParent($parent_id,$student_id)
	{
		$data = new stdClass(); 
		$data->student_id = $student_id;
		$data->parent_id = $parent_id;
		
		$this->student_model->deleteParent($data);
		
		$url = base_url('student/editProfile/'.$student_id);
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
	}

	public function editBehave()
	{
		
		$student_id = check_empty($_POST['student_id']);

		$point = $this->student_model->getBehaviorPoint($student_id);

		$behaviorLogPlus = $this->student_model->getBehaviorLog($student_id,'plus');
		
		$behaviorLogMinus = $this->student_model->getBehaviorLog($student_id,'minus');
		
		$data['behaviorLogPlus'] = $behaviorLogPlus;
		$data['behaviorLogMinus'] = $behaviorLogMinus;
		$data['point'] = $point;

		$data['student_id'] = $student_id;
		
		$this->load->view ('student/studentProfile_behave_edit',$data);
		
	}

	public function editScore()
	{
		
		$student_id = check_empty($_POST['student_id']);
		$data['student_id'] = $student_id;
		
		$nowScore = $this->student_model->getNowScore($student_id);
		$allScore = $this->student_model->getAllScore($student_id);
		
		$data['nowScore'] = $nowScore;
		$data['allScore'] = $allScore;

		$this->load->view ('student/studentProfile_score_edit',$data);	
	}

	public function profile($student_id)
	{
		$result_datamenu['cat_menu'] 		= 'student/list';
		$result_datamenu['cat_menu_th'] 	= 'ข้อมูล นักเรียน';
		$result_datamenu['subcat_menu'] 	= 'studentProfile';
		$result_datamenu['subcat_menu_th'] 	= 'ข้อมูล นักเรียน';
		$result_datamenu['active'] 			= 'student-profile';
		$result_datamenu['sub_active'] 		= '';

		$temp_academicYearNow = $this->setting_model->getAcademicYearNow();
		
		$data['academicYearNow'] = $temp_academicYearNow->academic_year;
		$data['term_id'] = $temp_academicYearNow->term_id;

		$academicYearNow = $temp_academicYearNow->academic_year;;
		$term_id = $temp_academicYearNow->term_id;

		$data_menu['data_menu'] = $result_datamenu;
		
		$data['student_id'] = $student_id;

		$profile = $this->student_model->getStudentProfile($academicYearNow,$term_id,$student_id);
		$data['profile'] = $profile[0];
		
		$parentFather = $this->student_model->getParentByRelationship($student_id,1);
		$parentMother = $this->student_model->getParentByRelationship($student_id,2);
		
		$data['parentFather'] = $parentFather;
		$data['parentMother'] = $parentMother;

		$parentContactPoint = $this->student_model->getParentContactPoint($student_id);
		$data['parentContactPoint'] = $parentContactPoint;
		
		
		$point = $this->student_model->getBehaviorPoint($student_id);
		$behaviorLogPlus = $this->student_model->getBehaviorLog($student_id,'plus');
		$behaviorLogMinus = $this->student_model->getBehaviorLog($student_id,'minus');
		
		$data['behaviorLogPlus'] = $behaviorLogPlus;
		$data['behaviorLogMinus'] = $behaviorLogMinus;
		$data['point'] = $point;

		/*
		console($point);
		console($behaviorLogPlus);
		console($behaviorLogMinus);
		*/

		$timesheetNormal = $this->student_model->getTimesheetInfo($student_id);
		$data['timesheetNormal'] = $timesheetNormal;
		//console($data['timesheetNormal']);
		$timesheetLate = $this->student_model->getTimesheetLate($student_id);
		$data['timesheetLate'] = $timesheetLate;

		$timesheetLeaveBefore = $this->student_model->getTimesheetLeaveBefore($student_id);
		$data['timesheetLeaveBefore'] = $timesheetLeaveBefore;

		$timesheetAbsent = $this->student_model->getTimesheetAbsent($student_id);
		$data['timesheetAbsent'] = $timesheetAbsent;
		
		
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'student/studentProfile',$data, true);
		$this->master_layout();

	}

	public function list(){

		if(isset($_GET['page'])&&!empty($_GET['page']))
		$page = $_GET['page']; else $page = 1;

		if(isset($_GET['search'])&&!empty($_GET['search']))
		$search = $_GET['search']; else $search = '';

		$data['search'] = $search;
		
		$result_datamenu['cat_menu'] 		= 'student/list';
		$result_datamenu['cat_menu_th'] 	= 'ข้อมูล นักเรียน';
		$result_datamenu['subcat_menu'] 	= 'list';
		$result_datamenu['subcat_menu_th'] 	= 'รายชื่อ นักเรียน';
		$result_datamenu['active'] 			= 'student-profile';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$academicYearNow = $this->setting_model->getAcademicYearNow();

		$data['academicYearNow'] = $academicYearNow->academic_year;
		$data['term_id'] = $academicYearNow->term_id;

		$temp_educationList = $this->setting_model->getEducationList();
		if($temp_educationList)
		{
			$educationList = $temp_educationList->body;
		}
		else $educationList = NULL;
		$temp_educationSubList = $this->setting_model->getEducationSubList();
		if($temp_educationSubList)
		{
			$educationSubList = $temp_educationSubList->body;
		}
		else $educationSubList = NULL;

		$data['educationList'] = $educationList;
		$data['educationSubList'] = $educationSubList;
	
		$result = $this->student_model->getStudentList();
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}

		//console($data);

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'student/studentList',$data, true);
		$this->master_layout();
	}

	public function listLoad()
	{
		$academic_year = $_POST['academic_year'];
		$term_id = $_POST['term_id'];
		$education = $_POST['education'];
		$educationSub = $_POST['educationSub'];
		$room = $_POST['room'];

		$result = $this->student_model->getStudentList();
		if($result)
		{
			$data['result'] = $result->body;
		}
		else
		{
			$data['result'] = NULL;
		}
		$this->load->view ('student/studentList_load',$data);
	}

	public function loadEducationSub()
	{
		$education = $_POST['education'];
		$data['academicYearNow'] = $_POST['academic_year'];
		$data['term_id'] = $_POST['term_id'];
		
		$result = $this->setting_model->getEducationSubByEducation($education);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		$this->load->view ('student/educationsubLoad',$data);
		
	}

	public function loadRoom()
	{
		$academic_year = $_POST['academic_year'];
		$term_id = $_POST['term_id'];
		$education = $_POST['education'];
		$educationSub = $_POST['educationSub'];

		$data['academicYearNow'] = $_POST['academic_year'];
		$data['term_id'] = $_POST['term_id'];

		$result = $this->setting_model->getClassroomRoom($academic_year,$term_id,$education,$educationSub);
		//console($result);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		$this->load->view ('student/roomLoad',$data);
		
	}
}
