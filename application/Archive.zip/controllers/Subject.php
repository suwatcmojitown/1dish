<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Subject extends MY_Controller {

    function __construct() {
		parent::__construct();

		if(!isset($this->session->userdata['login_id'])){
			redirect('login', 'refresh');
		}

		$this->load->model('subject_model');
		$this->load->model('setting_model');
		$this->load->model('classroom_model');
	}
	
	//--------------------------- AcademicYear ----------------------------//

    public function subjectProfile($subject_id){
		
		$result_datamenu['cat_menu'] 		= 'subject/list';
		$result_datamenu['cat_menu_th'] 	= 'ข้อมูล วิชา';
		$result_datamenu['subcat_menu'] 	= 'subjectProfile';
		$result_datamenu['subcat_menu_th'] 	= 'ข้อมูล วิชา';
		$result_datamenu['active'] 			= 'subject-profile';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;
		$data['subject_id'] = $subject_id;

		$result = $this->subject_model->getSubjectProfile($subject_id);
		$data['profile'] = $result[0];

		$result = $this->subject_model->getSubjectOwner($subject_id);
		$data['subjectOwner'] = $result;

		$personnelList = $this->setting_model->getPersonnelList();
		$data['personnelList'] = $personnelList->body;

		$subjectProfile = $this->setting_model->getSubjectConfig($subject_id);
		$data['subjectProfile'] = $subjectProfile;


		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'subject/subjectProfile',$data, true);
		$this->master_layout();
	}

	public function addPersonnel()
	{
		$subject_id = check_empty($_POST['subject_id']);
		$personnel_id = check_empty($_POST['personnel_id']);

		$data = new stdClass(); 
		$data->personnel_id = $personnel_id;
		$data->subject_id = $subject_id;

		$student = $this->subject_model->addPersonnel($data);	

		$url = $_SERVER['HTTP_REFERER'];
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
	}

	public function delPersonnel()
	{
		$subject_id = check_empty($_GET['subject_id']);
		$personnel_id = check_empty($_GET['personnel_id']);

		$data = new stdClass(); 
		$data->personnel_id = $personnel_id;
		$data->subject_id = $subject_id;
		
		$student = $this->subject_model->delPersonnel($data);	

		$url = $_SERVER['HTTP_REFERER'];
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
	}

	public function list(){

		if(isset($_GET['page'])&&!empty($_GET['page']))
		$page = $_GET['page']; else $page = 1;

		if(isset($_GET['type'])&&!empty($_GET['type']))
		$type = $_GET['type']; else $type = 0;

		if(isset($_GET['group'])&&!empty($_GET['group']))
		$group = $_GET['group']; else $group = 0;

		$data['type'] = $type;
		$data['group'] = $group;

		$result_datamenu['cat_menu'] 		= 'subject/list';
		$result_datamenu['cat_menu_th'] 	= 'ข้อมูล วิชา';
		$result_datamenu['subcat_menu'] 	= 'list';
		$result_datamenu['subcat_menu_th'] 	= 'รายชื่อ วิชา';
		$result_datamenu['active'] 			= 'subject-profile';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$subjectType = $this->setting_model->getSubjectTypeList();
		$subjectGroup = $this->setting_model->getSubjectGroupList();

		$data['subjectTypeList'] = $subjectType;
		$data['subjectGroupList'] = $subjectGroup;

		$temp_educationSubList = $this->setting_model->getEducationSubList();
		if($temp_educationSubList)
		{
			$educationSubList = $temp_educationSubList->body;
		}
		else $educationSubList = NULL;

		$data['educationSubList'] = $educationSubList;

		$result = $this->setting_model->getSubjectList($group,$type,$page);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
 
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'subject/subjectList',$data, true);
		$this->master_layout();
	}

	public function listLoad()
	{
		$subjectType = 0;//$_POST['subjectType'];
		$subjectGroup = $_POST['subjectGroup'];
		$educationSub = $_POST['educationSub'];
		$page = $_POST['page'];

		
		$result = $this->setting_model->getSubjectList($subjectGroup,$subjectType,$page);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		
		$this->load->view ('subject/subjectLoad',$data);
		
	}

	public function addScore($subject_id=NULL,$classroom_id=NULL){
		
		$result_datamenu['cat_menu'] 		= 'subject/list';
		$result_datamenu['cat_menu_th'] 	= 'ข้อมูล วิชา';
		$result_datamenu['subcat_menu'] 	= 'list';
		$result_datamenu['subcat_menu_th'] 	= 'รายชื่อ วิชา';
		$result_datamenu['active'] 			= 'subject-profile';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$result = $this->subject_model->getSubjectProfile($subject_id);
		$data['profile'] = $result[0];

		$result = $this->subject_model->getSubjectOwner($subject_id);
		$data['subjectOwner'] = $result;

		/*
		$result = $this->personnel_model->getPersonnelProfile($personnel_id);
		$data['profile'] = $result[0];

		
		$studentList = $this->classroom_model->getStudentList($academicYearNow,$classroom_id,$term_id);
		$data['studentList'] = $studentList;
		*/

		$temp_academicYearNow = $this->setting_model->getAcademicYearNow();
		$academicYearNow = $temp_academicYearNow->academic_year;
		$term_id = $temp_academicYearNow->term_id;
		$data['academicYearNow'] = $academicYearNow;
		$data['term_id'] = $term_id;
		
		$result = $this->classroom_model->getClassroomProfile($academicYearNow,$classroom_id);
		$data['classroom_profile'] = $result[0];

		$studentList = $this->subject_model->getScoreByClassroom($academicYearNow,$classroom_id,$subject_id);
		$data['studentList'] = $studentList;

		//console($studentList);
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'subject/subject_classroom',$data, true);
		$this->master_layout();
	}
	
	
}
