<?php if (!defined('BASEPATH')) exit('No direct script access allowed');



class Timesheet extends MY_Controller {

    function __construct() {
		parent::__construct();

		if(!isset($this->session->userdata['login_id'])){
            redirect('login');
		}

		//date_default_timezone_set("Asia/Bangkok");

		$this->load->model('classroom_model');
		$this->load->model('setting_model');
		$this->load->model('timesheet_model');
	}
	
	//--------------------------- AcademicYear ----------------------------//

	public function list()
	{
		$result_datamenu['cat_menu'] 		= 'timesheet/list';
		$result_datamenu['cat_menu_th'] 	= 'ข้อมูล เวลาเข้า-ออก';
		$result_datamenu['subcat_menu'] 	= 'list';
		$result_datamenu['subcat_menu_th'] 	= '<i class="fa fa-briefcase"></i> รายการ เวลาเข้า-ออก';
		$result_datamenu['active'] 			= 'timesheet';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$temp_academicYearNow = $this->setting_model->getAcademicYearNow();
		$academicYearNow = $temp_academicYearNow->academic_year;
		$term_id = $temp_academicYearNow->term_id;
		$data['academicYearNow'] = $academicYearNow;
		$data['term_id'] = $term_id;

		$academicYearList = $this->setting_model->getAcademicYearList();
		$temp_educationList = $this->setting_model->getEducationList();
		if($temp_educationList)
		{
			$educationList = $temp_educationList->body;
		}
		else $educationList = NULL;
		$temp_educationSubList = $this->setting_model->getEducationSubList();
		if($temp_educationSubList)
		{
			$educationSubList = $temp_educationSubList->body;
		}
		else $educationSubList = NULL;

		$data['educationList'] = $educationList;
		$data['educationSubList'] = $educationSubList;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'timesheet/timesheetList',$data, true);
		$this->master_layout();
		
	}

	public function listLoad()
	{
		date_default_timezone_set("Asia/Bangkok");

		$educationSub = $_POST['educationSub'];
		$room = $_POST['room'];
		$date = $_POST['date'];
		
		if(isset($_POST['date'])&&!empty($_POST['date']))
		{
			if($date=='now')
			{
				$result = $this->timesheet_model->getTimesheetList($educationSub,$room,date('Y-m-d'));
			}
			else
			{
				$result = $this->timesheet_model->getTimesheetList($educationSub,$room,$date);
			}
		}
		else $result = $this->timesheet_model->getTimesheetList($educationSub,$room);
		//console($result);
		if($result)
		{
			$data['result'] = $result;
		}
		else
		{
			$data['result'] = NULL;
		}

		$origDate = $date;
		
		$newDate = date("d-m-Y", strtotime($origDate));
		
		$data['active_date'] = $newDate;
		$this->load->view ('timesheet/timesheetList_load',$data);
	}

	public function loadEducationSub()
	{
		$education = $_POST['education'];
		$data['academicYearNow'] = $_POST['academic_year'];
		$data['term_id'] = $_POST['term_id'];
		
		$result = $this->setting_model->getEducationSubByEducation($education);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		$this->load->view ('timesheet/educationsubLoad',$data);
		
	}

	public function loadRoom()
	{
		$academic_year = $_POST['academic_year'];
		$term_id = $_POST['term_id'];
		$education = $_POST['education'];
		$educationSub = $_POST['educationSub'];

		$data['academicYearNow'] = $_POST['academic_year'];
		$data['term_id'] = $_POST['term_id'];

		$result = $this->setting_model->getClassroomRoom($academic_year,$term_id,$education,$educationSub);
		
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		$this->load->view ('timesheet/roomLoad',$data);
		
	}
 
	public function deleteTimesheet()
	{
		date_default_timezone_set("Asia/Bangkok");

		$educationSub = $_POST['educationSub'];
		$room = $_POST['room'];
		$date = $_POST['date'];
		$student_id = $_POST['student_id'];
		
		if(isset($_POST['date'])&&!empty($_POST['date']))
		{
			if($date=='now')
			{
				$this->timesheet_model->deleteTimesheet($student_id,date('Y-m-d'));
				$result = $this->timesheet_model->getTimesheetList($educationSub,$room,date('Y-m-d'));
			}
			else
			{
				$this->timesheet_model->deleteTimesheet($student_id,$date);
				$result = $this->timesheet_model->getTimesheetList($educationSub,$room,$date);
			}
		}
		else $result = $this->timesheet_model->getTimesheetList($educationSub,$room);

		if($result)
		{
			$data['result'] = $result;
		}
		else
		{
			$data['result'] = NULL;
		}

		

		$origDate = $date;
		
		$newDate = date("d-m-Y", strtotime($origDate));
		
		$data['active_date'] = $newDate;
		$this->load->view ('timesheet/timesheetList_load',$data);
	}
	
}
