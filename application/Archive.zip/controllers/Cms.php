<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Cms extends MY_Controller {

    function __construct() {
		parent::__construct();
		$this->load->model('cms_model');
    }

    public function index()
	{
		
		$data_menu['data_menu'] = '';
		$data['data'] = '';
		
			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms_home',$data, true);
			$this->cms_layout();
	}
// ---------------------------------------------- category ---------------------------------------
//|																								 |
// ---------------------------------------------- category ---------------------------------------	
	public function list_category($category='all')
	{
		$slug_name = 'category';
		
		if(isset($_GET['page'])&&!empty($_GET['page'])) $page = $_GET['page'];
		else $page = 1;

		if($category!='all')
		{
			$temp_name = $this->cms_model->getCategoryBySlug($category);
			$cat_id = $temp_name[0]['cat_id'];
		}
		else 
		{
			$cat_id = '0';
		}


		$result_datamenu['active'] 	= $slug_name;
		$data_menu['data_menu'] = $result_datamenu;

		$total = $this->cms_model->getTotalCategory($cat_id);
		
		$limit = 10;
		$offset = ($page-1)*$limit;
		$total_page = ceil($total/$limit);

		$data['data']['active_page'] = $page;
		$data['data']['total_page']  = $total_page;
		$data['data']['type'] = $slug_name;
		
		$temp_result = $this->cms_model->getCategoryList($cat_id,$limit,$offset);

		$cat_list = $this->cms_model->getCatList();
		
		if(isset($temp_result[0]['cat_id'])&&!empty($temp_result[0]['cat_id']))
		{
			$data['data']['cat_list'] = $cat_list;
			$data['data']['result'] = $temp_result;
			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms/category_list',$data, true);
			$this->cms_layout();
		}	
	}

	public function create_category()
	{
		$data_menu['data_menu'] = '';
		$data['data'] = '';
		
			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms/category_create',$data, true);
			$this->cms_layout();
	}

	public function add_category()
	{
		if(isset($_POST)&&!empty($_POST))
		{
			$name = check_empty($_POST['name']);
			$name_en = check_empty($_POST['name_en']);
			$slug = check_empty($_POST['slug']);
			$description = check_empty($_POST['description']);
			$description_en = check_empty($_POST['description_en']);
			$status = check_empty($_POST['status']);
			$code_color = check_empty($_POST['code_color']);
			$is_main = check_empty($_POST['is_main']);
			
			if(isset($_FILES)&&!empty($_FILES))
			{
				$thumbnail = upload_pic($_FILES,'thumbnail','images');
			}
			else $thumbnail = NULL;
			
			$temp_data_menu = $this->cms_model->createCategory($name,$name_en,$slug,$description,$description_en,$status,$code_color,$is_main,$thumbnail);
			
	
		}
		else
		{
			echo "no data";
		}
	}

	public function load_category()
	{
		$slug_name = 'category';
		
		$category = $_POST['category'];
		$page = 1;

		if($category!='all')
		{
			$temp_name = $this->cms_model->getCategoryBySlug($category);
			$cat_id = $temp_name[0]['cat_id'];
		}
		else 
		{
			$cat_id = '0';
		}
	
		$total = $this->cms_model->getTotalCategory($cat_id);
		
		$limit = 10;
		$offset = ($page-1)*$limit;
		$total_page = ceil($total/$limit);

		$data['data']['active_page'] = $page;
		$data['data']['total_page']  = $total_page;
		$data['data']['type'] = $slug_name;
		
		$temp_result = $this->cms_model->getCategoryList($cat_id,$limit,$offset);

		if(isset($temp_result[0]['cat_id'])&&!empty($temp_result[0]['cat_id']))
		{
			$data['data']['result'] = $temp_result;
			$this->load->view ('cms/category_load',$data);
		}
		
	}
// ---------------------------------------------- contact ---------------------------------------
//|																								 |
// ---------------------------------------------- contact ---------------------------------------	
	public function list_contact($category='all')
	{
		$slug_name = 'contact';
		$limit = 10;
		$offset = 0;
		
		if($category!='all')
		{
			$temp_name = $this->cms_model->getCategoryBySlug($category);
			$cat_id = $temp_name[0]['cat_id'];
		}
		else 
		{
			$cat_id = '0';
		}
	
		$result_datamenu['active'] 	= $slug_name;
		$data_menu['data_menu'] = $result_datamenu;

		$temp_result = $this->cms_model->getContactList($cat_id,$limit,$offset);

		if(isset($temp_result[0]['contact_id'])&&!empty($temp_result[0]['contact_id']))
		{
			$data['data']['result'] = $temp_result;
			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms/contact_list',$data, true);
			$this->cms_layout();
		}	
	}

	public function create_contact()
	{
			$cat_list = $this->cms_model->getSubcatList();
			$data_menu['data_menu'] = '';
			$data['cat_list'] = $cat_list;

			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms/contact_create',$data, true);
			$this->cms_layout();
	}

	public function add_contact()
	{
		if(isset($_POST)&&!empty($_POST))
		{
			$category = check_empty($_POST['category']);
			$address = check_empty($_POST['address']);
			$address_en = check_empty($_POST['address_en']);
			$phone = check_empty($_POST['phone']);
			$email = check_empty($_POST['email']);
			$facebook = check_empty($_POST['facebook']);
			$description = check_empty($_POST['description']);
			$description_en = check_empty($_POST['description_en']);
			$status = check_empty($_POST['status']);
			
			$temp_data_menu = $this->cms_model->createContact($category,$address,$address_en,$phone,$email,$facebook,$description,$description_en,$status);
			
	
		}
		else
		{
			echo "no data";
		}
	}
// ---------------------------------------------- Category Template ---------------------------------------
//|																										   |
// ---------------------------------------------- Category Template ---------------------------------------	
	public function list_category_template($category='all')
	{
		$slug_name = 'category_template';
		$limit = 10;
		$offset = 0;
		
		if($category!='all')
		{
			$temp_name = $this->cms_model->getCategoryBySlug($category);
			$cat_id = $temp_name[0]['cat_id'];
		}
		else 
		{
			$cat_id = '0';
		}

		$result_datamenu['active'] 	= $slug_name;
		$data_menu['data_menu'] = $result_datamenu;

		$temp_result = $this->cms_model->getCategoryTemplateList($cat_id,$limit,$offset);

		if(isset($temp_result[0]['category_template_id'])&&!empty($temp_result[0]['category_template_id']))
		{
			$data['data']['result'] = $temp_result;
			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms/category_template_list',$data, true);
			$this->cms_layout();
		}	
	}

	public function create_category_template()
	{
			$cat_list = $this->cms_model->getSubcatList();
			$data_menu['data_menu'] = '';
			$data['cat_list'] = $cat_list;

			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms/category_template_create',$data, true);
			$this->cms_layout();
	}

	public function add_category_template()
	{
		if(isset($_POST)&&!empty($_POST))
		{
			
			$category = check_empty($_POST['category']);
			$description = check_empty($_POST['description']);
			$description_en = check_empty($_POST['description_en']);
			$code_color = check_empty($_POST['code_color']);
			$tools = check_empty($_POST['tools']);
			$tools_en = check_empty($_POST['tools_en']);
			$service = check_empty($_POST['service']);
			$service_en = check_empty($_POST['service_en']);
			$rate = check_empty($_POST['rate']);
			$rate_en = check_empty($_POST['rate_en']);
			$status = check_empty($_POST['status']);
			
			if(isset($_FILES)&&!empty($_FILES))
			{
				$thumbnail = upload_pic($_FILES,'thumbnail','images');
			}
			else $thumbnail = NULL;
			
			$temp_data_menu = $this->cms_model->createCategoryTemplate(
				$category,$description,$description_en,$code_color,$tools,$tools_en,$service,$service_en,$rate,$rate_en,$status,$thumbnail
			);
		}
		else
		{
			echo "no data";
		}
	}
// ---------------------------------------------- Highlight ---------------------------------------
//|																								   |
// ---------------------------------------------- Highlight ---------------------------------------		
	
	public function list_highlight()
	{
		$slug_name = 'highlight';
		
		$result_datamenu['active'] 	= $slug_name;
		$data_menu['data_menu'] = $result_datamenu;

		$temp_result = $this->cms_model->getHighlightList();

		if(isset($temp_result[0]['highlight_id'])&&!empty($temp_result[0]['highlight_id']))
		{
			$data['data']['result'] = $temp_result;
			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms/highlight_list',$data, true);
			$this->cms_layout();
		}	
	}

	public function create_highlight()
	{
			$cat_list = $this->cms_model->getSubcatList();
			$data_menu['data_menu'] = '';
			$data['cat_list'] = $cat_list;

			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms/highlight_create',$data, true);
			$this->cms_layout();
	}

	public function add_highlight()
	{
		if(isset($_POST)&&!empty($_POST))
		{
			$title = check_empty($_POST['title']);
			$title_en = check_empty($_POST['title_en']);
			$description = check_empty($_POST['description']);
			$description_en = check_empty($_POST['description_en']);
			$link = check_empty($_POST['link']);
			$status = check_empty($_POST['status']);
			$is_service = check_empty($_POST['is_service']);
			
			if(isset($_FILES)&&!empty($_FILES))
			{
				$thumbnail = upload_pic($_FILES,'thumbnail','images');
			}
			else $thumbnail = NULL;
			
			$temp_data_menu = $this->cms_model->createHighlight(
				$title,$title_en,$description,$description_en,$link,$status,$thumbnail,$is_service	
			);
		}
		else
		{
			echo "no data";
		}
	}
// ---------------------------------------------- Personnel ---------------------------------------
//|																								   |
// ---------------------------------------------- Personnel ---------------------------------------	
	public function list_personnel($category='all')
	{
		$slug_name = 'personnel';
		
		if(isset($_GET['page'])&&!empty($_GET['page'])) $page = $_GET['page'];
		else $page = 1;

		if($category!='all')
		{
			$temp_name = $this->cms_model->getCategoryBySlug($category);
			$cat_id = $temp_name[0]['cat_id'];
		}
		else 
		{
			$cat_id = '0';
		}


		$result_datamenu['active'] 	= $slug_name;
		$data_menu['data_menu'] = $result_datamenu;

		$total = $this->cms_model->getTotalPersonnel($cat_id);
		
		$limit = 10;
		$offset = ($page-1)*$limit;
		$total_page = ceil($total/$limit);

		$data['data']['active_page'] = $page;
		$data['data']['total_page']  = $total_page;
		$data['data']['type'] = $slug_name;
		
		$temp_result = $this->cms_model->getPersonnelList($cat_id,$limit,$offset);

		$cat_list = $this->cms_model->getSubcatList();
		
		if(isset($temp_result[0]['personnel_id'])&&!empty($temp_result[0]['personnel_id']))
		{
			$data['data']['cat_list'] = $cat_list;
			$data['data']['result'] = $temp_result;
			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms/personnel_list',$data, true);
			$this->cms_layout();
		}		
	}

	public function load_personnel()
	{
		$slug_name = 'personnel';
		
		$category = $_POST['category'];
		$page = 1;

		if($category!='all')
		{
			$temp_name = $this->cms_model->getCategoryBySlug($category);
			$cat_id = $temp_name[0]['cat_id'];
		}
		else 
		{
			$cat_id = '0';
		}
	
		$total = $this->cms_model->getTotalPersonnel($cat_id);
		
		$limit = 10;
		$offset = ($page-1)*$limit;
		$total_page = ceil($total/$limit);

		$data['data']['active_page'] = $page;
		$data['data']['total_page']  = $total_page;
		$data['data']['type'] = $slug_name;
		
		$temp_result = $this->cms_model->getPersonnelList($cat_id,$limit,$offset);

		if(isset($temp_result[0]['personnel_id'])&&!empty($temp_result[0]['personnel_id']))
		{
			$data['data']['result'] = $temp_result;
			$this->load->view ('cms/personnel_load',$data);
		}
		
	}

	public function create_personnel()
	{
			$cat_list = $this->cms_model->getSubcatList();
			$data_menu['data_menu'] = '';
			$data['cat_list'] = $cat_list;

			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms/personnel_create',$data, true);
			$this->cms_layout();
	}

	public function add_personnel()
	{
		if(isset($_POST)&&!empty($_POST))
		{
			$name = check_empty($_POST['name']);
			$rank = check_empty($_POST['rank']);
			$category = check_empty($_POST['category']);
			$rank_order = check_empty($_POST['rank_order']);
			$status = check_empty($_POST['status']);
			
			if(isset($_FILES)&&!empty($_FILES))
			{
				$thumbnail = upload_pic($_FILES,'thumbnail','images');
			}
			else $thumbnail = NULL;
			
			$temp_data_menu = $this->cms_model->createPersonnel(
				$name,$rank,$category,$rank_order,$status,$thumbnail
			);
			
		}
		else
		{
			echo "no data";
		}
	}
// ---------------------------------------------- Notice ---------------------------------------
//|																								|
// ---------------------------------------------- Notice ---------------------------------------	
	public function list_notice($category='all')
	{
		$slug_name = 'notice';
		
		if(isset($_GET['page'])&&!empty($_GET['page'])) $page = $_GET['page'];
		else $page = 1;

		if($category!='all')
		{
			$temp_name = $this->cms_model->getCategoryBySlug($category);
			$cat_id = $temp_name[0]['cat_id'];
		}
		else 
		{
			$cat_id = '0';
		}


		$result_datamenu['active'] 	= $slug_name;
		$data_menu['data_menu'] = $result_datamenu;

		$total = $this->cms_model->getTotalNotice($cat_id);
		
		$limit = 10;
		$offset = ($page-1)*$limit;
		$total_page = ceil($total/$limit);

		$data['data']['active_page'] = $page;
		$data['data']['total_page']  = $total_page;
		$data['data']['type'] = $slug_name;
		
		$temp_result = $this->cms_model->getNoticeList($cat_id,$limit,$offset);

		$cat_list = $this->cms_model->getSubcatList();
		if($cat_id == 0)
		{
			$doc_list = NULL;
			$doctype_list = NULL;
			$department_list = NULL;	
		}
		else
		{
			$doc_id = 0;
			$type_id = 0;
			
			$doc_list = $this->cms_model->getDocList();
			$doctype_list = $this->cms_model->getDocTypeList($doc_id);
			$department_list = $this->cms_model->getDepartmentList($type_id);
		}
		
		
		if(isset($temp_result[0]['notice_id'])&&!empty($temp_result[0]['notice_id']))
		{
			$data['data']['cat_list'] = $cat_list;
			$data['data']['doc_list'] = $doc_list;
			$data['data']['doctype_list'] = $doctype_list;
			$data['data']['department_list'] = $department_list;
			$data['data']['result'] = $temp_result;
			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms/notice_list',$data, true);
			$this->cms_layout();
		}		
	}

	public function load_doclist()
	{
		
		$doc_list = $this->cms_model->getDocList();

		if(isset($doc_list[0]['doc_id'])&&!empty($doc_list[0]['doc_id']))
		{
			$data['data']['doc_list'] = $doc_list;
			$this->load->view ('cms/notice_doclist_load',$data);
		}
	}

	public function load_doctypelist()
	{
		$doc_id = $_POST['doc_id'];

		$doc_list = $this->cms_model->getDocTypeList($doc_id);
		if(isset($doc_list[0]['type_id'])&&!empty($doc_list[0]['type_id']))
		{
			$data['data']['doctype_list'] = $doc_list;
			$this->load->view ('cms/notice_doctypelist_load',$data);
		}
	}

	public function load_departmentlist()
	{
		$type_id = $_POST['type_id'];

		$doc_list = $this->cms_model->getDepartmentList($type_id);
		if(isset($doc_list[0]['department_id'])&&!empty($doc_list[0]['department_id']))
		{
			$data['data']['department_list'] = $doc_list;
			$this->load->view ('cms/notice_departmentlist_load',$data);
		}
	}

	public function create_notice()
	{
			$cat_id = 0;
			$cat_list = $this->cms_model->getSubcatList();
			if($cat_id == 0)
			{
				$doc_list = NULL;
				$doctype_list = NULL;
				$department_list = NULL;	
			}
			else
			{
				$doc_id = 0;
				$type_id = 0;
				
				$doc_list = $this->cms_model->getDocList();
				$doctype_list = $this->cms_model->getDocTypeList($doc_id);
				$department_list = $this->cms_model->getDepartmentList($type_id);
			}

			$data_menu['data_menu'] = '';
			$data['cat_list'] = $cat_list;

			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms/notice_create',$data, true);
			$this->cms_layout();
	}

	public function load_doc_create()
	{
		$doc_list = $this->cms_model->getDocList();
		if(isset($doc_list[0]['doc_id'])&&!empty($doc_list[0]['doc_id']))
		{
			$data['data']['doc_list'] = $doc_list;
			$this->load->view ('cms/notice_doclist_create',$data);
		}
	}

	public function load_doctype_create()
	{
		$doc_id = $_POST['doc_id'];
		if($doc_id!=0)
		{
			$is_type = $this->cms_model->istype_doc($doc_id);
			if($is_type)
			{
				$doc_list = $this->cms_model->getDocTypeList($doc_id);
			}
			else $doc_list = NULL;
			
		}
		else $doc_list = NULL;
		if(isset($doc_list[0]['type_id'])&&!empty($doc_list[0]['type_id']))
		{
			$data['data']['doctype_list'] = $doc_list;
			$this->load->view ('cms/notice_doctypelist_create',$data);
		}
	}

	public function load_department_create()
	{
		$type_id = $_POST['doc_id'];
		if($type_id!=0)
		{
			$is_type = $this->cms_model->istype_department($type_id);
			if($is_type)
			{
				$department_list = $this->cms_model->getDepartmentList($type_id);
			}
			else $department_list = NULL;
			
		}
		else $department_list = NULL;
		if(isset($department_list[0]['department_id'])&&!empty($department_list[0]['department_id']))
		{
			$data['data']['department_list'] = $department_list;
			$this->load->view ('cms/notice_departmentlist_create',$data);
		}
	}

	public function add_notice()
	{
		if(isset($_POST)&&!empty($_POST))
		{
			$cat_id = check_empty($_POST['category']);

			if(isset($_POST['doc_list'])&&!empty($_POST['doc_list']))
			{
				$doc_id = check_empty($_POST['doc_list']);
			}else $doc_id = NULL;

			if(isset($_POST['doctype_list'])&&!empty($_POST['doctype_list']))
			{
				$type_id = check_empty($_POST['doctype_list']);
			}else $type_id = NULL;

			if(isset($_POST['department_id'])&&!empty($_POST['department_id']))
			{
				$department_id = check_empty($_POST['department_id']);
			}else $department_id = NULL;

			$title = check_empty($_POST['name']);
			$title_en = check_empty($_POST['name_en']);
			$status = check_empty($_POST['status']);

			if(isset($_FILES['doc']['name'])&&!empty($_FILES['doc']['name']))
			{
				$doc = upload_pic($_FILES,'doc','doc');
			}
			else $doc = NULL;
			
			$temp_data_menu = $this->cms_model->createNotice(
				$title,$title_en,$doc,$cat_id,$doc_id,$type_id,$department_id,$status
			);
			
		}
		else
		{
			echo "no data";
		}
	}
	
	public function add_document()
	{
		if(isset($_POST)&&!empty($_POST))
		{
			$title = check_empty($_POST['title']);
			$slug = check_empty($_POST['slug']);
			$cat_id = check_empty($_POST['cat_id']);
			$is_type = check_empty($_POST['is_type']);
			$status = check_empty($_POST['status']);
			
			$this->cms_model->createDocument(
				$title,$slug,$cat_id,$is_type,$status
			);
			
		}
	}

	public function add_doctype()
	{
		if(isset($_POST)&&!empty($_POST))
		{
			$title = check_empty($_POST['title']);
			$slug = check_empty($_POST['slug']);
			$doc_id = check_empty($_POST['doc_id']);
			$is_department = check_empty($_POST['is_department']);
			$status = check_empty($_POST['status']);
			
			$this->cms_model->createDocType(
				$title,$slug,$doc_id,$is_department,$status
			);
		}
	}

	public function add_department()
	{
		if(isset($_POST)&&!empty($_POST))
		{
			$title = check_empty($_POST['title']);
			$slug = check_empty($_POST['slug']);
			$type_id = check_empty($_POST['type_id']);
			$status = check_empty($_POST['status']);
			
			$this->cms_model->createDepartment(
				$title,$slug,$type_id,$status
			);
		}
	}
// ---------------------------------------------- News ---------------------------------------
//|																							  |
// ---------------------------------------------- News ---------------------------------------	
	public function list_news($category='all')
	{
		$slug_name = 'news';
		
		if(isset($_GET['page'])&&!empty($_GET['page'])) $page = $_GET['page'];
		else $page = 1;

		if($category!='all')
		{
			$temp_name = $this->cms_model->getNewsTypeBySlug($category);
			$type_id = $temp_name[0]['type_id'];
		}
		else 
		{
			$type_id = '0';
		}


		$result_datamenu['active'] 	= $slug_name;
		$data_menu['data_menu'] = $result_datamenu;

		$total = $this->cms_model->getTotalNews($type_id);
		
		$limit = 10;
		$offset = ($page-1)*$limit;
		$total_page = ceil($total/$limit);

		$data['data']['active_page'] = $page;
		$data['data']['total_page']  = $total_page;
		$data['data']['type'] = $slug_name;
		
		$temp_result = $this->cms_model->getNewsList($type_id,$limit,$offset);

		$news_type_list = $this->cms_model->getNewsTypeList();
		
		if(isset($temp_result[0]['news_id'])&&!empty($temp_result[0]['news_id']))
		{
			$data['data']['news_type_list'] = $news_type_list;
			$data['data']['result'] = $temp_result;
			
			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms/news_list',$data, true);
			$this->cms_layout();
			
		}		
	}

	public function load_news()
	{
		$slug_name = 'news';
		
		$category = $_POST['category'];
		$page = 1;

		if($category!='all')
		{
			$temp_name = $this->cms_model->getNewsTypeBySlug($category);
			$type_id = $temp_name[0]['type_id'];
		}
		else 
		{
			$type_id = '0';
		}
	
		$total = $this->cms_model->getTotalNews($type_id);
		
		$limit = 10;
		$offset = ($page-1)*$limit;
		$total_page = ceil($total/$limit);

		$data['data']['active_page'] = $page;
		$data['data']['total_page']  = $total_page;
		$data['data']['type'] = $slug_name;
		
		$temp_result = $this->cms_model->getNewsList($type_id,$limit,$offset);

		if(isset($temp_result[0]['news_id'])&&!empty($temp_result[0]['news_id']))
		{
			$data['data']['result'] = $temp_result;
			$this->load->view ('cms/news_load',$data);
		}
		
	}

	public function create_news()
	{
		$data_menu['data_menu'] = '';
		
		$news_type_list = $this->cms_model->getNewsTypeList();
		$data['data']['news_type_list'] = $news_type_list;
		
		$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'cms/news_create',$data, true);
		$this->cms_layout();
	}

	public function add_news()
	{
		if(isset($_POST)&&!empty($_POST))
		{
			$name = check_empty($_POST['name']);
			$name_en = check_empty($_POST['name_en']);
			$category = check_empty($_POST['category']);
			$description = check_empty($_POST['description']);
			$description_en = check_empty($_POST['description_en']);
			if(isset($_FILES)&&!empty($_FILES))
			{
				$thumbnail = upload_pic($_FILES,'thumbnail','images');
			}
			else $thumbnail = NULL;
			$recommend = check_empty($_POST['recommend']);
			$status = check_empty($_POST['status']);
			
			$temp_data_menu = $this->cms_model->createNews(
				$name,$name_en,$category,$description,$description_en,$thumbnail,$status,$recommend
			);
			
		}
		else
		{
			echo "no data";
		}
	}
// ---------------------------------------------- Product ---------------------------------------
//|																							     |
// ---------------------------------------------- Product ---------------------------------------	
	public function list_product($category='all')
	{
		$slug_name = 'product';
		
		if(isset($_GET['page'])&&!empty($_GET['page'])) $page = $_GET['page'];
		else $page = 1;

		if($category!='all')
		{
			$temp_name = $this->cms_model->getCategoryBySlug($category);
			$cat_id = $temp_name[0]['type_id'];
		}
		else 
		{
			$cat_id = '0';
		}


		$result_datamenu['active'] 	= $slug_name;
		$data_menu['data_menu'] = $result_datamenu;

		$total = $this->cms_model->getTotalProduct($cat_id);
		
		$limit = 10;
		$offset = ($page-1)*$limit;
		$total_page = ceil($total/$limit);

		$data['data']['active_page'] = $page;
		$data['data']['total_page']  = $total_page;
		$data['data']['type'] = $slug_name;
		
		$temp_result = $this->cms_model->getProductList($cat_id,$limit,$offset);

		$cat_list = $this->cms_model->getSubcatList();
		
		if(isset($temp_result[0]['product_id'])&&!empty($temp_result[0]['product_id']))
		{
			$data['data']['cat_list'] = $cat_list;
			$data['data']['result'] = $temp_result;
			
			$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
			$this->template['content'] = $this->load->view ($this->middle = 'cms/product_list',$data, true);
			$this->cms_layout();
			
		}		
	}	

	public function create_product()
	{
		$data_menu['data_menu'] = '';
		
		$cat_list = $this->cms_model->getSubcatList();
		$data['data']['subcat_list'] = $cat_list;
		$product_type_list = $this->cms_model->getProductTypeList();
		$data['data']['product_type_list'] = $product_type_list;
		
		$this->template['menu'] = $this->load->view ($this->menu = 'cms_menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'cms/product_create',$data, true);
		$this->cms_layout();
	}

	public function load_ownerlist()
	{
		$type_id = $_POST['type_id'];

		$owner_list = $this->cms_model->getOwner($type_id);
			
		if(isset($owner_list[0]['personnel_id'])&&!empty($owner_list[0]['personnel_id']))
		{
			$data['data']['owner_list'] = $owner_list;
			$this->load->view ('cms/product_ownerlist_create',$data);
		}
	}

	public function add_product()
	{
		if(isset($_POST)&&!empty($_POST))
		{
			
			$title = check_empty($_POST['title']);
			$title_en = check_empty($_POST['title_en']);
			
			if(isset($_POST['product_type'])&&!empty($_POST['product_type']))
			{
				$product_type_id = check_empty($_POST['product_type']);
			}else $product_type_id = NULL;
			if(isset($_POST['owner'])&&!empty($_POST['owner']))
			{
				$owner = check_empty($_POST['owner']);
			}else $owner = NULL;
			
			$category = check_empty($_POST['category']);
			$description = check_empty($_POST['description']);
			$description_en = check_empty($_POST['description_en']);
			$doc_name = check_empty($_POST['doc_name']);
			
			
			
			if(isset($_FILES['thumbnail'])&&!empty($_FILES['thumbnail']))
			{
				$thumbnail = upload_pic($_FILES,'thumbnail','images');
			}
			else $thumbnail = NULL;
			
			if(isset($_FILES['doc'])&&!empty($_FILES['doc']))
			{
				$doc = upload_doc($_FILES,'doc','doc');
			}
			else $doc = NULL;
			
			$status = check_empty($_POST['status']);
			
			$temp_data_menu = $this->cms_model->createProduct(
				$title,$title_en,$product_type_id,$owner,$description,$description_en,$category,$status,$doc_name,$doc,$thumbnail
			);
			
			
		}
		else
		{
			echo "no data";
		}
	}

}
