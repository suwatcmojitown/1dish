<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FrontReview extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Review_model');
    }

    public function detail($review_id)
    {
        $review = $this->Review_model->getReviewDetail($review_id);
        if (!$review) show_404();

        $this->data['page_title'] = $review->title ?: $review->place_name;
        $this->data['review']     = $review;
        $this->data['comments']   = array(); // Phase 2
        $this->middle = 'front/review/detail';
        $this->front_layout();
    }
}
