<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Behavior extends MY_Controller {

    function __construct() {
		parent::__construct();
		
		if(!isset($this->session->userdata['login_id'])){
			redirect('login', 'refresh');
		}

		//console($this->session->userdata);
		$this->load->model('classroom_model');
		$this->load->model('setting_model');
		$this->load->model('student_model');

		$this->load->model('behavior_model');
	}
	
	//--------------------------- AcademicYear ----------------------------//

	public function createEvent()
	{
		if(isset($_GET['keysearch'])&&!empty($_GET['keysearch']))
		{
			$keysearch = check_empty($_GET['keysearch']);
		}else $keysearch = '';

		if(isset($_GET['status'])&&!empty($_GET['status']))
		{
			$alert = $_GET['status'];
			$data['alert'] = $alert;
		}	
		else $data['alert'] = '';
		
		$result_datamenu['cat_menu'] 		= 'behavior/createEvent';
		$result_datamenu['cat_menu_th'] 	= 'จัดการคะแนนพฤติกรรม';
		$result_datamenu['subcat_menu'] 	= 'list';
		$result_datamenu['subcat_menu_th'] 	= '<i class="fa fa-thumbs-o-up"></i> เพิ่ม ลด คะแนนพฤติกรรม';
		$result_datamenu['active'] 			= 'behavior';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;
		
		$temp_academicYearNow = $this->setting_model->getAcademicYearNow();
		$academicYearNow = $temp_academicYearNow->academic_year;;
		$term_id = $temp_academicYearNow->term_id;

		if($keysearch!='')$result = $this->student_model->searchStudent($academicYearNow,$term_id,$keysearch);
		else $result = null;
		
		$data['list'] = $result;
		$data['keysearch'] = $keysearch; 

		if($this->setting_model->getBehaviorList('plus')) $behaviorPlusList = $this->setting_model->getBehaviorList('plus')->body;
		if($this->setting_model->getBehaviorList('minus')) $behaviorMinusList = $this->setting_model->getBehaviorList('minus')->body;
		
		$data['behaviorPlusList'] = $behaviorPlusList;
		$data['behaviorMinusList'] = $behaviorMinusList;

		
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'behavior/createEvent',$data, true);
		$this->master_layout();
	}

	public function AddEvent()
	{
		
		$create_by = $this->session->userdata['login_id'];
		
		$data = new stdClass(); 
		$data->student_id = $_POST['student_id'];
		$data->description = $_POST['description'];
		$data->point = $_POST['point'];
		$data->title = $_POST['title'];
		$data->created_by = $create_by;

			
		$result = $this->behavior_model->addEvent($data);
		
		if($result)
		{
			$url = base_url('behavior/createEvent?status=success');
			
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}else
		{
			$url = base_url('behavior/createEvent?status=error');
			
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
	}

	
}
