<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FrontUser extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Place_model');
        $this->load->model('Review_model');
        $this->load->model('User_model');
        $this->load->model('Influencer_model');
        $this->load->model('Lookup_model');
    }
}
