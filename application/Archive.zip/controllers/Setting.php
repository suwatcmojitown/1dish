<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Setting extends MY_Controller {

    function __construct() {

		parent::__construct();

		if(!isset($this->session->userdata['login_id'])){
			redirect('login', 'refresh');
		}

		$this->load->model('setting_model');
		$this->load->model('personnel_model');
		$this->load->model('parent_model');
		$this->load->model('student_model');
	}
	
	//--------------------------- AcademicYear ----------------------------//

    public function academicYearList(){
		
		$result_datamenu['cat_menu'] 		= 'setting/academicYearList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า เทอม / ปีการศึกษา';
		$result_datamenu['subcat_menu'] 	= 'academicyearList';
		$result_datamenu['subcat_menu_th'] 	= 'รายการปีการศึกษา';
		$result_datamenu['active'] 			= 'academicyear';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$result = $this->setting_model->getAllAcademicYearList();
		$data['result'] = $result;
 
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'academicYear_list',$data, true);
		$this->master_layout();
	}

	public function academicYearCreate(){
		
		$result_datamenu['cat_menu'] 		= 'setting/academicYearList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า เทอม / ปีการศึกษา';
		$result_datamenu['subcat_menu'] 	= 'academicyearList';
		$result_datamenu['subcat_menu_th'] 	= 'เพิ่มปีการศึกษา';
		$result_datamenu['active'] 			= 'academicyear';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'academicYear_create','', true);
		$this->master_layout();
	}

	public function academicYearAdd(){

		$create_by = $this->session->userdata['login_id'];
		
		$name = check_empty($_POST['name']);
		$term_id = check_empty($_POST['term_id']);
		$startdate = check_empty($_POST['startdate']);
		$enddate = check_empty($_POST['enddate']);
		
		$result = $this->setting_model->AddAcademicYear($name,$term_id,$startdate,$enddate,$create_by);
		
		if($result)
		{
			echo "success";
		}
		else echo "no success";
	}

	//--------------------------- AcademicYear ----------------------------//
	//--------------------------- SubjectType ----------------------------//
	
	public function subjectTypeList(){
		
		$result_datamenu['cat_menu'] 		= 'setting/subjectTypeList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า วิชา';
		$result_datamenu['subcat_menu'] 	= 'subjectTypeList';
		$result_datamenu['subcat_menu_th'] 	= 'รายการประเภทวิชา';
		$result_datamenu['active'] 			= 'subject';
		$result_datamenu['sub_active'] 		= 'subjectType';

		$data_menu['data_menu'] = $result_datamenu;

		$result = $this->setting_model->getSubjectTypeList();
		$data['result'] = $result;
 
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'subjectType_list',$data, true);
		$this->master_layout();
	}

	/*
	public function subjectTypeCreate(){
		
		$result_datamenu['cat_menu'] 		= 'setting/subjectTypeList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า วิชา';
		$result_datamenu['subcat_menu'] 	= 'subjectTypeCreate';
		$result_datamenu['subcat_menu_th'] 	= 'เพิ่มประเภทวิชา';
		$result_datamenu['active'] 			= 'subject';

		$data_menu['data_menu'] = $result_datamenu;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'subjectType_create','', true);
		$this->master_layout();
	}
	*/

	public function subjectTypeAdd(){
		
		$create_by = $this->session->userdata['login_id'];
		
		$name = check_empty($_POST['name']);
		$name_en = check_empty($_POST['name_en']);
		
		$result = $this->setting_model->AddSubjectType($name,$name_en,$create_by);
		
		if($result)
		{
			return true;
		}
		else return false;
		
	}
	
	//--------------------------- SubjectType ----------------------------//
	//--------------------------- SubjectGroup ----------------------------//
	
	public function subjectGroupList(){

		$result_datamenu['cat_menu'] 		= 'setting/subjectGroupList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า วิชา';
		$result_datamenu['subcat_menu'] 	= 'subjectGroupList';
		$result_datamenu['subcat_menu_th'] 	= 'รายการกลุ่มสาระ';
		$result_datamenu['active'] 			= 'subject';
		$result_datamenu['sub_active'] 		= 'subjectGroup';

		$data_menu['data_menu'] = $result_datamenu;

		$result = $this->setting_model->getSubjectGroupList();
		$data['result'] = $result;
 
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'subjectGroup_list',$data, true);
		$this->master_layout();
	}

	/*
	public function subjectGroupCreate(){
		
		$result_datamenu['cat_menu'] 		= 'setting';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า';
		$result_datamenu['subcat_menu'] 	= 'subjectGroupList';
		$result_datamenu['subcat_menu_th'] 	= 'กลุ่มสาระ';

		$data_menu['data_menu'] = $result_datamenu;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'subjectGroup_create','', true);
		$this->master_layout();
	}
	*/

	public function subjectGroupAdd(){
		
		$create_by = $this->session->userdata['login_id'];
		
		$name = check_empty($_POST['name']);
		$name_en = check_empty($_POST['name_en']);
		
		$result = $this->setting_model->AddSubjectGroup($name,$name_en,$create_by);
		
		if($result)
		{
			return true;
		}
		else return false;
		
	}
	
	//--------------------------- SubjectGroup ----------------------------//
	//--------------------------- Subject ----------------------------//
	public function subjectList(){
		
		if(isset($_GET['page'])&&!empty($_GET['page']))
		$page = $_GET['page']; else $page = 1;

		if(isset($_GET['type'])&&!empty($_GET['type']))
		$type = $_GET['type']; else $type = 0;

		if(isset($_GET['group'])&&!empty($_GET['group']))
		$group = $_GET['group']; else $group = 0;

		if(isset($_GET['educationSub'])&&!empty($_GET['educationSub']))
		$educationSub = $_GET['educationSub']; else $educationSub = 0;

		$data['type'] = $type;
		$data['group'] = $group;

		$result_datamenu['cat_menu'] 		= 'setting/subjectList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า วิชา';
		$result_datamenu['subcat_menu'] 	= 'subjectList';
		$result_datamenu['subcat_menu_th'] 	= 'รายการวิชา';
		$result_datamenu['active'] 			= 'subject';
		$result_datamenu['sub_active'] 		= '';

		$subjectType = $this->setting_model->getSubjectTypeList();
		$subjectGroup = $this->setting_model->getSubjectGroupList();

		$temp_educationSubList = $this->setting_model->getEducationSubList();
		if($temp_educationSubList)
		{
			$educationSubList = $temp_educationSubList->body;
		}
		else $educationSubList = NULL;

		
		$data['subjectTypeList'] = $subjectType;
		$data['subjectGroupList'] = $subjectGroup;
		$data['educationSubList'] = $educationSubList;

		$data_menu['data_menu'] = $result_datamenu;

		$result = $this->setting_model->getSubjectList($group,$type,$educationSub,$page);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'subject_list',$data, true);
		$this->master_layout();
	}

	public function subjectCreate(){
		
		$result_datamenu['cat_menu'] 		= 'setting/subjectList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า วิชา';
		$result_datamenu['subcat_menu'] 	= 'subjectCreate';
		$result_datamenu['subcat_menu_th'] 	= 'เพิ่มวิชา';
		$result_datamenu['active'] 			= 'subject';
		$result_datamenu['sub_active'] 		= 'subject';

		$data_menu['data_menu'] = $result_datamenu;

		$subjectType = $this->setting_model->getSubjectTypeList();
		$subjectGroup = $this->setting_model->getSubjectGroupList();

		
		$data['subjectTypeList'] = $subjectType;
		$data['subjectGroupList'] = $subjectGroup;

		$temp_educationList = $this->setting_model->getEducationList();
		if($temp_educationList)
		{
			$educationList = $temp_educationList->body;
		}
		else $educationList = NULL;
		$temp_educationSubList = $this->setting_model->getEducationSubList();
		if($temp_educationSubList)
		{
			$educationSubList = $temp_educationSubList->body;
		}
		else $educationSubList = NULL;

		$data['educationList'] = $educationList;
		$data['educationSubList'] = $educationSubList;

		
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'subject_create',$data, true);
		$this->master_layout();
	}

	public function subjectAdd(){
		
		$create_by = $this->session->userdata['login_id'];
		
		$data = new stdClass(); 
		$data->subject_group_id = check_empty($_POST['subjectGroup']);
        $data->subject_type_id = check_empty($_POST['subjectType']);
        $data->education_level_id = check_empty($_POST['education']);
        $data->education_sublevel_id = check_empty($_POST['educationSub']);
        $data->subject_id = check_empty($_POST['code']);
        $data->name_th = check_empty($_POST['name_th']);
        $data->name_en = check_empty($_POST['name_en']);
		$data->unit = check_empty($_POST['unit']);
		$data->created_by = $create_by;

		$result = $this->setting_model->AddSubject($data);
		
		if($result)
		{
			return true;
		}
		else return false;
		
	}

	public function subjectLoad()
	{
		$subjectType = 0;//$_POST['subjectType'];
		$subjectGroup = $_POST['subjectGroup'];
		$educationSub = $_POST['educationSub'];
		$page = $_POST['page'];

		
		$result = $this->setting_model->getSubjectList($subjectGroup,$subjectType,$educationSub,$page);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		
		$this->load->view ('subject_load',$data);
		
	}

	public function subjectAddScore($subject_id){
		
		$result_datamenu['cat_menu'] 		= 'setting/subjectScoreAdd';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า วิชา';
		$result_datamenu['subcat_menu'] 	= 'subjectCreate';
		$result_datamenu['subcat_menu_th'] 	= 'ตั้งค่าคะแนน';
		$result_datamenu['active'] 			= 'subject';
		$result_datamenu['sub_active'] 		= 'subject';

		$data_menu['data_menu'] = $result_datamenu;

		$subjectProfile = $this->setting_model->getSubjectConfig($subject_id);
		$data['subjectProfile'] = $subjectProfile;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'subjectScore_add',$data, true);
		$this->master_layout();
		
	}

	public function subjectUpdateScore(){
		
		
		$create_by = $this->session->userdata['login_id'];
		
		$data = new stdClass(); 
		$data->academic_year = $_POST['academic_year'];
		$data->subject_id = check_empty($_POST['subject_id']);
		$data->term_1_test_score = check_empty($_POST['term_1_test_score']);
		$data->term_1_midterm_score = check_empty($_POST['term_1_midterm_score']);
        $data->term_1_finalterm_score = check_empty($_POST['term_1_finalterm_score']);
		$data->term_2_test_score = check_empty($_POST['term_2_test_score']);
		$data->term_2_midterm_score = check_empty($_POST['term_2_midterm_score']);
        $data->term_2_finalterm_score = check_empty($_POST['term_2_finalterm_score']);
		//console($data);
		
		$result = $this->setting_model->subjectUpdateScore($data);
		$subject_id = $_POST['subject_id'];
		$url = base_url('setting/subjectAddScore/'.$subject_id.'');
		echo "<script type='text/javascript'>
		location.href = '" . $url . "';
		</script>";
	}
	//--------------------------- Subject ----------------------------//
	//--------------------------- PersonnelGroup ----------------------------//
	
	public function personnelGroupList(){
		$result_datamenu['cat_menu'] 		= 'setting/personnelGroupList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า ตำแหน่ง';
		$result_datamenu['subcat_menu'] 	= 'personnelGroupList';
		$result_datamenu['subcat_menu_th'] 	= 'รายการตำแหน่ง';
		$result_datamenu['active'] 			= 'personnel';
		$result_datamenu['sub_active'] 		= 'personnelGroup';

		$data_menu['data_menu'] = $result_datamenu;

		$result = $this->setting_model->getPersonnelGroupList();
		$data['result'] = $result;
 
		
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'personnelGroup_list',$data, true);
		$this->master_layout();
		
	}

	public function personnelGroupAdd(){
		
		$create_by = $this->session->userdata['login_id'];
		
		$title = check_empty($_POST['name']);
		
		$result = $this->setting_model->AddPersonnelGroup($title);
		
		if($result)
		{
			return true;
		}
		else return false;
		
	}
	
	//--------------------------- PersonnelGroup ----------------------------//
	//--------------------------- Personnel ----------------------------//
	public function personnelList(){
		
		if(isset($_GET['status'])&&!empty($_GET['status']))
		{
			$alert = $_GET['status'];
			$data['alert'] = $alert;
		}	
		else $data['alert'] = '';

		if(isset($_GET['page'])&&!empty($_GET['page']))
		$page = $_GET['page']; else $page = 1;
		if(isset($_GET['search'])&&!empty($_GET['search']))
		$keysearch = $_GET['search']; else $keysearch = '';

		$data['search'] = $keysearch;

		$result_datamenu['cat_menu'] 		= 'setting/personnelList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า บุคลากร';
		$result_datamenu['subcat_menu'] 	= 'personnelList';
		$result_datamenu['subcat_menu_th'] 	= 'รายชื่อบุคลากร';
		$result_datamenu['active'] 			= 'personnel';
		$result_datamenu['sub_active'] 		= 'personnelList';

		$personnelGroup = $this->setting_model->getPersonnelGroupList();
		$permission= $this->setting_model->getPermissionList();

		$data['personnelGroupList'] = $personnelGroup;
		$data['permissionList'] = $permission;

		
		$data_menu['data_menu'] = $result_datamenu;

		if($keysearch!='')
		{
			$result = $this->setting_model->getPersonnelSearch($keysearch);
			
			
		}
		else $result = $this->setting_model->getPersonnelList($page,0,0);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		//console($data);
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'personnel_list',$data, true);
		$this->master_layout();
	}

	public function personnelCreate(){
		
		
		$result_datamenu['cat_menu'] 		= 'setting/personnelList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า บุคลากร';
		$result_datamenu['subcat_menu'] 	= 'personnelCreate';
		$result_datamenu['subcat_menu_th'] 	= 'เพิ่ม บุคลากร';
		$result_datamenu['active'] 			= 'personnel';
		$result_datamenu['sub_active'] 		= 'personnelCreate';

		$data_menu['data_menu'] = $result_datamenu;

		$personnelGroup = $this->setting_model->getPersonnelGroupList();
		$permission= $this->setting_model->getPermissionList();
		$subjectGroup= $this->setting_model->getSubjectGroupList();

		$data['personnelGroupList'] = $personnelGroup;
		$data['permissionList'] = $permission;
		$data['subjectGroupList'] = $subjectGroup;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'personnel_create',$data, true);
		$this->master_layout();
	}

	public function personnelEdit($personnel_id){
		
		$result_datamenu['cat_menu'] 		= 'setting/personnelList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า บุคลากร';
		$result_datamenu['subcat_menu'] 	= 'personnelCreate';
		$result_datamenu['subcat_menu_th'] 	= 'แก้ไข บุคลากร';
		$result_datamenu['active'] 			= 'personnel';
		$result_datamenu['sub_active'] 		= 'personnelEdit';

		$data_menu['data_menu'] = $result_datamenu;

		$personnelGroup = $this->setting_model->getPersonnelGroupList();
		$permission= $this->setting_model->getPermissionList();
		$subjectGroup= $this->setting_model->getSubjectGroupList();


		$result = $this->personnel_model->getPersonnelProfile($personnel_id);
		$data['profile'] = $result[0];

		$data['personnelGroupList'] = $personnelGroup;
		$data['permissionList'] = $permission;
		$data['subjectGroupList'] = $subjectGroup;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'personnel_edit',$data, true);
		$this->master_layout();
	}

	public function personnelAdd(){
		
		$create_by = $this->session->userdata['login_id'];
		
		$data = new stdClass(); 
		$data->personnel_group_id = check_empty($_POST['personnel_group_id']);
		$data->permission_id = check_empty($_POST['permission_id']);
		$data->subject_group_id = check_empty($_POST['subject_group_id']);
        $data->name_title_th = check_empty($_POST['name_title_th']);
        $data->firstname_th = check_empty($_POST['firstname_th']);
        $data->lastname_th = check_empty($_POST['lastname_th']);
        $data->name_title_en = check_empty($_POST['name_title_en']);
        $data->firstname_en = check_empty($_POST['firstname_en']);
		$data->lastname_en = check_empty($_POST['lastname_en']);
		$id_card = $_POST['txtID1'].$_POST['txtID2'].$_POST['txtID3'].$_POST['txtID4'].$_POST['txtID5'];
		
		if($_FILES['myfile']['error']=='4')
		{
			$data->profile_img = '';
		}else
		{
			$result_upload = json_decode(upload_pic($_FILES));
			if($result_upload->header->res_code=='200')
			{
				$profile_img = $result_upload->body->image_path;
			}
			else $profile_img = '';
			$data->profile_img = $profile_img;
		}
        $data->birthdate = check_empty($_POST['birthdate']);
        $data->gender = check_empty($_POST['gender']);
        $data->tel = check_empty($_POST['tel']);
        $data->cell_phone = check_empty($_POST['cell_phone']);
        $data->email = check_empty($_POST['email']);
        $data->password = '';//md5(check_empty($_POST['password']));
        $data->created_by = $create_by;
		$data->personnel_id = 'TPS00212334';
		$data->id_card = $id_card;

		$result = $this->setting_model->AddPersonnel($data);
		
		if($result)
		{
			$url = base_url('setting/personnelList?status=success');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
		else {
			$url = base_url('setting/personnelList?status=error');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
	}

	public function personnelUpdate(){
		
		$create_by = $this->session->userdata['login_id'];
		
		$data = new stdClass(); 
		$data->id = $_POST['id'];
		$data->personnel_group_id = check_empty($_POST['personnel_group_id']);
		$data->permission_id = check_empty($_POST['permission_id']);
		$data->subject_group_id = check_empty($_POST['subject_group_id']);
        $data->name_title_th = check_empty($_POST['name_title_th']);
        $data->firstname_th = check_empty($_POST['firstname_th']);
        $data->lastname_th = check_empty($_POST['lastname_th']);
        $data->name_title_en = check_empty($_POST['name_title_en']);
        $data->firstname_en = check_empty($_POST['firstname_en']);
		$data->lastname_en = check_empty($_POST['lastname_en']);
		$id_card = $_POST['txtID1'].$_POST['txtID2'].$_POST['txtID3'].$_POST['txtID4'].$_POST['txtID5'];
		$data->id_card = $id_card;
		
		if($_FILES['myfile']['error']=='4')
		{
			$data->profile_img = check_empty($_POST['profile_img']);
		}else
		{
			$result_upload = json_decode(upload_pic($_FILES));
			if($result_upload->header->res_code=='200')
			{
				$profile_img = $result_upload->body->image_path;
			}
			else $profile_img = '';
			$data->profile_img = $profile_img;
		}

        $data->birthdate = check_empty($_POST['birthdate']);
        $data->gender = check_empty($_POST['gender']);
        $data->tel = check_empty($_POST['tel']);
        $data->cell_phone = check_empty($_POST['cell_phone']);
        $data->email = check_empty($_POST['email']);
        $data->created_by = $create_by;
		$data->personnel_id = 'TPS00212334';
		$data->status = $_POST['status'];
		$data->lastupdated_by = $create_by;
		

		$result = $this->setting_model->UpdatePersonnel($data);
		
		
		if($result)
		{
			$url = base_url('setting/personnelList?status=success');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
		else {
			$url = base_url('setting/personnelList?status=error');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
	
	}

	public function personnelLoad()
	{
		$personnelGroup = $_POST['personnelGroup'];
		//$permission = $_POST['permission'];
		$permission = 0;
		$page = $_POST['page'];

		//personnel/list/1/20/desc?permission=1&position=1&search=0818305533
		$result = $this->setting_model->getPersonnelList($page,$personnelGroup,$permission);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		
		$this->load->view ('personnel_load',$data);
		
	}
	//--------------------------- Personnel ----------------------------//
	//--------------------------- Classroom ----------------------------//
	public function classroomList(){
		
		if(isset($_GET['status'])&&!empty($_GET['status']))
		{
			$alert = $_GET['status'];
			$data['alert'] = $alert;
		}	
		else $data['alert'] = '';

		$result_datamenu['cat_menu'] 		= 'setting/classroomList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า ห้องเรียน';
		$result_datamenu['subcat_menu'] 	= 'classroomList';
		$result_datamenu['subcat_menu_th'] 	= '<i class="fa fa-fort-awesome"></i> รายการ ห้องเรียน';
		$result_datamenu['active'] 			= 'classroom';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$academicYearList = $this->setting_model->getAcademicYearList();
		$temp_educationList = $this->setting_model->getEducationList();
		if($temp_educationList)
		{
			$educationList = $temp_educationList->body;
		}
		else $educationList = NULL;
		$temp_educationSubList = $this->setting_model->getEducationSubList();
		if($temp_educationSubList)
		{
			$educationSubList = $temp_educationSubList->body;
		}
		else $educationSubList = NULL;

		$data['academicYearList'] = $academicYearList;
		$data['educationList'] = $educationList;
		$data['educationSubList'] = $educationSubList;

		$temp_result = $this->setting_model->getClassroomList();
		if($temp_result)
		{
			$result = $temp_result->body;
		}
		else $result = NULL;
		$data['result'] = $result;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'classroom_list',$data, true);
		$this->master_layout();
	}

	public function classroomLoadEducationSub()
	{
		$education = $_POST['education'];

		
		$result = $this->setting_model->getEducationSubByEducation($education);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		$this->load->view ('classroom_load_educationsub',$data);
		
		
	}

	public function classroomLoadRoom()
	{
		$academic_year = $_POST['academic_year'];
		$term_id = $_POST['term_id'];
		$education = $_POST['education'];
		$educationSub = $_POST['educationSub'];

		
		$result = $this->setting_model->getClassroomRoom($academic_year,$term_id,$education,$educationSub);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		$this->load->view ('classroom_load_room',$data);
	}

	public function classroomLoad()
	{
		$academic_year = $_POST['academic_year'];
		$term_id = $_POST['term_id'];
		$education = $_POST['education'];
		$educationSub = $_POST['educationSub'];
		$room = $_POST['room'];

		
		//console($_POST);

		$result = $this->setting_model->getClassroomList($academic_year,$term_id,$education,$educationSub,$room);
		//console($result);
		if($result)
		{
			$data['result'] = $result->body;
		}
		else
		{
			$data['result'] = NULL;
		}
		$this->load->view ('classroom_load',$data);
	}

	

	public function classroomCreate(){
		
		$result_datamenu['cat_menu'] 		= 'setting/classroomList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า ห้องเรียน';
		$result_datamenu['subcat_menu'] 	= 'classroomCreate';
		$result_datamenu['subcat_menu_th'] 	= '<i class="fa fa-fort-awesome"></i> เพิ่ม ห้องเรียน';
		$result_datamenu['active'] 			= 'classroom';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;
		
		$academicYearList = $this->setting_model->getAcademicYearList();
		$temp_educationList = $this->setting_model->getEducationList();
		if($temp_educationList)
		{
			$educationList = $temp_educationList->body;
		}
		else $educationList = NULL;
		$temp_educationSubList = $this->setting_model->getEducationSubList();
		if($temp_educationSubList)
		{
			$educationSubList = $temp_educationList->body;
		}
		else $educationSubList = NULL;

		$temp_classroomList = $this->setting_model->getClassroomList();
		if($temp_classroomList)
		{
			$classroomList = $temp_classroomList->body;
		}
		else $classroomList = NULL;

		$temp_personnelList = $this->setting_model->getPersonnelList();
		if($temp_personnelList)
		{
			$personnelList = $temp_personnelList->body;
		}
		else $personnelList = NULL;

		$data['academicYearList'] = $academicYearList;
		$data['educationList'] = $educationList;
		$data['educationSubList'] = $educationSubList;
		$data['classroomList'] = $classroomList;
		$data['personnelList'] = $personnelList;
		//console($data);
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'classroom_create',$data, true);
		$this->master_layout();
		
	}

	public function classroomAdd(){
		
		$create_by = $this->session->userdata['login_id'];
		
		$academic_year = check_empty($_POST['academic_year']);
		$education = check_empty($_POST['education']);
		$educationSub = check_empty($_POST['educationSub']);
		$room = check_empty($_POST['room']);
		$personnel = check_empty($_POST['personnel']);
		
		$result = $this->setting_model->AddClassroom(
			$academic_year,$education,$educationSub,$room,$personnel,$create_by
		);
		
		if($result)
		{
			$url = base_url('setting/classroomList?status=success');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
		else {
			$url = base_url('setting/classroomList?status=error');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
		
		
	}

	public function classroomEdit($academicYear,$classroom_id){
		
		$result_datamenu['cat_menu'] 		= 'setting/classroomList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า ห้องเรียน';
		$result_datamenu['subcat_menu'] 	= 'classroomCreate';
		$result_datamenu['subcat_menu_th'] 	= '<i class="fa fa-fort-awesome"></i> แก้ไข ห้องเรียน';
		$result_datamenu['active'] 			= 'classroom';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;
		
		$profile = $this->setting_model->getClassroomProfile($academicYear,$classroom_id);
		$data['profile'] = $profile;

		$academicYearList = $this->setting_model->getAcademicYearList();
		$temp_educationList = $this->setting_model->getEducationList();
		if($temp_educationList)
		{
			$educationList = $temp_educationList->body;
		}
		else $educationList = NULL;

		$temp_educationSubList = $this->setting_model->getEducationSubListById($profile->education_level_id);
		if($temp_educationSubList)
		{
			$educationSubList = $temp_educationSubList->body;
		}
		else $educationSubList = NULL;

		$temp_personnelList = $this->setting_model->getPersonnelList();
		if($temp_personnelList)
		{
			$personnelList = $temp_personnelList->body;
		}
		else $personnelList = NULL;

		
	
		$data['academicYearList'] = $academicYearList;
		$data['educationList'] = $educationList;
		$data['educationSubList'] = $educationSubList;
		$data['personnelList'] = $personnelList;
		//console($data);
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'classroom_edit',$data, true);
		$this->master_layout();
		
	}

	public function classroomUpdate(){
		
		$create_by = $this->session->userdata['login_id'];

		$data = new stdClass(); 
		$data->id = $_POST['classroom_id'];
		$data->academic_year = $_POST['academic_year'];
		$data->education_level_id = $_POST['education'];
		$data->education_sublevel_id = $_POST['educationSub'];
		$data->room = $_POST['room'];
		$data->status = 1;
		$data->lastupdated_by = $create_by;

		$update = new stdClass(); 
		$update->classroom_id = $_POST['classroom_id'];
		$update->academic_year = $_POST['academic_year'];
		$update->personnel_id = $_POST['personnel_id'];
		
		$result = $this->setting_model->mappingPersonnelClassroom($update);

		$result = $this->setting_model->updateClassroom($data);
		
		if($result)
		{
			$url = base_url('setting/classroomList?status=success');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
		else {
			$url = base_url('setting/classroomList?status=error');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
		
	}
	//--------------------------- Classroom ----------------------------//
	//--------------------------- Parent ----------------------------//
	public function parentList(){
		
		if(isset($_GET['status'])&&!empty($_GET['status']))
		{
			$alert = $_GET['status'];
			$data['alert'] = $alert;
		}	
		else $data['alert'] = '';

		if(isset($_GET['page'])&&!empty($_GET['page']))
		$page = $_GET['page']; else $page = 1;
		if(isset($_GET['search'])&&!empty($_GET['search']))
		$keysearch = $_GET['search']; else $keysearch = '';
		
		$result_datamenu['cat_menu'] 		= 'setting/parrentList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า ผู้ปกครอง';
		$result_datamenu['subcat_menu'] 	= 'parentList';
		$result_datamenu['subcat_menu_th'] 	= '<i class="fa fa-male"></i> รายชื่อ ผู้ปกครอง';
		$result_datamenu['active'] 			= 'parent';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;
		$result = $this->setting_model->getParentList($page,$keysearch);
		
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}

		$data['search'] = $keysearch;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'parent_list',$data, true);
		$this->master_layout();
	}

	public function parentCreate(){
		
		$result_datamenu['cat_menu'] 		= 'setting/parrentList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า ผู้ปกครอง';
		$result_datamenu['subcat_menu'] 	= 'parentCreate';
		$result_datamenu['subcat_menu_th'] 	= '<i class="fa fa-male"></i> เพิ่ม ผู้ปกครอง';
		$result_datamenu['active'] 			= 'parent';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'parent_create','', true);
		$this->master_layout();
	}

	public function parentEdit($parent_id){
		
		$result_datamenu['cat_menu'] 		= 'setting/parentList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า ผู้ปกครอง';
		$result_datamenu['subcat_menu'] 	= 'parentCreate';
		$result_datamenu['subcat_menu_th'] 	= '<i class="fa fa-male"></i> แก้ไข บุคลากร';
		$result_datamenu['active'] 			= 'parent';
		$result_datamenu['sub_active'] 		= 'parentEdit';

		$data_menu['data_menu'] = $result_datamenu;

		$result = $this->parent_model->getParentProfile($parent_id);
		
		if($result)
		{
			$data['profile'] = $result->body[0];
		}
		else
		{
			$data['profile'] = NULL;
		}

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'parent_edit',$data, true);
		$this->master_layout();
	}

	public function parentDelete($parent_id){
		
		$data = new stdClass();
		$data->id = $parent_id;
		$result = $this->setting_model->deleteParent($data);
		if($result)
		{
			$url = base_url('setting/parentList?status=success');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
		else {
			$url = base_url('setting/parentList?status=error');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
	}

	
	public function parentAdd()
	{
		$create_by = $this->session->userdata['login_id'];

			
		$data = new stdClass(); 
		$id_card = $_POST['txtID1'].$_POST['txtID2'].$_POST['txtID3'].$_POST['txtID4'].$_POST['txtID5'];
		$data->id_card = $id_card;
		$data->name_title = check_empty($_POST['name_title_th']);
        $data->firstname = check_empty($_POST['firstname_th']);
        $data->lastname = check_empty($_POST['lastname_th']);
        $result_upload = json_decode(upload_pic($_FILES));
		if($result_upload->header->res_code=='200')
        {
            $profile_img = $result_upload->body->image_path;
        }
        else $profile_img = '';
		$data->profile_img = $profile_img;
		$data->tel = check_empty($_POST['tel']);
		$data->cell_phone = check_empty($_POST['cell_phone']);
		$data->email = check_empty($_POST['email']);
		$data->occupation = check_empty($_POST['occupation']);
        $data->salary = check_empty($_POST['salary']);
        $data->address = check_empty($_POST['address']);
		$data->subdistrict = check_empty($_POST['subdistrict_id']);
		$result_district = $this->setting_model->getDistrictId($_POST['district']);
		if($result_district) $district_id = $result_district[0]->id;else $district_id = '';
		$data->district_id = $district_id;
		$result_province = $this->setting_model->getProvinceId($_POST['province']);
		$data->zipcode = check_empty($_POST['zipcode']);
        $data->created_by = $create_by;

		$result = $this->setting_model->AddParent($data);
		if($result)
		{
			$url = base_url('setting/parentList?status=success');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
		else {
			$url = base_url('setting/parentList?status=error');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
	}

	public function parentUpdate()
	{
		$create_by = $this->session->userdata['login_id'];

		$data = new stdClass(); 
		$data->id = check_empty($_POST['id']);
		$data->name_title = check_empty($_POST['name_title_th']);
        $data->firstname = check_empty($_POST['firstname_th']);
        $data->lastname = check_empty($_POST['lastname_th']);
        $id_card = $_POST['txtID1'].$_POST['txtID2'].$_POST['txtID3'].$_POST['txtID4'].$_POST['txtID5'];
		$data->id_card = $id_card;
		if($_FILES['myfile']['error']=='4')
		{
			$data->profile_img = check_empty($_POST['profile_img']);
		}else
		{
			$result_upload = json_decode(upload_pic($_FILES));
			if($result_upload->header->res_code=='200')
			{
				$profile_img = $result_upload->body->image_path;
			}
			else $profile_img = '';
			$data->profile_img = $profile_img;
		}
		$data->occupation = check_empty($_POST['occupation']);
        $data->salary = check_empty($_POST['salary']);
        $data->tel = check_empty($_POST['tel']);
        $data->cell_phone = check_empty($_POST['cell_phone']);
        $data->email = check_empty($_POST['email']);
		$data->address = check_empty($_POST['address']);
		$data->subdistrict_id = check_empty($_POST['subdistrict_id']);
		$result_district = $this->setting_model->getDistrictId($_POST['district']);
		if($result_district) $district_id = $result_district[0]->id;else $district_id = '';
		$data->district_id = $district_id;
		$result_province = $this->setting_model->getProvinceId($_POST['province']);
		if($result_province) $province_id = $result_province[0]->id;else $province_id = '';
		$data->province_id = $province_id;
		$data->zipcode = check_empty($_POST['zipcode']);
        $data->status = '1';
        $data->lastupdated_by = $create_by;

		
		$result = $this->setting_model->UpdateParent($data);
		
		
		if($result)
		{
			$url = base_url('setting/parentList?status=success');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
		else {
			$url = base_url('setting/parentList?status=error');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
		
		
	}
	//--------------------------- Personnel ----------------------------//
	//--------------------------- Address ----------------------------//
	public function getAddress($subdistrict)
	{
		
		$result = $this->setting_model->getAddress($subdistrict);
		//console($result);
		if($result)
		{
			$data['result'] = $result->body;
		}
		else
		{
			$data['result'] = NULL;
		}

		$this->load->view ('address_load',$data);
	}
	//--------------------------- Address ----------------------------//
	//--------------------------- Student ----------------------------//
	public function studentList(){
		
		if(isset($_GET['status'])&&!empty($_GET['status']))
		{
			$alert = $_GET['status'];
			$data['alert'] = $alert;
		}	
		else $data['alert'] = '';

		if(isset($_GET['page'])&&!empty($_GET['page']))
		$page = $_GET['page']; else $page = 1;
		if(isset($_GET['search'])&&!empty($_GET['search']))
		$keysearch = $_GET['search']; else $keysearch = '';
		
		$result_datamenu['cat_menu'] 		= 'setting/studentList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า นักเรียน';
		$result_datamenu['subcat_menu'] 	= 'studentList';
		$result_datamenu['subcat_menu_th'] 	= 'รายชื่อ นักเรียน';
		$result_datamenu['active'] 			= 'student';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$temp_academicYearNow = $this->setting_model->getAcademicYearNow();
		$academicYearNow = $temp_academicYearNow->academic_year;
		$term_id = $temp_academicYearNow->term_id;

		if($keysearch!='')
		{
			$result = $this->student_model->searchStudent($academicYearNow,$term_id,$keysearch);
		}
		else
		{
			$result = $this->setting_model->getStudentList($academicYearNow,$term_id,$page);
		}
		if($result)
		{
			if($keysearch!='')
			{
				$data['result'] = $result;
				$data['page'] = NULL;
			}else 
			{
				$data['result'] = $result->body;
				$data['page'] = $result->header;
			}	
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}

		$data['search'] = $keysearch;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'student_list',$data, true);
		$this->master_layout();
	}

	public function studentCreate(){
		
		$result_datamenu['cat_menu'] 		= 'setting/studentList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า นักเรียน';
		$result_datamenu['subcat_menu'] 	= 'studentList';
		$result_datamenu['subcat_menu_th'] 	= 'เพิ่ม นักเรียน';
		$result_datamenu['active'] 			= 'student';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'student_create','', true);
		$this->master_layout();
	}

	
	public function studentAdd(){
		
	   	$create_by = $this->session->userdata['login_id'];

		$data = new stdClass(); 
		$data->student_no = check_empty($_POST['student_no']);
		$data->name_title_th = check_empty($_POST['name_title_th']);
        $data->firstname_th = check_empty($_POST['firstname_th']);
		$data->lastname_th = check_empty($_POST['lastname_th']);
		$data->name_title_en = check_empty($_POST['name_title_en']);
        $data->firstname_en = check_empty($_POST['firstname_en']);
        $data->lastname_en = check_empty($_POST['lastname_en']);
        $id_card = $_POST['txtID1'].$_POST['txtID2'].$_POST['txtID3'].$_POST['txtID4'].$_POST['txtID5'];
		$data->id_card = $id_card;
		$data->nickname = check_empty($_POST['nickname']);
		$result_upload = json_decode(upload_pic($_FILES));
		if($result_upload->header->res_code=='200')
        {
            $profile_img = $result_upload->body->image_path;
        }
        else $profile_img = '';
		$data->profile_img = $profile_img;
		$data->birthdate = check_empty($_POST['birthdate']);
        $data->tel = '';
        $data->cell_phone = '';
        $data->nationality = check_empty($_POST['nationality']);
        $data->race = check_empty($_POST['race']);
        $data->religion = check_empty($_POST['religion']);
		$data->address = check_empty($_POST['address']);
		$data->subdistrict_id = check_empty($_POST['subdistrict_id']);
		$result_district = $this->setting_model->getDistrictId($_POST['district']);
		if($result_district) $district_id = $result_district[0]->id;else $district_id = '';
		$data->district_id = $district_id;
		$result_province = $this->setting_model->getProvinceId($_POST['province']);
		if($result_province) $province_id = $result_province[0]->id;else $province_id = '';
		$data->province_id = $province_id;
		$data->zipcode = check_empty($_POST['zipcode']);
		$data->home_latitude = check_empty($_POST['home_latitude']);
		$data->home_longitude = check_empty($_POST['home_longitude']);
		$data->blood_type = check_empty($_POST['blood_type']);
		$data->congenital_disease = check_empty($_POST['congenital_disease']);
        $data->created_by = $create_by;

		//console($data);
		
		$result = $this->setting_model->AddStudent($data);
		
		if($result)
		{
			$url = base_url('setting/studentList?status=success');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
		else {
			$url = base_url('setting/studentList?status=error');
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
		
	}

	public function studentEdit($student_id){
		
		$result_datamenu['cat_menu'] 		= 'setting/studentList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า นักเรียน';
		$result_datamenu['subcat_menu'] 	= 'studentList';
		$result_datamenu['subcat_menu_th'] 	= 'แก้ไข นักเรียน';
		$result_datamenu['active'] 			= 'student';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$temp_academicYearNow = $this->setting_model->getAcademicYearNow();
		$academicYearNow = $temp_academicYearNow->academic_year;
		$term_id = $temp_academicYearNow->term_id;

		$result = $this->student_model->getStudentProfile($academicYearNow,$term_id,$student_id);
		if($result)
		{
			$data['profile'] = $result[0];
		}
		else
		{
			$data['profile'] = NULL;
		}
		
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'student_edit',$data, true);
		$this->master_layout();
		
	}

	public function studentUpdate($student_id){
		
	 $create_by = $this->session->userdata['login_id'];

	 $data = new stdClass(); 
	 $data->id = $student_id;
	 $data->name_title_th = check_empty($_POST['name_title_th']);
	 $data->firstname_th = check_empty($_POST['firstname_th']);
	 $data->lastname_th = check_empty($_POST['lastname_th']);
	 $data->name_title_en = check_empty($_POST['name_title_en']);
	 $data->firstname_en = check_empty($_POST['firstname_en']);
	 $data->lastname_en = check_empty($_POST['lastname_en']);
	 $id_card = $_POST['txtID1'].$_POST['txtID2'].$_POST['txtID3'].$_POST['txtID4'].$_POST['txtID5'];
	 $data->id_card = $id_card;
	 $data->nickname = check_empty($_POST['nickname']);
	 if($_FILES['myfile']['error']=='4')
		{
			$data->profile_img = check_empty($_POST['profile_img']);
		}else
		{
			$result_upload = json_decode(upload_pic($_FILES));
			if($result_upload->header->res_code=='200')
			{
				$profile_img = $result_upload->body->image_path;
			}
			else $profile_img = '';
			$data->profile_img = $profile_img;
		}
	 $data->birthdate = check_empty($_POST['birthdate']);
	 $data->tel = '';
	 $data->cell_phone = '';
	 $data->nationality = check_empty($_POST['nationality']);
	 $data->race = check_empty($_POST['race']);
	 $data->religion = check_empty($_POST['religion']);
	 $data->address = check_empty($_POST['address']);
	 $data->subdistrict_id = check_empty($_POST['subdistrict_id']);
	 $result_district = $this->setting_model->getDistrictId($_POST['district']);
	 if($result_district) $district_id = $result_district[0]->id;else $district_id = '';
	 $data->district_id = $district_id;
	 $result_province = $this->setting_model->getProvinceId($_POST['province']);
	 if($result_province) $province_id = $result_province[0]->id;else $province_id = '';
	 $data->province_id = $province_id;
	 $data->zipcode = check_empty($_POST['zipcode']);
	 $data->home_latitude = check_empty($_POST['home_latitude']);
	 $data->home_longitude = check_empty($_POST['home_longitude']);
	 $data->blood_type = check_empty($_POST['blood_type']);
	 $data->congenital_disease = check_empty($_POST['congenital_disease']);
	 $data->status = $_POST['status'];
	 $data->lastupdated_by = $create_by;

	 $result = $this->setting_model->updateStudent($data);
	 
	 if($result)
	 {
		 $url = base_url('setting/studentList?status=success');
		 echo "<script type='text/javascript'>
		 location.href = '" . $url . "';
		 </script>";
	 }
	 else {
		 $url = base_url('setting/studentList?status=error');
		 echo "<script type='text/javascript'>
		 location.href = '" . $url . "';
		 </script>";
	 }
	 
 }
	//--------------------------- Personnel ----------------------------//
	//--------------------------- Behavior ----------------------------//
	public function behaviorList(){
		
		if(isset($_GET['search'])&&!empty($_GET['search']))
		$keysearch = $_GET['search']; else $keysearch = '';
		
		if(isset($_POST['type'])&&!empty($_POST['type']))
		$type = $_POST['type']; else $type = '';
		
		$result_datamenu['cat_menu'] 		= 'setting/studentList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า ความประพฤติ';
		$result_datamenu['subcat_menu'] 	= 'behaviorList';
		$result_datamenu['subcat_menu_th'] 	= 'รายการ ความประพฤติ';
		$result_datamenu['active'] 			= 'behavior';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		if($keysearch!='')
		{
			$result = $this->setting_model->getBehaviorSearch($keysearch);
			
		}
		else $result = $this->setting_model->getBehaviorList($type);
		
		if($result)
		{
			$data['result'] = $result->body;
		}
		else
		{
			$data['result'] = NULL;
		}

		$data['search'] = $keysearch;
		$data['type'] = $type;
		
		
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'behavior_list',$data, true);
		$this->master_layout();
		
	}

	public function behaviorLoad(){
		
		if(isset($_GET['page'])&&!empty($_GET['page']))
		$page = $_GET['page']; else $page = 1;
		if(isset($_POST['type'])&&!empty($_POST['type']))
		$type = $_POST['type']; else $type = '';

		$result = $this->setting_model->getBehaviorList($type);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		$this->load->view ('behavior_load',$data);
	}

	public function behaviorAdd(){
		$create_by = $this->session->userdata['login_id'];

		$data = new stdClass(); 
		$data->title = check_empty($_POST['title']);
		if($_POST['type']=='minus')
		{
			$score = '-'.check_empty($_POST['score']).'';
		}
		else $score = check_empty($_POST['score']);
		$data->point = $score;
		$data->created_by = $create_by;

		$result = $this->setting_model->AddBehavior($data);
		
		if($result)
		{
			return true;
		}
		else return false;
		
	}

	//--------------------------- Behavior ----------------------------//
	//--------------------------- rank ----------------------------//	
	public function rankList(){
		
		$result_datamenu['cat_menu'] 		= 'setting/studentList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า คะแนนตัดเกรด';
		$result_datamenu['subcat_menu'] 	= 'rankList';
		$result_datamenu['subcat_menu_th'] 	= 'รายการ คะแนนตัดเกรด';
		$result_datamenu['active'] 			= 'rank';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$academicYearList = $this->setting_model->getAcademicYearList();
		$data['academicYearList'] = $academicYearList;

		$result = $this->setting_model->getRankList();
		if($result)
		{
			$data['result'] = $result->body;
		}
		else
		{
			$data['result'] = NULL;
		}

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'rank_list',$data, true);
		$this->master_layout();
		
	}

	public function rankUpdate()
	{
		$create_by = $this->session->userdata['login_id'];

		$data = new stdClass();
		$data->id = check_empty($_POST['id']);
		$data->grade = check_empty($_POST['grade']);
		$data->academic_year = check_empty($_POST['academic_year']);
		$data->point_min = check_empty($_POST['point_min']);
		$data->point_max = check_empty($_POST['point_max']);
		$data->status = check_empty($_POST['status']);
		$data->lastupdated_by = $create_by;

		$result = $this->setting_model->updateRank($data);
		
		if($result)
		{
			return true;
		}
		else return false;
	}

	public function rankLoad()
	{
		
		$year = $_POST['year'];

		$result = $this->setting_model->getRankList();
		if($result)
		{
			$data['result'] = $result->body;
		}
		else
		{
			$data['result'] = NULL;
		}

		$this->load->view ('rank_load',$data);
	}

	public function autoCheckInAllRoom()
	{
		$classroom_id = $_POST['classroom_id'];
		
		$create_by = $this->session->userdata['login_id'];

		$result = $this->setting_model->autoCheckInAllRoom($classroom_id,$create_by);

		if($result)
		{
			return true;
		}
		else return false;
	}

	//--------------------------- Activity ----------------------------//
	/*
	public function activityList(){
		
		$result_datamenu['cat_menu'] 		= 'setting/activityList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า กิจกรรม';
		$result_datamenu['subcat_menu'] 	= 'activityList';
		$result_datamenu['subcat_menu_th'] 	= 'รายการกิจกรรม';
		$result_datamenu['active'] 			= 'activity';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$academicYearList = $this->setting_model->getAcademicYearList();
		$data['academicYearList'] = $academicYearList;

		$activityList = $this->setting_model->getRankList();
		$data['result'] = $activityList;

		//console($data);		
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'activity_list',$data, true);
		$this->master_layout();
		
	}

	public function activityEdit(){
		
		$result_datamenu['cat_menu'] 		= 'setting/subjectList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า วิชา';
		$result_datamenu['subcat_menu'] 	= 'subjectCreate';
		$result_datamenu['subcat_menu_th'] 	= 'เพิ่มวิชา';
		$result_datamenu['active'] 			= 'subject';
		$result_datamenu['sub_active'] 		= 'subject';

		$data_menu['data_menu'] = $result_datamenu;

		$subjectType = $this->setting_model->getSubjectTypeList();
		$subjectGroup = $this->setting_model->getSubjectGroupList();

		
		$data['subjectTypeList'] = $subjectType;
		$data['subjectGroupList'] = $subjectGroup;

		$temp_educationList = $this->setting_model->getEducationList();
		if($temp_educationList)
		{
			$educationList = $temp_educationList->body;
		}
		else $educationList = NULL;
		$temp_educationSubList = $this->setting_model->getEducationSubList();
		if($temp_educationSubList)
		{
			$educationSubList = $temp_educationSubList->body;
		}
		else $educationSubList = NULL;

		$data['educationList'] = $educationList;
		$data['educationSubList'] = $educationSubList;

		
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'subject_create',$data, true);
		$this->master_layout();
	}

	public function activityUpdate(){
		
		$create_by = $this->session->userdata['login_id'];
		
		$data = new stdClass(); 
		$data->subject_group_id = check_empty($_POST['subjectGroup']);
        $data->subject_type_id = check_empty($_POST['subjectType']);
        $data->education_level_id = check_empty($_POST['education']);
        $data->education_sublevel_id = check_empty($_POST['educationSub']);
        $data->subject_id = check_empty($_POST['code']);
        $data->name_th = check_empty($_POST['name_th']);
        $data->name_en = check_empty($_POST['name_en']);
		$data->unit = check_empty($_POST['unit']);
		$data->created_by = $create_by;

		$result = $this->setting_model->AddSubject($data);
		
		if($result)
		{
			return true;
		}
		else return false;
		
	}
	*/
	//--------------------------- Activity ----------------------------//
	//------------------------ Education 6 ---------------------- --//
	public function educationSixList(){
		
		$result_datamenu['cat_menu'] 		= 'setting/educationSixList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า นักเรียนประถมศึกษาปีที่ 6';
		$result_datamenu['subcat_menu'] 	= 'educationSixList';
		$result_datamenu['subcat_menu_th'] 	= 'นักเรียนประถมศึกษาปีที่ 6';
		$result_datamenu['active'] 			= 'educationSix';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$roomList = $this->setting_model->getOnetRoomList();
		if($roomList)
		{
			$data['roomList'] = $roomList;
			$room_id = $roomList[0]->id;

			$studentList = $this->setting_model->getOnetStudentList($room_id);
			$data['studentList'] = $studentList;
		}
		else 
		{
			$data['roomList'] = NULL;
			$data['studentList'] = NULL;
		}	
		
		$onetList = $this->setting_model->getOnetList(0,2,0);
		if($roomList)
		{
			$data['onetList'] = $onetList->body;
		}
		else $data['onetList'] = NULL;
		
		//console($data);		
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'educationSix_list',$data, true);
		$this->master_layout();
		
	}

	public function educationSixLoad()
	{
		$room_id = $_POST['room_id'];
		
		$studentList = $this->setting_model->getOnetStudentList($room_id);
		$data['studentList'] = $studentList;
		
		console($data);

		//$this->load->view('educationSix_load',$data);
		
	}

	public function getStudentOnetScore()
	{
		$student_id = $_POST['student_id'];
		$academic_year = $_POST['academic_year'];
		
		$onetScore = $this->setting_model->getStudentOnetScore($student_id,$academic_year);
		$data['onetScore'] = $onetScore;
		$data['academic_year'] = $academic_year;
		$data['student_id'] = $student_id;
 		
		$this->load->view('educationSix_onet',$data);
		
	}

	public function updateOnetScore($student_id,$academic_year)
	{
		$create_by = $this->session->userdata['login_id'];

		foreach($_POST as $key => $value)
		{
			$data = new stdClass();
			$data->academic_year = $academic_year;
			$data->student_id = $student_id;
			$data->subject_id = $key;
			$data->score = $value;
			$data->created_by = $create_by;
			
			$result = $this->setting_model->updateOnetScore($data);
		
			$url = $_SERVER['HTTP_REFERER'];
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
	}

	public function getStudentEvaluation()
	{
		$student_id = $_POST['student_id'];
		$academic_year = $_POST['academic_year'];
		
		$evalution = $this->setting_model->getStudentEvaluation($student_id,$academic_year);
		$data['evalution'] = $evalution;
		$data['academic_year'] = $academic_year;
		$data['student_id'] = $student_id;
 		
		$this->load->view('educationSix_evalution',$data);
		
		
	}

	public function updateEvalution($student_id,$academic_year)
	{
			$create_by = $this->session->userdata['login_id'];

			$data = new stdClass();
			$data->academic_year = $academic_year;
			$data->student_id = $student_id;
			$data->basic_subject_evaluation = $_POST['basic_subject_evaluation'];
			$data->attitude_evaluation = $_POST['attitude_evaluation'];
			$data->basic_subject_decision = $_POST['basic_subject_decision'];
			$data->attitude_decision = $_POST['attitude_decision'];
			$data->reading_evaluation = $_POST['reading_evaluation'];
			$data->activity_evaluation = $_POST['activity_evaluation'];
			$data->reading_decision = $_POST['reading_decision'];
			$data->activity_decision = $_POST['activity_decision'];
			$data->created_by = $create_by;
			
			$result = $this->setting_model->updateEvalution($data);
		
			$url = $_SERVER['HTTP_REFERER'];
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
	}
	//------------------------ Education 6 ---------------------- --//
}
