<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Personnel extends MY_Controller {

    function __construct() {
		parent::__construct();

		if(!isset($this->session->userdata['login_id'])){
			redirect('login', 'refresh');
		}

		$this->load->model('personnel_model');
		$this->load->model('setting_model');
	}
	
	//--------------------------- AcademicYear ----------------------------//

    public function profile($personnel_id){
		
		$result_datamenu['cat_menu'] 		= '';
		$result_datamenu['cat_menu_th'] 	= 'ข้อมูล ครู';
		$result_datamenu['subcat_menu'] 	= 'personnelProfile';
		$result_datamenu['subcat_menu_th'] 	= 'รายละเอียด ครู';
		$result_datamenu['active'] 			= 'personnel-profile';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;
		$data['personnel_id'] = $personnel_id;

		$result = $this->personnel_model->getPersonnelProfile($personnel_id);
		$data['profile'] = $result[0];

		/*
		$studentList = $this->classroom_model->getStudentList($academicYearNow,$classroom_id,$term_id);
		$data['studentList'] = $studentList;
		*/

		//console($data);
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'personnel/personnelProfile',$data, true);
		$this->master_layout();
	}

	public function searchStudent()
	{
		$keysearch = check_empty($_POST['keysearch']);
		$classroom_id = check_empty($_POST['classroom_id']);

		$student = $this->classroom_model->searchStudent($keysearch);
		$data['student'] = $student;
		$data['classroom_id'] = $classroom_id;

		$this->load->view ('classroom_profile_load',$data);
		
	}

	public function addStudent()
	{
		$student_id = check_empty($_POST['student_id']);
		$classroom_id = check_empty($_POST['classroom_id']);

		$all_student = array();
		$all_student[] = $student_id;

		$data = new stdClass(); 
		$data->classroom_id = $classroom_id;
		$data->student_id = $all_student;

		$student = $this->classroom_model->addStudent($data);

	}

	public function list()
	{
		if(isset($_GET['status'])&&!empty($_GET['status']))
		{
			$alert = $_GET['status'];
			$data['alert'] = $alert;
		}	
		else $data['alert'] = '';
		
		if(isset($_GET['search'])&&!empty($_GET['search']))
		$keysearch = $_GET['search']; else $keysearch = '';

		$data['search'] = $keysearch;

		$result_datamenu['cat_menu'] 		= 'setting/personnelList';
		$result_datamenu['cat_menu_th'] 	= 'ตั้งค่า บุคลากร';
		$result_datamenu['subcat_menu'] 	= 'personnelList';
		$result_datamenu['subcat_menu_th'] 	= 'รายชื่อบุคลากร';
		$result_datamenu['active'] 			= 'personnel';
		$result_datamenu['sub_active'] 		= 'personnelList';

		$personnelGroup = $this->setting_model->getPersonnelGroupList();
		$permission= $this->setting_model->getPermissionList();

		$data['personnelGroupList'] = $personnelGroup;
		$data['permissionList'] = $permission;

		
		$data_menu['data_menu'] = $result_datamenu;

		if($keysearch!='')
		{
			$result = $this->setting_model->getPersonnelSearch($keysearch);
			
			
		}
		else $result = $this->setting_model->getPersonnelList(1,0,0);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		//console($data);
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'personnel/personnelList',$data, true);
		$this->master_layout();
		
	}

	public function listLoad()
	{
		$personnelGroup = $_POST['personnelGroup'];
		$permission = $_POST['permission'];
		$page = $_POST['page'];

		//personnel/list/1/20/desc?permission=1&position=1&search=0818305533
		$result = $this->setting_model->getPersonnelList($page,$personnelGroup,$permission);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		
		$this->load->view ('personnel/personnelList_load',$data);
		
	}

	public function loadEducationSub()
	{
		$education = $_POST['education'];
		$data['academicYearNow'] = $_POST['academic_year'];
		$data['term_id'] = $_POST['term_id'];
		
		$result = $this->setting_model->getEducationSubByEducation($education);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		$this->load->view ('classroom/educationsubLoad',$data);
		
	}

	public function loadRoom()
	{
		$academic_year = $_POST['academic_year'];
		$term_id = $_POST['term_id'];
		$education = $_POST['education'];
		$educationSub = $_POST['educationSub'];

		$data['academicYearNow'] = $_POST['academic_year'];
		$data['term_id'] = $_POST['term_id'];

		$result = $this->setting_model->getClassroomRoom($academic_year,$term_id,$education,$educationSub);
		//console($result);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		$this->load->view ('classroom/roomLoad',$data);
		
	}


	
	public function setSubject($personnel_id)
	{
		$result_datamenu['cat_menu'] 		= '';
		$result_datamenu['cat_menu_th'] 	= 'ข้อมูล ครู';
		$result_datamenu['subcat_menu'] 	= 'personnelProfile';
		$result_datamenu['subcat_menu_th'] 	= 'จัดการวิชา ครู';
		$result_datamenu['active'] 			= 'personnel-setting-subject';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;
		$data['personnel_id'] = $personnel_id;

		$result = $this->personnel_model->getPersonnelProfile($personnel_id);
		$data['subjectList'] = $result[0]->subject;

		//console($data);
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'personnel/setSubject',$data, true);
		$this->master_layout();
	}

	public function updateMiniProfile()
	{
		$create_by = $this->session->userdata['login_id'];
		
		$data = new stdClass(); 
		$data->id = $_POST['id'];
		$data->firstname_th = check_empty($_POST['name']);
        $data->lastname_th = check_empty($_POST['lastname']);
        $data->cell_phone = check_empty($_POST['cellphone']);
        $data->email = check_empty($_POST['email']);
        $data->lastupdated_by = $create_by;
		
		$result = $this->setting_model->UpdatePersonnel($data);

		//echo $result;
	}

	public function subject($personnel_id=NULL){
		
		$result_datamenu['cat_menu'] 		= '';
		$result_datamenu['cat_menu_th'] 	= 'ข้อมูล ครู';
		$result_datamenu['subcat_menu'] 	= 'subject';
		$result_datamenu['subcat_menu_th'] 	= 'วิชาและห้องที่สอน';
		$result_datamenu['active'] 			= 'personnel-subject';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;
		$data['personnel_id'] = $personnel_id;

		$result = $this->personnel_model->getPersonnelSubject($personnel_id);
		$data['profile'] = $result;


		/*
		$result = $this->personnel_model->getPersonnelProfile($personnel_id);
		$data['profile'] = $result[0];

		
		$studentList = $this->classroom_model->getStudentList($academicYearNow,$classroom_id,$term_id);
		$data['studentList'] = $studentList;
		*/

		//console($data);
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'personnel/subject',$data, true);
		$this->master_layout();
	}

	
	
}
