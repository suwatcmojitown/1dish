<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Hr extends MY_Controller {

    function __construct() {
		parent::__construct();

		if(!isset($this->session->userdata['login_id'])){
			redirect('login', 'refresh');
		}

		$this->load->model('classroom_model');
		$this->load->model('setting_model');
		$this->load->model('timesheet_model');
		$this->load->model('student_model');

		$this->load->model('hr_model');
	}
	
	//--------------------------- AcademicYear ----------------------------//

	public function createEvent()
	{
		if(isset($_GET['keysearch'])&&!empty($_GET['keysearch']))
		{
			$keysearch = check_empty($_GET['keysearch']);
		}else $keysearch = '';

		if(isset($_GET['status'])&&!empty($_GET['status']))
		{
			$alert = $_GET['status'];
			$data['alert'] = $alert;
		}	
		else $data['alert'] = '';
		
		$result_datamenu['cat_menu'] 		= 'hr/createEvent';
		$result_datamenu['cat_menu_th'] 	= 'จัดการเวลานักเรียน';
		$result_datamenu['subcat_menu'] 	= 'list';
		$result_datamenu['subcat_menu_th'] 	= '<i class="fa fa-clock-o"></i> แจ้ง สาย/กลับก่อนเวลา';
		$result_datamenu['active'] 			= 'hr';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;
		
		$temp_academicYearNow = $this->setting_model->getAcademicYearNow();
		//console($temp_academicYearNow);
		$academicYearNow = $temp_academicYearNow->academic_year;;
		$term_id = $temp_academicYearNow->term_id;

		if($keysearch!='')$result = $this->student_model->searchStudent($academicYearNow,$term_id,$keysearch);
		else $result = null;
		
		$data['list'] = $result;
		$data['keysearch'] = $keysearch; 

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'hr/createEvent',$data, true);
		$this->master_layout();
	}

	public function AddEvent()
	{
		
		$create_by = $this->session->userdata['login_id'];
		
		$data = new stdClass(); 
		$data->student_id = $_POST['student_id'];
		$data->date_time = $_POST['date_time'];
		$data->description = $_POST['description'];
		$data->is_parent = $_POST['is_parent'];
		$data->lastupdated_by = $create_by;
		$data->status = $_POST['status'];
		
		$result = $this->hr_model->addEvent($data);
		
		if($result)
		{
			$url = base_url('hr/createEvent?status=success');
			
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}else
		{
			$url = base_url('hr/createEvent?status=error');
			
			echo "<script type='text/javascript'>
			location.href = '" . $url . "';
			</script>";
		}
	}

	public function AddEventTimesheet()
	{
		date_default_timezone_set("Asia/Bangkok");

		$create_by = $this->session->userdata['login_id'];
		
		$date = $_POST['date'];
		$time = $_POST['time'];
		if($date=='now')
		{
			$date_time = date('Y.m.d').' '.$time;
		}
		else
		{
			$date_time = $date.' '.$time;
		}	

		$data = new stdClass(); 
		$data->student_id = $_POST['student_id'];
		$data->date_time = $date_time;
		$data->description = $_POST['description'];
		$data->is_parent = $_POST['is_parent'];
		$data->type_check = $_POST['type_check'];
		$data->lastupdated_by = $create_by;
		$data->status = $_POST['status'];
		
		
		$result = $this->hr_model->addEvent($data);
		
		if($result)
		{
			echo true;
		}else
		{
			echo false;
		}
		
	}
	
}
