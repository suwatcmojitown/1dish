<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Device extends MY_Controller {

    function __construct() {
		parent::__construct();

		if(!isset($this->session->userdata['login_id'])){
			redirect('login', 'refresh');
		}

		$this->load->model('device_model');
	}
	
	//--------------------------- AcademicYear ----------------------------//

	public function list()
	{
		
		$result_datamenu['cat_menu'] 		= 'device/list';
		$result_datamenu['cat_menu_th'] 	= 'Health Check';
		$result_datamenu['subcat_menu'] 	= 'list';
		$result_datamenu['subcat_menu_th'] 	= '<i class="fa fa-h-square"></i> รายการ เครื่องสแกนบัตร';
		$result_datamenu['active'] 			= 'device';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;
		
		$result = $this->device_model->getStatus();
		
		$data['result'] = $result;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'device/list',$data, true);
		$this->master_layout();
	}

	public function load()
	{
		$result = $this->device_model->getStatus();
		
		$data['result'] = $result;

		$this->load->view ('device/load',$data);
	}

	
}
