<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends MY_Controller {

    function __construct() {
		parent::__construct();

		if(!isset($this->session->userdata['login_id'])){
			redirect('login', 'refresh');
		}

		$this->load->model('classroom_model');
		$this->load->model('setting_model');
		$this->load->model('timesheet_model');
		$this->load->model('student_model');
		$this->load->model('hr_model');
		$this->load->model('personnel_model');
	}
	
	//--------------------------- AcademicYear ----------------------------//

	public function index()
	{
		//console($this->session->userdata);

		date_default_timezone_set("Asia/Bangkok");

		$result_datamenu['cat_menu'] 		= 'dashboard';
		$result_datamenu['cat_menu_th'] 	= '';
		$result_datamenu['subcat_menu'] 	= 'list';
		$result_datamenu['subcat_menu_th'] 	= '<i class="fa fa-book"></i> Dashboard';
		$result_datamenu['active'] 			= 'dashboard';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;
		
		//console($this->session->userdata);

		$personnel_id = $this->session->userdata['personnel_id'];
		//$personnel_id = 46;
		$result = $this->personnel_model->getPersonnelProfile($personnel_id);
		//console($result);
		if(isset($result[0]->classroom)&&!empty($result[0]->classroom))
		{
			$classroomList = $result[0]->classroom;
			$room_name = $classroomList[0]->education_sublevel_name_th.' ห้อง '.$classroomList[0]->room;
			$data['room_name'] = $room_name;
			$data['date'] = date('d-m-Y');
			$room = $classroomList[0]->id; 
			$educationSub = $classroomList[0]->education_sublevel_id;
			
			$timesheet = $this->timesheet_model->getTimesheetList($educationSub,$room,date('Y-m-d'));
			$data['timesheet'] = $timesheet;
		}
		else
		{
			$data['room_name'] = NULL;
			$data['date'] = NULL;
			$data['timesheet'] = NULL;
		}
		
		//console($data);
		
		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'dashboard/dashboard',$data, true);
		$this->master_layout();
	}

	
}
