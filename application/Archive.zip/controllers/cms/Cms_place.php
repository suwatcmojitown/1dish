<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cms_place extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ('Cms_place' !== 'Cms_auth') {
            $this->checkCmsAuth();
        }
        $this->load->model('Place_model');
        $this->load->model('Review_model');
        $this->load->model('User_model');
        $this->load->model('Influencer_model');
        $this->load->model('Comment_model');
        $this->load->model('Lookup_model');
    }
}
