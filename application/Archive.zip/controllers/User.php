<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('User_model');
	}

	public function login()
	{
		//test();
		$this->load->view('user/login');
	}

	public function validlogin()
	{
		$result = $this->User_model->fetch_user_login($this->input->post('username'), $this->input->post('password'));
		//console($result);
		if($result)
		{
			$this->session->set_userdata(
				array('login_id'    => $result->id,
					  'username'    => $this->input->post('username'),
					  'name' => $result->name_title_th.' '.$result->firstname_th.' '.$result->lastname_th,
					  'role'=> $result->permission_title,
					  'permission_id' =>$result->permission_id,
					  'personnel_id' =>$result->id,
					  'token' =>$result->token,
					  'thumbnail' => $result->profile_ing_url
			  ));
			redirect(base_url().'dashboard');
		}	
		else
		{
			redirect('user/login', 'refresh');
		}	
				
		/*
		if($this->input->server('REQUEST_METHOD') == TRUE){
			if($this->User_model->record_count($this->input->post('username'), $this->input->post('password')) == 1)
			{

				$result = $this->User_model->fetch_user_login($this->input->post('username'), $this->input->post('password'));
				$this->session->set_userdata(
				  array('login_id'    => $result->id,
						'username'    => $result->username,
						'display_name'=> $result->display_name
				));
				//redirect('order');
				
			}
			else
			{
				$this->session->set_flashdata(array('msgerr'=> '<p class="login-box-msg" style="color:red;">ชื่อผู้ใช้หรือรหัสผ่านผิดพลาด!</p>'));
				redirect('user/login', 'refresh');
			}
		}
		*/
	}

	public function logout()
	{
		$this->session->unset_userdata(
			array('login_id','username','name','role','permission_id','token','thumbnail'
			)
		);
		redirect(base_url().'login', 'refresh');
	}

	public function profile()
	{
		$data['result'] = $this->User_model->read_user($this->session->userdata('login_id'));
		$this->load->view('user/profile',$data);
	}

	public function postprofile()
	{
		if($this->input->server('REQUEST_METHOD') == TRUE)
		{
			$this->form_validation->set_rules('display_name', 'ชื่อแสดง', 'required', array('required'=> 'ค่าห้ามว่าง!'));
			if($this->User_model->record_count($this->input->post('username'),$this->input->post('password')) == 1 && $this->form_validation->run() == TRUE){
				$this->User_model->entry_user($this->session->userdata('login_id'));
				$this->session->set_userdata(array('display_name'=>$this->input->post('display_name')));
				redirect('admin','refresh');  //ให้วิ่งไปหน้านีหน้าแรก สำหรับ admin 
			}else{
				redirect('user/profile','refresh');
			}
		}

	}

	public function changePassword()
	{
		$this->load->view('user/changePassword');
	}
}