<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Classroom extends MY_Controller {

    function __construct() {
		parent::__construct();

		if(!isset($this->session->userdata['login_id'])){
			redirect('login', 'refresh');
		}

		$this->load->model('classroom_model');
		$this->load->model('setting_model');
	}
	
	//--------------------------- AcademicYear ----------------------------//

    public function classroomProfile($classroom_id){
		
		$result_datamenu['cat_menu'] 		= 'classroom/list';
		$result_datamenu['cat_menu_th'] 	= 'ข้อมูล ห้องเรียน';
		$result_datamenu['subcat_menu'] 	= 'classroomProfile';
		$result_datamenu['subcat_menu_th'] 	= 'รายละเอียด ห้องเรียน';
		$result_datamenu['active'] 			= 'classroom-profile';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;
		$data['classroom_id'] = $classroom_id;

		$temp_academicYearNow = $this->setting_model->getAcademicYearNow();
		$academicYearNow = $temp_academicYearNow->academic_year;
		$term_id = $temp_academicYearNow->term_id;
		$data['academicYearNow'] = $academicYearNow;
		$data['term_id'] = $term_id;

		$result = $this->classroom_model->getClassroomProfile($academicYearNow,$classroom_id);
		$data['profile'] = $result[0];

		$studentList = $this->classroom_model->getStudentList($academicYearNow,$classroom_id,$term_id);
		$data['studentList'] = $studentList;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'classroom/classroom_profile',$data, true);
		$this->master_layout();
	}

	public function searchStudent()
	{
		$keysearch = check_empty($_POST['keysearch']);
		$classroom_id = check_empty($_POST['classroom_id']);

		$student = $this->classroom_model->searchStudent($keysearch);
		$data['student'] = $student;
		$data['classroom_id'] = $classroom_id;

		$this->load->view ('classroom_profile_load',$data);
		
	}

	public function addStudent()
	{
		$student_id = check_empty($_POST['student_id']);
		$classroom_id = check_empty($_POST['classroom_id']);

		$all_student = array();
		$all_student[] = $student_id;

		$data = new stdClass(); 
		$data->classroom_id = $classroom_id;
		$data->student_id = $all_student;

		$student = $this->classroom_model->addStudent($data);

	}

	public function list()
	{
		$result_datamenu['cat_menu'] 		= 'classroom/list';
		$result_datamenu['cat_menu_th'] 	= 'ข้อมูล ห้องเรียน';
		$result_datamenu['subcat_menu'] 	= 'list';
		$result_datamenu['subcat_menu_th'] 	= 'รายชื่อ ห้องเรียน';
		$result_datamenu['active'] 			= 'classroom-profile';
		$result_datamenu['sub_active'] 		= '';

		$data_menu['data_menu'] = $result_datamenu;

		$temp_academicYearNow = $this->setting_model->getAcademicYearNow();
		$academicYearNow = $temp_academicYearNow->academic_year;
		$term_id = $temp_academicYearNow->term_id;
		$data['academicYearNow'] = $academicYearNow;
		$data['term_id'] = $term_id;

		$academicYearList = $this->setting_model->getAcademicYearList();
		$temp_educationList = $this->setting_model->getEducationList();
		if($temp_educationList)
		{
			$educationList = $temp_educationList->body;
		}
		else $educationList = NULL;
		$temp_educationSubList = $this->setting_model->getEducationSubList();
		if($temp_educationSubList)
		{
			$educationSubList = $temp_educationSubList->body;
		}
		else $educationSubList = NULL;

		$data['educationList'] = $educationList;
		$data['educationSubList'] = $educationSubList;

		
		$temp_result = $this->setting_model->getClassroomList($academicYearNow,$term_id);
		if($temp_result)
		{
			$result = $temp_result->body;
		}
		else $result = NULL;
		$data['result'] = $result;

		$this->template['menu'] = $this->load->view ($this->menu = 'menu',$data_menu, true);
		$this->template['content'] = $this->load->view ($this->middle = 'classroom/classroomList',$data, true);
		$this->master_layout();
		
	}

	public function listLoad()
	{
		$academicYearNow = $_POST['academic_year'];
		$term_id = $_POST['term_id'];
		$education = $_POST['education'];
		$educationSub = $_POST['educationSub'];
		$room = $_POST['room'];

		$result = $this->setting_model->getClassroomList($academicYearNow,$term_id,$education,$educationSub,$room);
		if($result)
		{
			$data['result'] = $result->body;
		}
		else
		{
			$data['result'] = NULL;
		}
		$this->load->view ('classroom/classroomList_load',$data);
	}

	public function loadEducationSub()
	{
		$education = $_POST['education'];
		$data['academicYearNow'] = $_POST['academic_year'];
		$data['term_id'] = $_POST['term_id'];
		
		$result = $this->setting_model->getEducationSubByEducation($education);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		$this->load->view ('classroom/educationsubLoad',$data);
		
	}

	public function loadRoom()
	{
		$academic_year = $_POST['academic_year'];
		$term_id = $_POST['term_id'];
		$education = $_POST['education'];
		$educationSub = $_POST['educationSub'];

		$data['academicYearNow'] = $_POST['academic_year'];
		$data['term_id'] = $_POST['term_id'];

		$result = $this->setting_model->getClassroomRoom($academic_year,$term_id,$education,$educationSub);
		//console($result);
		if($result)
		{
			$data['result'] = $result->body;
			$data['page'] = $result->header;
		}
		else
		{
			$data['result'] = NULL;
			$data['page'] = NULL;
		}
		$this->load->view ('classroom/roomLoad',$data);
		
	}

	
}
