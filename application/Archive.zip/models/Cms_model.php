<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Cms_model extends CI_Model {

        
        public function createCategory($name,$name_en,$slug,$description,$description_en,$status,$code_color,$is_main,$thumbnail)
        {
                $this->cat_name         = $name;
                $this->cat_name_en      = $name_en;
                $this->slug             = $slug;
                $this->thumbnail        = $thumbnail;
                $this->description      = $description;
                $this->description_en   = $description_en;
                $this->status           = $status;
                $this->cat_home         = $is_main;
                $this->color            = $code_color;

                $this->db->insert('category', $this);
        }

        public function getCategoryBySlug($slug=NULL)
        {
                $query = $this->db->query("
                        SELECT cat_id,cat_name,slug
                        FROM category 
                        WHERE slug = '$slug' AND status=1
                        ;");
                $object = $query->result_array();

                return $object;
        }

        public function getTotalCategory($id)
        {
                if($id=='0')
                {
                        $query = $this->db->query("
                        SELECT count(cat_id) as total
                        FROM category
                        ;");
                }else
                {
                        $query = $this->db->query("
                        SELECT count(cat_id) as total
                        FROM category
                        WHERE cat_id = $id AND category.cat_home=0 
                        ;");       
                } 
                
                $object = $query->result_array();  

                return $object[0]['total'];
        }

        public function getCategoryList($id,$limit,$offset)
        {
                if($id=='0')
                {
                        $query = $this->db->query("
                        SELECT cat_id,cat_name,slug,status,cat_home
                        FROM category 
                        WHERE status=1
                        LIMIT $limit OFFSET $offset
                        ;");
                }
                else
                {
                        $query = $this->db->query("
                        SELECT cat_id,cat_name,slug,status,cat_home
                        FROM category 
                        WHERE cat_id = $id AND status=1
                        LIMIT $limit OFFSET $offset
                        ;");
                }
                
                $object = $query->result_array();

                return $object;  
        }

        public function getCatList()
        {
                $query = $this->db->query("
                        SELECT cat_id,cat_name,slug
                        FROM category 
                        ;");
                $object = $query->result_array();
                
                return $object;  
        }

        public function getContactList($id,$limit,$offset)
        {
                $query = $this->db->query("
                        SELECT ct.contact_id,cat.cat_name
                        FROM contact as ct
                        INNER JOIN category AS cat ON cat.cat_id = ct.cat_id
                        LIMIT $limit OFFSET $offset
                        ;");
                $object = $query->result_array();

                return $object;  
        }

        public function createContact($category,$address,$address_en,$phone,$email,$facebook,$description,$description_en,$status)
        {
                $this->cat_id           = $category;
                $this->address          = $address;
                $this->address_en       = $address_en;
                $this->phone            = $phone;
                $this->email            = $email;
                $this->facebook         = $facebook;
                $this->description      = $description;
                $this->description_en   = $description_en;
                $this->status           = $status;

                $this->db->insert('contact', $this);
        }

        public function getSubcatList()
        {
                $query = $this->db->query("
                        SELECT cat_id,cat_name,slug
                        FROM category 
                        WHERE cat_home = 0
                        ;");
                $object = $query->result_array();
                
                return $object;  
        }

        public function getCategoryTemplateList($id,$limit,$offset)
        {
                $query = $this->db->query("
                        SELECT ct.category_template_id,cat.cat_name
                        FROM category_template as ct
                        INNER JOIN category AS cat ON cat.cat_id = ct.cat_id
                        WHERE cat_home = 0 
                        LIMIT $limit OFFSET $offset
                        ;");
                $object = $query->result_array();

                return $object;  
        }

        public function createCategoryTemplate($category,$description,$description_en,$code_color,$tools,$tools_en,$service,$service_en,$rate,$rate_en,$status,$thumbnail)
        {
                $this->cat_id           = $category;
                $this->description      = $description;
                $this->description_en   = $description_en;
                $this->cat_color        = $code_color;
                $this->tools            = $tools;
                $this->tools_en         = $tools_en;
                $this->service          = $service;
                $this->service_en       = $service_en;
                $this->rate             = $rate;
                $this->rate_en          = $rate_en;
                $this->status           = $status;
                $this->thumbnail        = $thumbnail;

                $this->db->insert('category_template', $this);
        }
        
        public function getHighlightList()
        {
                $query = $this->db->query("
                        SELECT highlight_id,title,thumbnail,link,status
                        FROM highlight
                        ;");
                $object = $query->result_array();

                return $object;  
        }

        public function createHighlight($title,$title_en,$description,$description_en,$link,$status,$thumbnail,$is_service)
        {
                $this->title           = $title;
                $this->title_en          = $title_en;
                $this->description       = $description;
                $this->description_en            = $description_en;
                $this->link            = $link;
                $this->thumbnail         = $thumbnail;
                $this->status           = $status;
                $this->is_service           = $is_service;

                $this->db->insert('highlight', $this);
        }

        public function getTotalPersonnel($id)
        {
                if($id=='0')
                {
                        $query = $this->db->query("
                        SELECT count(personnel_id) as total
                        FROM personnel
                        ;");
                }else
                {
                        $query = $this->db->query("
                        SELECT count(personnel_id) as total
                        FROM personnel
                        WHERE cat_id = $id 
                        ;");       
                } 
                
                $object = $query->result_array();  

                return $object[0]['total'];
        }

        public function getPersonnelList($id,$limit,$offset)
        {
                if($id=='0')
                {
                        $query = $this->db->query("
                        SELECT p.personnel_id,p.name,p.rank,p.thumbnail,p.rank_order,
                                cat.cat_name,p.status                        
                        FROM personnel AS p
                        INNER JOIN category AS cat ON cat.cat_id = p.cat_id 
                        LIMIT $limit OFFSET $offset
                        ;");
                }
                else
                {
                        $query = $this->db->query("
                        SELECT p.personnel_id,p.name,p.rank,p.thumbnail,p.rank_order,
                                cat.cat_name,p.status                        
                        FROM personnel AS p
                        INNER JOIN category AS cat ON cat.cat_id = p.cat_id 
                        WHERE p.cat_id = $id 
                        LIMIT $limit OFFSET $offset
                        ;");
                }
                
                $object = $query->result_array();

                return $object;  
        }

        public function createPersonnel($name,$rank,$category,$rank_order,$status,$thumbnail)
        {
                $this->name           = $name;
                $this->rank          = $rank;
                $this->cat_id       = $category;
                $this->rank_order            = $rank_order;
                $this->thumbnail         = $thumbnail;
                $this->status           = $status;
                
                $this->db->insert('personnel', $this);
        }

        public function getNoticeList($id,$limit,$offset)
        {
                if($id=='0')
                {
                        $query = $this->db->query("
                        SELECT  n.notice_id,n.title,n.doc,n.status, 
                                cat.cat_name,d.title as doc_title,dt.name as doctype_name,dp.name as department_name
                        FROM notice AS n
                        LEFT JOIN category AS cat ON cat.cat_id = n.cat_id
                        LEFT JOIN document AS d ON d.doc_id = n.doc_id 
                        LEFT JOIN doc_type AS dt ON dt.type_id = n.type_id
                        LEFT JOIN department AS dp ON dp.department_id = n.department_id   
                        LIMIT $limit OFFSET $offset
                        ;");
                }
                else
                {
                        $query = $this->db->query("
                        SELECT  n.notice_id,n.title,n.doc,n.status, 
                                cat.cat_name,d.title as doc_title,dt.name as doctype_name,dp.name as department_name
                        FROM notice AS n
                        LEFT JOIN category AS cat ON cat.cat_id = n.cat_id
                        LEFT JOIN document AS d ON d.doc_id = n.doc_id 
                        LEFT JOIN doc_type AS dt ON dt.type_id = n.type_id
                        LEFT JOIN department AS dp ON dp.department_id = n.department_id 
                        WHERE n.cat_id = $id 
                        LIMIT $limit OFFSET $offset
                        ;");
                }
                
                $object = $query->result_array();

                return $object;  
        }

        public function getTotalNotice($id)
        {
                if($id=='0')
                {
                        $query = $this->db->query("
                        SELECT count(notice_id) as total
                        FROM notice
                        ;");
                }else
                {
                        $query = $this->db->query("
                        SELECT count(notice_id) as total
                        FROM notice
                        WHERE cat_id = $id 
                        ;");       
                } 
                
                $object = $query->result_array();  

                return $object[0]['total'];
        }

        public function getDocList()
        {
                $query = $this->db->query("
                        SELECT doc_id,title,is_type,slug
                        FROM document
                        WHERE status = 1
                        ;");
                $object = $query->result_array();

                return $object;        
        }

        public function getDocTypeList($id)
        {
                if($id==0)
                {
                        $query = $this->db->query("
                        SELECT type_id,name,is_department
                        FROM doc_type
                        WHERE status = 1
                        ;");
                }else
                {
                        $query = $this->db->query("
                        SELECT type_id,name,is_department
                        FROM doc_type
                        WHERE doc_id = $id AND status = 1
                        ;");
                }
                
                $object = $query->result_array();

                return $object;        
        }

        public function getDepartmentList($id)
        {
                if($id==0)
                {
                        $query = $this->db->query("
                        SELECT department_id,name
                        FROM department
                        WHERE status = 1
                        ;");
                }else
                {
                        $query = $this->db->query("
                        SELECT department_id,name
                        FROM department
                        WHERE type_id = $id AND status = 1
                        ;");
                }        
                $object = $query->result_array();

                return $object;        
        }

        public function istype_doc($id)
        {
                $query = $this->db->query("
                SELECT is_type
                FROM document
                WHERE doc_id = $id
                ;");      
                
                $object = $query->result_array();

                return $object[0]['is_type'];        
        }

        public function istype_department($id)
        {
                $query = $this->db->query("
                SELECT is_department
                FROM doc_type
                WHERE type_id = $id
                ;");      
                
                $object = $query->result_array();

                return $object[0]['is_department'];        
        }

        public function createNotice($title,$title_en,$doc,$cat_id,$doc_id,$type_id,$department_id,$status)
        {
                $this->title            = $title;
                $this->title_en         = $title_en;
                $this->doc              = $doc;
                $this->cat_id           = $cat_id;
                $this->doc_id           = $doc_id;
                $this->type_id          = $type_id;
                $this->department_id    = $department_id;
                $this->status           = $status;
                
                $this->db->insert('notice', $this);
        }

        public function createDocument($title,$slug,$cat_id,$is_type,$status)
        {
                $this->title            = $title;
                $this->slug             = $slug;
                $this->cat_id            = $cat_id;
                $this->is_type           = $is_type;
                $this->status           = $status;
                
                $this->db->insert('document', $this);
        }

        public function createDocType($title,$slug,$doc_id,$is_department,$status)
        {
                $this->name             = $title;
                $this->slug              = $slug;
                $this->doc_id            = $doc_id;
                $this->is_department     = $is_department;
                $this->status            = $status;
                
                $this->db->insert('doc_type', $this);
        }

        public function createDepartment($title,$slug,$type_id,$status)
        {
                $this->name             = $title;
                $this->slug              = $slug;
                $this->type_id            = $type_id;
                $this->status            = $status;
                
                $this->db->insert('department', $this);
        }

        public function getNewsTypeBySlug($slug=NULL)
        {
                $query = $this->db->query("
                        SELECT news_type_id as type_id,name,slug
                        FROM news_type 
                        WHERE slug = '$slug' AND status=1
                        ;");
                $object = $query->result_array();

                return $object;
        }

        public function getTotalNews($id)
        {
                if($id=='0')
                {
                        $query = $this->db->query("
                        SELECT count(news_id) as total
                        FROM news
                        ;");
                }else
                {
                        $query = $this->db->query("
                        SELECT count(news_id) as total
                        FROM news
                        WHERE news_type_id = $id 
                        ;");       
                } 
                
                $object = $query->result_array();  

                return $object[0]['total'];
        }

        public function getNewsList($id,$limit,$offset)
        {
                if($id=='0')
                {
                        $query = $this->db->query("
                        SELECT  n.news_id,n.title,n.title_en,n.thumbnail,n.status,n.recommend, 
                                nt.name
                        FROM news AS n
                        LEFT JOIN news_type AS nt ON nt.news_type_id = n.news_type_id
                        LIMIT $limit OFFSET $offset
                        ;");
                }
                else
                {
                        $query = $this->db->query("
                        SELECT  n.news_id,n.title,n.title_en,n.thumbnail,n.status,n.recommend, 
                                nt.name
                        FROM news AS n
                        LEFT JOIN news_type AS nt ON nt.news_type_id = n.news_type_id
                        WHERE n.news_type_id = $id
                        LIMIT $limit OFFSET $offset
                        ;");
                }
                
                $object = $query->result_array();

                return $object;  
        }

        public function getNewsTypeList()
        {
                
                $query = $this->db->query("
                        SELECT  news_type_id as type_id,name,slug
                        FROM news_type 
                        WHERE status = 1
                ;");
                
                
                $object = $query->result_array();

                return $object;  
        }

        public function createNews($name,$name_en,$category,$description,$description_en,$thumbnail,$status,$recommend)
        {
                $this->title               = $name;
                $this->title_en            = $name_en;
                $this->news_type_id        = $category;
                $this->description         = $description;
                $this->description_en      = $description_en;
                $this->thumbnail           = $thumbnail;
                $this->status              = $status;
                $this->recommend           = $recommend;
                
                $this->db->insert('news', $this);
        }

        public function getTotalProduct($id)
        {
                if($id=='0')
                {
                        $query = $this->db->query("
                        SELECT count(product_id) as total
                        FROM product
                        ;");
                }else
                {
                        $query = $this->db->query("
                        SELECT count(product_id) as total
                        FROM product
                        WHERE cat_id = $id 
                        ;");       
                } 
                
                $object = $query->result_array();  

                return $object[0]['total'];
        }

        public function getProductList($id,$limit,$offset)
        {
                if($id=='0')
                {
                        $query = $this->db->query("
                        SELECT  p.product_id,p.title,p.title_en,p.thumbnail,p.status,
                                pn.name as owner_name,cat.cat_name,pt.name as type_name
                        FROM product AS p
                        LEFT JOIN personnel AS pn ON pn.personnel_id = p.owner_id
                        LEFT JOIN category AS cat ON cat.cat_id = p.cat_id
                        LEFT JOIN product_type AS pt ON pt.type_id = p.product_type
                        LIMIT $limit OFFSET $offset
                        ;");
                }
                else
                {
                        $query = $this->db->query("
                        SELECT  p.product_id,p.title,p.title_en,p.thumbnail,p.status,
                                pn.name as owner_name,cat.cat_name,pt.name as type_name
                        FROM product AS p
                        LEFT JOIN personnel AS pn ON pn.personnel_id = p.owner_id
                        LEFT JOIN category AS cat ON cat.cat_id = p.cat_id
                        LEFT JOIN product_type AS pt ON pt.type_id = p.product_type
                        WHERE p.cat_id = $id
                        LIMIT $limit OFFSET $offset
                        ;");
                }
                
                $object = $query->result_array();

                return $object;  
        }

        public function getProductTypeList()
        {
                
                $query = $this->db->query("
                        SELECT  type_id,name,slug
                        FROM product_type 
                        WHERE status = 1
                ;");
                
                
                $object = $query->result_array();

                return $object;  
        }

        public function getOwner($id)
        {
                $query = $this->db->query("
                        SELECT  personnel_id,name
                        FROM personnel 
                        WHERE cat_id = $id AND status = 1
                ;");
                
                
                $object = $query->result_array();

                return $object;  
        }

        public function createProduct($title,$title_en,$product_type_id,$owner,$description,$description_en,$category,$status,$doc_name,$doc,$thumbnail)
        {
                $this->title               = $title;
                $this->title_en            = $title_en;
                $this->product_type        = $product_type_id;
                $this->owner_id         = $owner;
                $this->description      = $description;
                $this->description_en           = $description_en;
                $this->cat_id              = $category;
                $this->status           = $status;
                $this->doc_name           = $doc_name;
                $this->doc              = $doc;
                $this->thumbnail           = $thumbnail;
                
                $this->db->insert('product', $this);
        }

        

        

        

}