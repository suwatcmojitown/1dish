<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Timesheet_model extends CI_Model {

        public function getTimesheetList($educationSub=7,$room=1,$date='2019-10-22')
        {   
              $result = json_decode(callAPI('GET',PATH_API.'timesheetinfo/classroom?education_sublevel_id='.$educationSub.'&room='.$room.'&date='.$date.'',''));  
              //console($result);
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function deleteTimesheet($student_id,$date)
        {
                //echo PATH_API.'timesheetinfo/student/'.$student_id.'/'.$date.'';
                
                $result = json_decode(callAPI('DEL',PATH_API.'timesheetinfo/student/'.$student_id.'/'.$date.'',''));  
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
                
        }

        
        

}