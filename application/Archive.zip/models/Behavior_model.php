<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Behavior_model extends CI_Model {

        public function addEvent($data)
        {   
            $myJSON = json_encode($data); 
            $result = json_decode(callAPI('PUT',PATH_API.'behaviorpoint',$myJSON)); 
            if($result->header->res_code=='200')
            {
                    return true;
            }
            else return false;
            
        }

        
        

}