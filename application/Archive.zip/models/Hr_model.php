<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Hr_model extends CI_Model {

        public function getTimesheetList($educationSub=7,$room=1,$date='2019-10-22')
        {   
               $result = json_decode(callAPI('GET',PATH_API.'timesheetinfo/classroom?education_sublevel_id='.$educationSub.'&room='.$room.'&date='.$date.'',''));  
               //console($result);
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function addEvent($data)
        {   
            $myJSON = json_encode($data); 
            
            //console($data);
            $result = json_decode(callAPI('PUT',PATH_API.'timesheet',$myJSON)); 
            //console($result);
            if($result->header->res_code=='200')
            {
                    return true;
            }
            else return false;
            
        }

        
        

}