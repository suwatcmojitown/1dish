<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Device_model extends CI_Model {

        public function getStatus()
        {   
               $result = json_decode(callAPI('GET',PATH_API.'device/status',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        
        

}