<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Setting_model extends CI_Model {

        public function uploadPicture($file)
        {
                
                $data = new stdClass(); 
                $data->upload = $file; 
                $result = json_decode(callAPI('POST',PATH_API.'uploadimage','')); 
                if($result->header->res_code=='200')
                {
                        $object = $result->body;
                }
                else $object = NULL;
                
                return $object;
        }

        public function getAcademicYearNow()
        {
               
               $result = json_decode(callAPI('GET',PATH_API.'academicyear/current',''));  
               if($result->header->res_code=='200')
               {
                        $object = $result->body;
               }
               else $object = NULL;
               
               return $object;
               
        }

        public function getAllAcademicYearList()
        {
               $result = json_decode(callAPI('GET',PATH_API.'academicyear/asc',''));  
               
               if($result->header->res_code=='200')
               {
                        $object = $result->body;
               }
               else $object = NULL;
               
               return $object;
        }

        public function getAcademicYearList()
        {
               $result = json_decode(callAPI('GET',PATH_API.'academicyear/group',''));  
               
               if($result->header->res_code=='200')
               {
                        $object = $result->body;
               }
               else $object = NULL;
               
               return $object;
        }

        public function AddAcademicYear($name,$term_id,$startdate,$enddate,$create_by)
        {
                $data = new stdClass(); 
                $data->academic_year = $name;
                $data->term_id = $term_id;
                $data->begin_date = $startdate;
                $data->end_date = $enddate;
                $data->created_by = $create_by;
                
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('POST',PATH_API.'academicyear',$myJSON));  
               
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }

        

        public function getSubjectTypeList()
        {
               $result = json_decode(callAPI('GET',PATH_API.'subjecttype/desc',''));  
               //console($result);
               
               if($result->header->res_code=='200')
               {
                        $object = $result->body;
               }
               else $object = NULL;
               
               return $object;
        }

        public function AddSubjectType($name,$name_en,$create_by)
        {
                $data = new stdClass(); 
                $data->name_th = $name;
                $data->name_en = $name_en;
                $data->created_by = $create_by;
                
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('POST',PATH_API.'subjecttype',$myJSON));  
               
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }

        public function getSubjectGroupList()
        {
               $result = json_decode(callAPI('GET',PATH_API.'subjectgroup/desc',''));  
               
               if($result->header->res_code=='200')
               {
                        $object = $result->body;
               }
               else $object = NULL;
               
               return $object;
        }

        public function AddSubjectGroup($name,$name_en,$create_by)
        {
                $data = new stdClass(); 
                $data->name_th = $name;
                $data->name_en = $name_en;
                $data->created_by = $create_by;
                
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('POST',PATH_API.'subjectgroup',$myJSON));  
               
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }

        public function getSubjectList($subjectGroup=0,$subjectType=0,$educationSub=0,$page=1)
        {
               $limit = PAGE_LIMIT;
               $result = json_decode(callAPI('GET',PATH_API.'subject/list/filter/'.$subjectGroup.'/'.$subjectType.'/'.$educationSub.'/'.$page.'/'.$limit.'',''));  
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function getSubjectProfile($id=NULL)
        {
               $result = json_decode(callAPI('GET',PATH_API.'subject/detail/'.$id.'',''));  
               
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function getPersonnelGroupList()
        {
               $result = json_decode(callAPI('GET',PATH_API.'personnelgroup/desc',''));  
               //console($result);
               if($result->header->res_code=='200')
               {
                        $object = $result->body;
               }
               else $object = NULL;
               
               return $object;
        }

        public function AddPersonnelGroup($title)
        {
                $data = new stdClass(); 
                $data->title = $title;
                $data->created_by = $create_by;
                
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('POST',PATH_API.'personnelgroup',$myJSON));  
                
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }
        

        public function getPersonnelList($page=1,$personnelGroup=0,$permission=0)
        {
               $limit = PAGE_LIMIT;
               $result = json_decode(callAPI('GET',PATH_API.'personnel/list/'.$page.'/'.$limit.'/desc?permission='.$permission.'&position='.$personnelGroup.'',''));  
               //console($result);
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function AddPersonnel($data)
        {
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('POST',PATH_API.'personnel',$myJSON));  
                //console($result);
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }

        public function UpdatePersonnel($data)
        {
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('PUT',PATH_API.'personnel',$myJSON));  
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }

        public function getPermissionList()
        {
               $result = json_decode(callAPI('GET',PATH_API.'permission/desc',''));  
               
               if($result->header->res_code=='200')
               {
                        $object = $result->body;
               }
               else $object = NULL;
               
               return $object;
        }

        public function getEducationList($page=1)
        {
               $result = json_decode(callAPI('GET',PATH_API.'educationlevel',''));    

               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function getEducationSubList($page=1)
        {
               $limit = PAGE_LIMIT;
               $result = json_decode(callAPI('GET',PATH_API.'educationsublevel',''));  
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function getEducationSubListById($id)
        {
               $result = json_decode(callAPI('GET',PATH_API.'educationsublevel/filter/'.$id.'',''));  
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function getClassroomList($academic_year=2562,$term_id=0,$education=0,$educationSub=0,$room=0)
        {
               //echo PATH_API.'classroom?academic_year='.$academic_year.'&term_id='.$term_id.'&education_level_id='.$education.'&education_sublevel_id='.$educationSub.'&room='.$room.'';
               $result = json_decode(callAPI('GET',PATH_API.'classroom?academic_year='.$academic_year.'&term_id='.$term_id.'&education_level_id='.$education.'&education_sublevel_id='.$educationSub.'&room='.$room.'',''));  
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function getEducationSubByEducation($id)
        {
               $result = json_decode(callAPI('GET',PATH_API.'educationsublevel/filter/'.$id.'',''));  
               
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function getClassroomRoom($academicYear=2562,$term_id=0,$education=0,$educationSub=0)
        {
               $result = json_decode(callAPI('GET',PATH_API.'classroom/room/'.$academicYear.'/'.$education.'/'.$educationSub.'',''));  
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
               
        }

        public function AddClassroom($academic_year,$education,$educationSub,$room,$personnel,$create_by)
        {
                $data = new stdClass(); 
                $data->academic_year = $academic_year;
                $data->education_level_id = $education;
                $data->education_sublevel_id = $educationSub;
                $data->personnel_id = $room;
                $data->room = $personnel;
                $data->created_by = $create_by;
                
                
                $myJSON = json_encode($data); 
                $result = json_decode(callAPI('POST',PATH_API.'classroom',$myJSON)); 
                console($result); 
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }

        public function getAddress($key)
        {
               $limit = PAGE_LIMIT;
               $result = json_decode(callAPI('GET',PATH_API.'subdistrict/search/'.$key.'',''));  
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function getParentList($page=1,$key)
        {
               $limit = PAGE_LIMIT;
               $key = urlencode($key);
               $result = json_decode(callAPI('GET',PATH_API.'parent/list/'.$page.'/'.$limit.'?search='.$key.'',''));  
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function UpdateParent($data)
        {
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('PUT',PATH_API.'parent',$myJSON));  
                //console($result);
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }

        public function deleteParent($data)
        {
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('DEL',PATH_API.'parent',$myJSON));  
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }

        public function getDistrictId($key)
        {
              $key = urlencode($key);
              $result = json_decode(callAPI('GET',PATH_API.'district/search/'.$key.'',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function getProvinceId($key)
        {
              $key = urlencode($key);
               $result = json_decode(callAPI('GET',PATH_API.'province/search/'.$key.'',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               
               return $object;
        }

        public function AddParent($data)
        {
                $myJSON = json_encode($data); 
                $result = json_decode(callAPI('POST',PATH_API.'parent',$myJSON));  
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }

        public function getStudentList($academicYear,$term_id,$page=1)
        {
               $limit = PAGE_LIMIT;
               $result = json_decode(callAPI('GET',PATH_API.'student/list/'.$academicYear.'/'.$term_id.'/'.$page.'/'.$limit.'',''));  
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function AddStudent($data)
        {
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('POST',PATH_API.'student',$myJSON));  
                //console($result);
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }    
        
        public function AddSubject($data)
        {
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('POST',PATH_API.'subject',$myJSON));  
                //console($result);
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }  

        public function getBehaviorList($type=0)
        {
               if($type=='')
               {
                        $result = json_decode(callAPI('GET',PATH_API.'rules/asc',''));
               }
               else $result = json_decode(callAPI('GET',PATH_API.'rules/asc?filter='.$type.'',''));

               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function getBehaviorSearch($key=NULL)
        {
               $limit = PAGE_LIMIT;

               $key = urlencode($key);

               $result = json_decode(callAPI('GET',PATH_API.'rules/search/'.$key.'','')); 
               //console($result); 
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function AddBehavior($data)
        {
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('POST',PATH_API.'rules',$myJSON));  
                //console($result);
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        } 

        public function getRankList()
        {
               $result = json_decode(callAPI('GET',PATH_API.'pointrank/asc',''));  
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function updateRank($data)
        {
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('PUT',PATH_API.'pointrank',$myJSON));  
                //console($result);
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        } 

        public function getPersonnelSearch($key=NULL)
        {
               $limit = PAGE_LIMIT;

               $key = urlencode($key);

               $result = json_decode(callAPI('GET',PATH_API.'personnel/search/'.$key.'','')); 
               
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function getClassroomProfile($academicYear,$id)
        {
               
               $result = json_decode(callAPI('GET',PATH_API.'classroom/detail/'.$academicYear.'/'.$id.'','')); 
               
               if($result->header->res_code=='200')
               {
                        $object = $result->body[0];
               }
               else $object = NULL;
               
               return $object;
        }

        public function updateClassroom($data)
        {
                $myJSON = json_encode($data); 
                $result = json_decode(callAPI('PUT',PATH_API.'classroom',$myJSON));
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }

        public function mappingPersonnelClassroom($data)
        {
                $myJSON = json_encode($data); 
                $result = json_decode(callAPI('POST',PATH_API.'classroom/personnel',$myJSON));  
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        } 

        public function UpdateStudent($data)
        {
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('PUT',PATH_API.'student',$myJSON));  
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }

        public function autoCheckInAllRoom($classroom_id,$create_by)
        {
               $result = json_decode(callAPI('GET',PATH_API.'autocheckin?classroom_id='.$classroom_id.'&created_by='.$create_by.'','')); 
               if($result->header->res_code=='200')
               {
                        $object = true;
               }
               else $object = false;
               
               return $object;
        }

        public function getActivityList()
        {
               $limit = PAGE_LIMIT;
               $result = json_decode(callAPI('GET',PATH_API.'subject/list',''));  
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function getOnetList($subjectGroup=0,$subjectType=0,$educationSub=0,$page=1)
        {
               $limit = PAGE_LIMIT;
               $result = json_decode(callAPI('GET',PATH_API.'subject/list/filter/'.$subjectGroup.'/'.$subjectType.'/'.$educationSub.'/'.$page.'/'.$limit.'',''));  
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function getSubjectConfig($id)
        {
                $result = json_decode(callAPI('GET',PATH_API.'subjectconfig/scoredetail?subject_id='.$id.'',''));  
               
                if($result->header->res_code=='200')
                {
                      $object = $result->body;
                }
                else $object = NULL;
                return $object;
        }

        public function subjectUpdateScore($data)
        {
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('POST',PATH_API.'subjectconfig/score',$myJSON));  
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }

        public function getOnetRoomList()
        {
                $result = json_decode(callAPI('GET',PATH_API.'onetstudent/studentroom',''));  
               
                if($result->header->res_code=='200')
                {
                      $object = $result->body;
                }
                else $object = NULL;
                return $object;
        }

        public function getOnetStudentList($room_id)
        {
                $result = json_decode(callAPI('GET',PATH_API.'onetstudent/student?room_id='.$room_id.'',''));  
               
                if($result->header->res_code=='200')
                {
                      $object = $result->body;
                }
                else $object = NULL;
                return $object;
        }

        public function getStudentOnetScore($student_id,$academic_year)
        {
                $result = json_decode(callAPI('GET',PATH_API.'onetstudent/score?student_id='.$student_id.'&academic_year='.$academic_year.'',''));  
               
                if($result->header->res_code=='200')
                {
                      $object = $result->body;
                }
                else $object = NULL;
                return $object;
        }

        public function updateOnetScore($data)
        {
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('POST',PATH_API.'onetstudent/score',$myJSON));  
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }

        public function getStudentEvaluation($student_id,$academic_year)
        {
                $result = json_decode(callAPI('GET',PATH_API.'evaluation?student_id='.$student_id.'&academic_year='.$academic_year.'',''));  
               
                if($result->header->res_code=='200')
                {
                      $object = $result->body;
                }
                else $object = NULL;
                return $object;
        }

        public function updateEvalution($data)
        {
                $myJSON = json_encode($data); 

                $result = json_decode(callAPI('POST',PATH_API.'evaluation',$myJSON));  
                if($result->header->res_code=='200')
                {
                        return true;
                }
                else return false;
        }
        

}