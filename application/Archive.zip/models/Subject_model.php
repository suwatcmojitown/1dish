<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Subject_model extends CI_Model {

        public function getSubjectProfile($id=NULL)
        {
               $result = json_decode(callAPI('GET',PATH_API.'subject/detail/'.$id.'',''));  
               
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function addPersonnel($data)
        {
            $myJSON = json_encode($data); 
            $result = json_decode(callAPI('POST',PATH_API.'personnelmapmatching',$myJSON));  
            if($result->header->res_code=='200')
            {
                    return true;
            }
            else return false;
        }

        public function getSubjectOwner($id=NULL)
        {
               $result = json_decode(callAPI('GET',PATH_API.'personnelmapmatching/subject/'.$id.'',''));  
               
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function delPersonnel($data)
        {
            $myJSON = json_encode($data); 
            $result = json_decode(callAPI('DEL',PATH_API.'personnelmapmatching',$myJSON));  
            //console($result);
            if($result->header->res_code=='200')
            {
                    return true;
            }
            else return false;
        }

        public function getScoreByClassroom($academic_year=NULL,$classroom_id=NULL,$subject_id=NULL)
        {
               $result = json_decode(callAPI('GET',PATH_API.'score/classroom?academic_year='.$academic_year.'&classroom_id='.$classroom_id.'&subject_id='.$subject_id.'',''));  
               
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        /*
        public function getStudentList($id=NULL)
        {
               $result = json_decode(callAPI('GET',PATH_API.'classroom/student/'.$id.'',''));  
               
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function searchStudent($key=NULL)
        {
               $key = urlencode($key);
               $result = json_decode(callAPI('GET',PATH_API.'student/list','')); 
               //$result = json_decode(callAPI('GET',PATH_API.'parent/list?search='.$key.'',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function addStudent($data)
        {
            $myJSON = json_encode($data); 
            $result = json_decode(callAPI('POST',PATH_API.'classroom/student',$myJSON));  
            if($result->header->res_code=='200')
            {
                    return true;
            }
            else return false;
        }

        public function updateParent($data)
        {
            $myJSON = json_encode($data); 
            $result = json_decode(callAPI('PUT',PATH_API.'studentmapmatching',$myJSON)); 
            if($result->header->res_code=='200')
            {
                    return true;
            }
            else return false;
        }

        public function deleteParent($data)
        {
            $myJSON = json_encode($data); 
            $result = json_decode(callAPI('DEL',PATH_API.'studentmapmatching/studentparent',$myJSON)); 
            if($result->header->res_code=='200')
            {
                    return true;
            }
            else return false;
        }
        */

}