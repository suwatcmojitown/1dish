<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Personnel_model extends CI_Model {

        public function getPersonnelProfile($id=NULL)
        {
               $result = json_decode(callAPI('GET',PATH_API.'personnel/detail/'.$id.'',''));  
               
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function getStudentList($academicYear=2562,$id=NULL,$term_id=1)
        {
               $result = json_decode(callAPI('GET',PATH_API.'classroom/student/'.$academicYear.'/'.$id.'/'.$term_id.'',''));  
               //console($result);
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function searchStudent($key=NULL)
        {
               $key = urlencode($key);
               $result = json_decode(callAPI('GET',PATH_API.'student/list','')); 
               //$result = json_decode(callAPI('GET',PATH_API.'parent/list?search='.$key.'',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function addStudent($data)
        {
            $myJSON = json_encode($data); 
            $result = json_decode(callAPI('POST',PATH_API.'classroom/student',$myJSON));  
            if($result->header->res_code=='200')
            {
                    return true;
            }
            else return false;
        }

        public function updateParent($data)
        {
            $myJSON = json_encode($data); 
            $result = json_decode(callAPI('PUT',PATH_API.'studentmapmatching',$myJSON)); 
            if($result->header->res_code=='200')
            {
                    return true;
            }
            else return false;
        }

        public function deleteParent($data)
        {
            $myJSON = json_encode($data); 
            $result = json_decode(callAPI('DEL',PATH_API.'studentmapmatching/studentparent',$myJSON)); 
            if($result->header->res_code=='200')
            {
                    return true;
            }
            else return false;
        }

        public function getPersonnelSubject($id=NULL)
        {
               $result = json_decode(callAPI('GET',PATH_API.'personnelmapmatching/getsubjectclassroom?personnel_id='.$id.'',''));  
               
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }
        

}