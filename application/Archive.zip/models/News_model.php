<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class News_model extends CI_Model
{
    public function getNewsList($status = '', $page = 1, $limit = 15)
    {
        $this->db->select('news.*, user.display_name as author_name');
        $this->db->from('news');
        $this->db->join('user', 'news.user_id = user.user_id', 'left');
        if ($status != '') $this->db->where('news.status', $status);
        $this->db->order_by('news.created_at', 'DESC');
        $this->db->limit($limit, ($page - 1) * $limit);
        $query = $this->db->get();
        return ($query->num_rows() > 0) ? $query->result() : array();
    }

    public function countNews($status = '')
    {
        if ($status != '') $this->db->where('status', $status);
        return $this->db->count_all_results('news');
    }

    public function getNews($news_id)
    {
        $this->db->select('news.*, user.display_name as author_name');
        $this->db->from('news');
        $this->db->join('user', 'news.user_id = user.user_id', 'left');
        $this->db->where('news.news_id', $news_id);
        $query = $this->db->get();
        return ($query->num_rows() > 0) ? $query->row() : null;
    }

    public function saveNews($data)
    {
        if (!empty($data['news_id'])) {
            $id = $data['news_id'];
            unset($data['news_id']);
            $data['updated_at'] = date('Y-m-d H:i:s');
            $this->db->where('news_id', $id)->update('news', $data);
            return $id;
        }
        $this->db->insert('news', $data);
        return $this->db->insert_id();
    }

    public function deleteNews($news_id)
    {
        $this->db->delete('news', array('news_id' => $news_id));
        return $this->db->affected_rows() > 0;
    }

    // สำหรับหน้า front
    public function getFrontNews($limit = 4)
    {
        $this->db->select('news.news_id, news.title, news.category, news.excerpt,
            news.thumbnail, news.published_at, news.created_at,
            user.display_name as author_name');
        $this->db->from('news');
        $this->db->join('user', 'news.user_id = user.user_id', 'left');
        $this->db->where('news.status', 'published');
        $this->db->order_by('news.published_at', 'DESC');
        $this->db->limit($limit);
        $query = $this->db->get();
        return ($query->num_rows() > 0) ? $query->result() : array();
    }
}
