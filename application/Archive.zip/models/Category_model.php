<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Category_model extends CI_Model {

        
        public function getCatDetail($cat_id=NULL)
        {
                $query = $this->db->query("
                        SELECT cat_tmp.category_template_id,cat_tmp.description,cat_tmp.thumbnail,cat_tmp.cat_color,
                        cat_tmp.cat_id,cat_tmp.service,cat_tmp.tools,cat_tmp.rate,cat.slug,cat.cat_name,cat.thumbnail as cat_thumbnail
                        FROM category_template AS cat_tmp 
                        INNER JOIN category AS cat ON cat.cat_id = cat_tmp.cat_id
                        WHERE cat_tmp.cat_id = $cat_id AND cat_tmp.status=1
                        ;");
                $object = $query->result_array();

                return $object;
        }

        public function getCatnameBySlug($slug=NULL)
        {
                $query = $this->db->query("
                        SELECT cat_id,cat_name,slug,thumbnail
                        FROM category 
                        WHERE slug = '$slug' AND status=1
                        ;");
                $object = $query->result_array();

                return $object;
        }

        public function getCategoryList()
        {
                $query = $this->db->query("
                        SELECT cat_id,cat_name,slug,icon,color,description
                        FROM category 
                        WHERE cat_home=0 AND status=1
                        ;");
                $object = $query->result_array();

                return $object;   
        }

        /*
        public function insert_entry()
        {
                $this->title    = $_POST['title']; // please read the below note
                $this->content  = $_POST['content'];
                $this->date     = time();

                $this->db->insert('entries', $this);
        }

        public function update_entry()
        {
                $this->title    = $_POST['title'];
                $this->content  = $_POST['content'];
                $this->date     = time();

                $this->db->update('entries', $this, array('id' => $_POST['id']));
        }
        */

}