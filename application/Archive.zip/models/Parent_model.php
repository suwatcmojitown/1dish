<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Parent_model extends CI_Model {

        

        public function getParentProfile($id)
        {
               $result = json_decode(callAPI('GET',PATH_API.'parent/detail/'.$id.'',''));  
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        
        

}