<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Student_model extends CI_Model {

        public function getStudentProfile($academicYear,$term_id,$id=NULL)
        {
               $result = json_decode(callAPI('GET',PATH_API.'student/detail/'.$academicYear.'/'.$term_id.'/'.$id.'',''));  
               
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function getParent($id=NULL)
        {
               $result = json_decode(callAPI('GET',PATH_API.'studentmapmatching/student/'.$id.'',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function getParentByRelationship($id=NULL,$relationship=NULL)
        {
               $result = json_decode(callAPI('GET',PATH_API.'studentmapmatching/student/'.$id.'/'.$relationship.'',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function searchParent($key=NULL)
        {
               $key = urlencode($key);
               $result = json_decode(callAPI('GET',PATH_API.'parent/list?search='.$key.'',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function addParent($data)
        {
            $myJSON = json_encode($data); 
            $result = json_decode(callAPI('POST',PATH_API.'studentmapmatching',$myJSON));  
            if($result->header->res_code=='200')
            {
                    return true;
            }
            else return false;
        }

        public function updateParent($data)
        {
            $myJSON = json_encode($data); 
            $result = json_decode(callAPI('PUT',PATH_API.'studentmapmatching',$myJSON)); 
            if($result->header->res_code=='200')
            {
                    return true;
            }
            else return false;
        }

        public function getParentContactPoint($id=NULL)
        {
               $result = json_decode(callAPI('GET',PATH_API.'studentmapmatching/contactpoint/'.$id.'',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

        public function deleteParent($data)
        { 
            //console($data);
            $myJSON = json_encode($data); 
            $result = json_decode(callAPI('DEL',PATH_API.'studentmapmatching/studentparent',$myJSON)); 
            //console($result);
            if($result->header->res_code=='200')
            {
                    return true;
            }
            else return false;
        }

        public function getBehaviorLog($student_id,$type,$page=1)
        {
               
               $result = json_decode(callAPI('GET',PATH_API.'behaviorpoint/logs/'.$student_id.'/asc?filter='.$type.'',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
            
        }

        public function getBehaviorPoint($student_id)
        {
            $result = json_decode(callAPI('GET',PATH_API.'behaviorpoint/logs/'.$student_id.'',''));  
              //console($result);
               if($result->header->res_code=='200')
               {
                     $object = $result->body->total_point;
               }
               else $object = NULL;
               return $object;
            
        }

        public function getNowScore($student_id)
        {
            $result = json_decode(callAPI('GET',PATH_API.'behaviorpoint/logs/'.$student_id.'',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
            
        }

        public function getAllScore($student_id)
        {
            $result = json_decode(callAPI('GET',PATH_API.'behaviorpoint/logs/'.$student_id.'',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
            
        }

        public function getTimesheetInfo($student_id)
        {
            $result = json_decode(callAPI('GET',PATH_API.'timesheetinfo/student/'.$student_id.'?page=1&limit=20&filter=normal',''));  
            if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
            
        }

        public function getTimesheetLate($student_id)
        {
            $result = json_decode(callAPI('GET',PATH_API.'timesheetinfo/student/'.$student_id.'?page=1&limit=20',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
            
        }

        public function getTimesheetLeaveBefore($student_id)
        {
            $result = json_decode(callAPI('GET',PATH_API.'timesheetinfo/student/'.$student_id.'?page=1&limit=20&filter=leave_before_time',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
            
        }

        public function getTimesheetAbsent($student_id)
        {
            $result = json_decode(callAPI('GET',PATH_API.'timesheetinfo/student/'.$student_id.'?page=1&limit=20&filter=absent',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
            
        }

        public function getStudentList($page=1)
        {
               $limit = ePAGE_LIMIT;
               $result = json_decode(callAPI('GET',PATH_API.'student/list/'.$page.'/'.$limit.'',''));  
               //console($result);
               if($result->header->res_code=='200')
               {
                        $object = $result;
               }
               else $object = NULL;
               
               return $object;
        }

        public function searchStudent($academicYear,$term_id,$keysearch)
        {
               $result = json_decode(callAPI('GET',PATH_API.'student/search/'.$academicYear.'/'.$term_id.'/'.urlencode($keysearch).'',''));  
               if($result->header->res_code=='200')
               {
                     $object = $result->body;
               }
               else $object = NULL;
               return $object;
        }

}